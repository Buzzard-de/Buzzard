import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/seo/config";

export const dynamic = "force-static";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: [
          "/admin/",
          "/konto/",
          "/checkout/",
          "/warenkorb/",
          "/wunschliste/",
          "/api/",
        ],
      },
    ],
    sitemap: `${SITE_URL}/sitemap.xml`,
  };
}
