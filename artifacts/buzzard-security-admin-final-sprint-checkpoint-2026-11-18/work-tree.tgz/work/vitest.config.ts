import { defineConfig } from "vitest/config";
import path from "path";

export default defineConfig({
  test: {
    environment: "node",
    include: [
      "server/__tests__/**/*.test.mjs",
      "!server/__tests__/part24*.test.mjs",
      "!server/__tests__/part27*.test.mjs",
      "!server/__tests__/part28*.test.mjs",
      "!server/__tests__/part29*.test.mjs",
      "!server/__tests__/part30*.test.mjs",
      "!server/__tests__/part31*.test.mjs",
      "!server/__tests__/part32*.test.mjs",
      "!server/__tests__/part33*.test.mjs",
      "!server/__tests__/part34*.test.mjs",
      "!server/__tests__/part35*.test.mjs",
      "lib/backgrounds/**/*.test.ts",
      "lib/market/languageIndependence.test.ts",
      "lib/market/resolveInitialCountry.test.ts",
      "lib/i18n/catalog.test.ts",
      "lib/i18n/languages.test.ts",
      "lib/i18n/routing.test.ts",
      "lib/i18n/localeAudit.test.ts",
      "server/__tests__/ecosystemScorecard.test.mjs",
      "lib/categories/i18n.test.ts",
    ],
    globals: false,
    globalSetup: ["./scripts/vitest-global-setup.mjs"],
    testTimeout: 15000,
    env: {
      BUZZARD_SALES_GATE_BYPASS: "1",
    },
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "."),
    },
  },
});
