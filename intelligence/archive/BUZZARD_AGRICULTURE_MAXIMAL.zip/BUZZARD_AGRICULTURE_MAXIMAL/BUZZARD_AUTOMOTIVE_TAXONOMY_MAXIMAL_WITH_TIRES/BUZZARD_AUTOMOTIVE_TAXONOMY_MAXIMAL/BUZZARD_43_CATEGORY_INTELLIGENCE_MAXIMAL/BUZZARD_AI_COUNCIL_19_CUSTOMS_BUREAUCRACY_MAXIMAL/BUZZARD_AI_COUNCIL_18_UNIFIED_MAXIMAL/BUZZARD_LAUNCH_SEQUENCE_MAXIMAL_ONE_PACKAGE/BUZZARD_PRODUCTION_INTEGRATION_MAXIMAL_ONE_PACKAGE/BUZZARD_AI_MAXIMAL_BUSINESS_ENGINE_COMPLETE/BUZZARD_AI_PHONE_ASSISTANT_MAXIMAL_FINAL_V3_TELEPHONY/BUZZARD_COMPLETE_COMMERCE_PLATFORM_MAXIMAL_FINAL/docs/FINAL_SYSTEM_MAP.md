Master Taxonomy → PIM → Multilingual AI → Supplier Engine → Commerce → Checkout/Payment → Orders → Inventory → Logistics → Marketplaces → Phone AI → Doğu Bey → Esat Bey → Audit/Observability → Deployment.
External providers remain adapters; credentials stay outside source code.
