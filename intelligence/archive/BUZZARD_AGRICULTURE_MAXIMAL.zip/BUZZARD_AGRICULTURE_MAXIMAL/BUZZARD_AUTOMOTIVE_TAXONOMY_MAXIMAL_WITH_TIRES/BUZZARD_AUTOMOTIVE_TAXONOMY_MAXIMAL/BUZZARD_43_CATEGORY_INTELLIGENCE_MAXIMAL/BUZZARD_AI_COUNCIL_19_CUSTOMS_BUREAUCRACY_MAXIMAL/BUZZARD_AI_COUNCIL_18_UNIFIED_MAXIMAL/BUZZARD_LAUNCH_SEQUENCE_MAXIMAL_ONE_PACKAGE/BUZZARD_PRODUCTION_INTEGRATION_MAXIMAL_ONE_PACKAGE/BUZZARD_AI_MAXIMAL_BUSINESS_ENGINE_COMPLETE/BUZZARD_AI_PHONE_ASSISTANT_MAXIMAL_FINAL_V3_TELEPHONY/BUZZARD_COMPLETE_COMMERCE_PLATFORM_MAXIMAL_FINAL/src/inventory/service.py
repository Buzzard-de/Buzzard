class InventoryService:
 def __init__(self,repo): self.repo=repo
 def available(self,pid): return int((self.repo.get(pid) or {}).get("available",0))
 def reserve(self,pid,q):
  if q<1: raise ValueError("INVALID_QUANTITY")
  r=self.repo.get(pid) or {"available":0,"reserved":0}
  if r["available"]<q: raise ValueError("INSUFFICIENT_STOCK")
  r["available"]-=q; r["reserved"]=r.get("reserved",0)+q; self.repo.save(pid,r); return r
 def release(self,pid,q):
  r=self.repo.get(pid) or {"available":0,"reserved":0}; r["reserved"]=max(0,r.get("reserved",0)-q); r["available"]+=q; self.repo.save(pid,r); return r
