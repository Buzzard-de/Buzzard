class LogisticsService:
 def __init__(self,carriers): self.carriers=carriers
 def quote(self,shipment): return sorted([{"carrier":n,**a.quote(shipment)} for n,a in self.carriers.items() if a.quote(shipment)],key=lambda x:x.get("price",10**9))
 def buy_label(self,carrier,shipment): return self.carriers[carrier].buy_label(shipment)
