TRANSITIONS={"pending_payment":{"paid","cancelled"},"paid":{"processing","cancelled","refunded"},"processing":{"fulfilled","on_hold","cancelled"},"fulfilled":{"shipped"},"shipped":{"delivered","on_hold"},"delivered":{"refunded","partially_refunded"},"on_hold":{"processing","cancelled"}}
class OrderService:
 def __init__(self,repo): self.repo=repo
 def transition(self,oid,status):
  o=self.repo.get(oid)
  if not o: raise ValueError("ORDER_NOT_FOUND")
  if status not in TRANSITIONS.get(o["status"],set()): raise ValueError("INVALID_ORDER_TRANSITION")
  o["status"]=status; self.repo.save(o); return o
