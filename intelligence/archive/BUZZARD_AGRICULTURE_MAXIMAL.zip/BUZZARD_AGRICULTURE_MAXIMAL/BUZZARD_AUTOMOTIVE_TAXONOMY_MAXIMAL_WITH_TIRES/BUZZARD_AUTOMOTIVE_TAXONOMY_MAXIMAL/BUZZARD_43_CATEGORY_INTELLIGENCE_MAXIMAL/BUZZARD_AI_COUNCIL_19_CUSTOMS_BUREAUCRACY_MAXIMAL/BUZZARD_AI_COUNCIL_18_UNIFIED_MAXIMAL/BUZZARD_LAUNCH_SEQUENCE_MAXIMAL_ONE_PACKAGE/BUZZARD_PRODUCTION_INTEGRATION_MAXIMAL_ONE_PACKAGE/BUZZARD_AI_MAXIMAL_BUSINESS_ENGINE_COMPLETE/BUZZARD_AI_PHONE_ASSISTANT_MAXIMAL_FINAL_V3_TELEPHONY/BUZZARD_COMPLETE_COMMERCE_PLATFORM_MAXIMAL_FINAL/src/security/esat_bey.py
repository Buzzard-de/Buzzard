class EsatBeyDefense:
 def inspect(self,event):
  f=[]
  if event.get("failed_auth_count",0)>=5:f.append("BRUTE_FORCE_SIGNAL")
  if event.get("invalid_webhook"):f.append("INVALID_WEBHOOK")
  if event.get("unexpected_rate",0)>100:f.append("RATE_ANOMALY")
  return {"risk":"high" if f else "normal","findings":f,"action":"isolate_and_alert" if f else "allow"}
