class SecurityPolicy:
 def authorize(self,actor,action):
  if action not in actor.get("permissions",[]): raise PermissionError("ACTION_NOT_AUTHORIZED")
  return True
 def safe_log(self,event):
  blocked={"password","card_number","cvv","api_key","access_token","refresh_token"}
  return {k:v for k,v in event.items() if k not in blocked}
