from fastapi import FastAPI
app=FastAPI(title="BUZZARD Complete Commerce Platform",version="1.0.0")
@app.get("/api/system/health")
def health(): return {"system":"buzzard","status":"integration_ready","live_side_effects":False}
@app.get("/api/system/modules")
def modules(): return {"modules":["taxonomy","pim","multilingual","supplier_import","commerce","checkout","orders","inventory","logistics","marketplaces","phone_ai","dogu_bey","esat_bey","observability"]}
