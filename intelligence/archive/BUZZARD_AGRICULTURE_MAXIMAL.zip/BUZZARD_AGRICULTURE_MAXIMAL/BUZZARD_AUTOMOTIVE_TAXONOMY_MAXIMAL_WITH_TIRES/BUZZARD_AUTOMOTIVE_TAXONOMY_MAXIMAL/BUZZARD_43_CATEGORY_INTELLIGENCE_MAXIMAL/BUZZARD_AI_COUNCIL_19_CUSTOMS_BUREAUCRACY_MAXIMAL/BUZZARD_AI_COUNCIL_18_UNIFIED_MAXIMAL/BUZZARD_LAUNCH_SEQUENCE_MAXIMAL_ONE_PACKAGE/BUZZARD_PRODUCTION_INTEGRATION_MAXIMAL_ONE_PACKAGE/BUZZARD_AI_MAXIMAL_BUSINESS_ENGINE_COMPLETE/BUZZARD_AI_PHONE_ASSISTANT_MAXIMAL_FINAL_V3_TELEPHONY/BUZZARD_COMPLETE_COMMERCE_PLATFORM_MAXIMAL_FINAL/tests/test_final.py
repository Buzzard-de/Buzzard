import json
from pathlib import Path
R=Path(__file__).parents[1]
def test_taxonomy():
 d=json.loads((R/"data/taxonomy.json").read_text())
 assert len([n for n in d["nodes"] if n["level"]==1])==43
def test_events():
 d=json.loads((R/"schemas/events.json").read_text()); assert "order.paid" in d["events"]
def test_gate(): assert (R/"deployment/PRODUCTION_CHECKLIST.md").exists()
