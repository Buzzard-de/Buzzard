from fastapi import FastAPI,Request,HTTPException
from .webhooks.service import WebhookService
def create_phone_app(service):
    app=FastAPI(title="Buzzard AI Phone Gateway",version="3.0.0")
    wh=WebhookService(service.provider,service.sessions)
    @app.get("/api/phone/health")
    async def health():
        return {"status":"ready","provider":service.provider.name,"live_credentials_present":False}
    @app.post("/api/phone/inbound")
    async def inbound(request:Request):
        body=await request.json()
        try: data=wh.inbound(dict(request.headers),body)
        except Exception as e: raise HTTPException(401,"INVALID_WEBHOOK") from e
        s=service.create_session(data)
        return {"session":s.__dict__,"answer":service.answer(s)}
    @app.post("/api/phone/hangup/{call_id}")
    async def hangup(call_id):
        s=service.sessions.get(call_id)
        if not s: raise HTTPException(404,"CALL_NOT_FOUND")
        return service.hangup(s)
    return app
