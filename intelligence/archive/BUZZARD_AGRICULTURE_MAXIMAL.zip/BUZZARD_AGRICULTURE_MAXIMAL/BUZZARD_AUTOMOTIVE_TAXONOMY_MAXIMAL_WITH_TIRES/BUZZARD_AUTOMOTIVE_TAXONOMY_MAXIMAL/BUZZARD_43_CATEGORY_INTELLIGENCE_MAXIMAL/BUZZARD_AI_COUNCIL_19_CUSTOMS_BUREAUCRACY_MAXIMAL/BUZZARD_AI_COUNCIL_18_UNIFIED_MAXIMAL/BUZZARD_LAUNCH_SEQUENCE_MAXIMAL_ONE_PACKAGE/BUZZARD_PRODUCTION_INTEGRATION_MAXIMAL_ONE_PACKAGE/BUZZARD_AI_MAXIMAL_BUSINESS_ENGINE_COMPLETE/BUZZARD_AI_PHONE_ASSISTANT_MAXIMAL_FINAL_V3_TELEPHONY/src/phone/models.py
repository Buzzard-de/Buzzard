from dataclasses import dataclass, field
from typing import Optional, Dict, Any

@dataclass
class CallSession:
    call_id: str
    provider: str
    from_number: Optional[str]=None
    to_number: Optional[str]=None
    language: str="de"
    customer_id: Optional[str]=None
    verification_level: str="none"
    state: str="ringing"
    metadata: Dict[str,Any]=field(default_factory=dict)
