import uuid
from .models import CallSession
class PhoneAssistantService:
    def __init__(self,provider,router,sessions): self.provider=provider; self.router=router; self.sessions=sessions
    def create_session(self,inbound):
        cid=inbound.get("provider_call_id") or "call_"+uuid.uuid4().hex
        s=CallSession(cid,self.provider.name,inbound.get("from_number"),inbound.get("to_number"))
        self.sessions[cid]=s; return s
    def answer(self,session): return self.router.inbound(session)
    def hangup(self,session):
        session.state="ended"; return self.provider.hangup(session)
