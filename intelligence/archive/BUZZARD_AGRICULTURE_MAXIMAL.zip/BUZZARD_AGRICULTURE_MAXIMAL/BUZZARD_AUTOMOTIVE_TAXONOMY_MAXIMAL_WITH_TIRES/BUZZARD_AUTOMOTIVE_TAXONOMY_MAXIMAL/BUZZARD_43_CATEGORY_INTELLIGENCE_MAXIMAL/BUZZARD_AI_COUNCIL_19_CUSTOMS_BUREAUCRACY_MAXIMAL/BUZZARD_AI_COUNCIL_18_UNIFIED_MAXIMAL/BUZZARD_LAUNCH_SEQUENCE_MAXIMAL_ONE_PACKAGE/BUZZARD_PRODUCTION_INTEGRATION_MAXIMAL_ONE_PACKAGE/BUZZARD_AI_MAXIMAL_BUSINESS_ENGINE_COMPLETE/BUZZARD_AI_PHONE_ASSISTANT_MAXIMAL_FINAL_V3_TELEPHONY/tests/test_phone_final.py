import json
from pathlib import Path
R=Path(__file__).parents[1]
def test_safe_defaults():
 c=json.loads((R/"config/phone_production.json").read_text())
 assert c["enabled"] is False
 assert c["recording"]["enabled"] is False
 assert c["security"]["require_signed_webhooks"] is True
def test_schema():
 s=json.loads((R/"schemas/phone_call.schema.json").read_text())
 assert "handoff" in s["states"] and "active" in s["states"]
def test_gate():
 assert (R/"docs/PHONE_GO_LIVE.md").exists()
