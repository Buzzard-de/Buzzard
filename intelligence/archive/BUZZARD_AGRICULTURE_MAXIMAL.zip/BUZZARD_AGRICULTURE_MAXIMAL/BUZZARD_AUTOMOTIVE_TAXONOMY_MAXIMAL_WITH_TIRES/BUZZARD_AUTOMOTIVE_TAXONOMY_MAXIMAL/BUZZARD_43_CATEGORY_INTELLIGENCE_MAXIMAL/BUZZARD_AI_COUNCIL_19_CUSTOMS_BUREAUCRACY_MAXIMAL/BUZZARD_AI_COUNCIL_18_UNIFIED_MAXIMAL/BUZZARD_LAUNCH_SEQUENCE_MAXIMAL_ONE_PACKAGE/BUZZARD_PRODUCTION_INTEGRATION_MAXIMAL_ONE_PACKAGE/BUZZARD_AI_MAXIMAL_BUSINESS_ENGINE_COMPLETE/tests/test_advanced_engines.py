from decimal import Decimal
from src.pricing.engine import PricingEngine
from src.forecasting.engine import ForecastEngine
from src.finance.engine import FinanceEngine
from src.rma.service import RMAService
from src.customer_intelligence.engine import CustomerIntelligence
from src.supplier_intelligence.engine import SupplierIntelligence
from src.knowledge_graph.graph import KnowledgeGraph

class Repo:
    def __init__(self): self.data={}
    def get(self,k): return self.data.get(k)
    def save(self,k,v=None):
        if v is None: self.data[k["rma_id"]]=k
        else: self.data[k]=v
    def new_id(self): return "rma_test"

def test_pricing():
    class R:
        def get(self,p): return {"sale_price":"20"}
    p=PricingEngine(R(),{"target_margin":"0.11"})
    assert Decimal(p.recommend({"product_id":"p","cost":"10"})["recommended_price"]) > 10

def test_forecast():
    f=ForecastEngine()
    assert len(f.forecast([1,2,3,4],3)["daily_forecast"])==3

def test_finance():
    x=FinanceEngine().order_margin(100,60,10,5,0)
    assert x["contribution"]=="25"

def test_rma():
    r=RMAService(Repo())
    x=r.create("o",["p"],"damaged")
    assert x["status"]=="requested"
    assert r.transition(x["rma_id"],"approved")["status"]=="approved"

def test_customer():
    assert CustomerIntelligence().segment(0,0,0)=="new_or_unconverted"

def test_supplier():
    s=SupplierIntelligence().rank({"a":{"price":90,"availability":80,"delivery":70,"quality":90,"returns":90}})
    assert s[0]["supplier"]=="a"

def test_graph():
    g=KnowledgeGraph()
    g.upsert_node("p1","product")
    g.upsert_node("v1","vehicle")
    g.link("p1","compatible_with","v1",["catalog"])
    assert g.neighbors("p1")[0]["target"]=="v1"
