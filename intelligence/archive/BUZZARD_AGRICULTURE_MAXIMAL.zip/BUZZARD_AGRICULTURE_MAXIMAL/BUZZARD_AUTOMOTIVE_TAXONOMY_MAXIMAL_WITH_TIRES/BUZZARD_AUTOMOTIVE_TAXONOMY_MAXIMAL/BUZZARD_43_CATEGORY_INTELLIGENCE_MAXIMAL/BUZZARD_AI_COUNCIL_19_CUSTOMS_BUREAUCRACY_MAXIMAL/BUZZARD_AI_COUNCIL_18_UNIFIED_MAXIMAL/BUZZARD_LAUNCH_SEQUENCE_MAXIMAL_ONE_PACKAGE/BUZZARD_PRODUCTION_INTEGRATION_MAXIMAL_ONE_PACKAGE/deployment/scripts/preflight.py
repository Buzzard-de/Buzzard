import json,os,sys
from pathlib import Path

cfg=json.loads(Path("config/integrations.production.json").read_text())
required=["APP_BASE_URL","POSTGRES_DB","POSTGRES_USER","POSTGRES_PASSWORD"]
missing=[x for x in required if not os.getenv(x)]
if missing:
    print("MISSING_ENV:",",".join(missing))
    sys.exit(2)
if not cfg["deployment"]["https_required"]:
    print("WARNING: HTTPS requirement disabled")
print("PREFLIGHT_OK")
