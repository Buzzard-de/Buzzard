class MarketplaceSync:
    def __init__(self, providers, mapping):
        self.providers=providers
        self.mapping=mapping

    def publish(self, product):
        results={}
        for channel, provider in self.providers.items():
            results[channel]=provider.publish_product(product)
        return results

    def price_stock(self, product):
        results={}
        for channel, provider in self.providers.items():
            ext=self.mapping.external_id(channel,product["product_id"])
            results[channel]=provider.update_price_stock(ext,product["price"],product["stock"])
        return results
