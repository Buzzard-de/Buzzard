import json
from pathlib import Path
from src.integrations.webhooks.idempotency import IdempotencyStore
from src.integrations.webhooks.security import verify_hmac
from src.integrations.suppliers.feed_contract import SupplierNormalizer
from src.integrations.health.readiness import Readiness

ROOT=Path(__file__).parents[1]

def test_payment_idempotency():
    s=IdempotencyStore()
    s.put("k",{"id":"p1"})
    assert s.get("k")["id"]=="p1"

def test_webhook_hmac():
    import hashlib,hmac
    secret="test"
    body=b'{"ok":true}'
    sig=hmac.new(secret.encode(),body,hashlib.sha256).hexdigest()
    assert verify_hmac(secret,body,sig)

def test_supplier_normalization():
    n=SupplierNormalizer()
    x=n.normalize({"sku":"S1","title":"Test","price":"10","currency":"EUR","stock":4})
    assert x["supplier_sku"]=="S1"

def test_readiness():
    r=Readiness({"a":lambda:True,"b":lambda:True}).run()
    assert r["ready"] is True

def test_production_config():
    c=json.loads((ROOT/"config/integrations.production.json").read_text())
    assert c["deployment"]["https_required"] is True
    assert c["telephony"]["signed_webhooks"] is True
