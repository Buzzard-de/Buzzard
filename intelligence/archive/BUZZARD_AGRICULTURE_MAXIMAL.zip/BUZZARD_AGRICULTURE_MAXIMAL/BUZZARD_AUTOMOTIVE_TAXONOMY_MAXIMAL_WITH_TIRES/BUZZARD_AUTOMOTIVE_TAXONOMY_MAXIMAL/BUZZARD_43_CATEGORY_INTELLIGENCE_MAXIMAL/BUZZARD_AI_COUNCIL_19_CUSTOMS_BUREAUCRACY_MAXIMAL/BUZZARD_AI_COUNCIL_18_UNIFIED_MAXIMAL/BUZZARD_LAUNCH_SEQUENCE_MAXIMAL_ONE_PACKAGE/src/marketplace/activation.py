REQUIRED = {"channel","seller_account","api_credentials"}

def validate_channel(config):
    missing = [k for k in REQUIRED if not config.get(k)]
    return {
        "passed": not missing,
        "missing": missing,
        "status": "configured" if not missing else "not_configured"
    }
