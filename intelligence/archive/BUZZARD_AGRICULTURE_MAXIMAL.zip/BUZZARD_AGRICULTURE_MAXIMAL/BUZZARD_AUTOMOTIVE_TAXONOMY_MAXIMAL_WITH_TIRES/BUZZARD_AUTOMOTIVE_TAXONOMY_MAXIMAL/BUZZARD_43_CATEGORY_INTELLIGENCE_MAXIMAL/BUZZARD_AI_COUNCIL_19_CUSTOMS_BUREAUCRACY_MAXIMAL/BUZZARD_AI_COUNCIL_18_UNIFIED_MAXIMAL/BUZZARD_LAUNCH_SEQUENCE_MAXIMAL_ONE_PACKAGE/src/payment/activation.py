REQUIRED_KEYS = {
    "provider",
    "merchant_account",
    "webhook_secret"
}

def validate_payment_config(config):
    missing = [k for k in REQUIRED_KEYS if not config.get(k)]
    return {
        "passed": not missing,
        "missing": missing,
        "status": "configured" if not missing else "not_configured"
    }
