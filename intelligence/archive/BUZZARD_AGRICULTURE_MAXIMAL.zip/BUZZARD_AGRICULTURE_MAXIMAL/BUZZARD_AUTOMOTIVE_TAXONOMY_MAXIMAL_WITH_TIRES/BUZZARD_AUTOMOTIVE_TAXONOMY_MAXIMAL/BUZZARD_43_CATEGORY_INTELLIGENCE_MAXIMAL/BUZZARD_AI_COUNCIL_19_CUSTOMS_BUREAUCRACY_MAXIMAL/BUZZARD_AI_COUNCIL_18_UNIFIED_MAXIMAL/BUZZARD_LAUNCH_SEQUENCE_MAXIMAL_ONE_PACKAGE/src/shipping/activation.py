REQUIRED = {"carrier","account_id","api_credential"}

def validate_shipping_config(config):
    missing = [k for k in REQUIRED if not config.get(k)]
    return {
        "passed": not missing,
        "missing": missing,
        "status": "configured" if not missing else "not_configured"
    }
