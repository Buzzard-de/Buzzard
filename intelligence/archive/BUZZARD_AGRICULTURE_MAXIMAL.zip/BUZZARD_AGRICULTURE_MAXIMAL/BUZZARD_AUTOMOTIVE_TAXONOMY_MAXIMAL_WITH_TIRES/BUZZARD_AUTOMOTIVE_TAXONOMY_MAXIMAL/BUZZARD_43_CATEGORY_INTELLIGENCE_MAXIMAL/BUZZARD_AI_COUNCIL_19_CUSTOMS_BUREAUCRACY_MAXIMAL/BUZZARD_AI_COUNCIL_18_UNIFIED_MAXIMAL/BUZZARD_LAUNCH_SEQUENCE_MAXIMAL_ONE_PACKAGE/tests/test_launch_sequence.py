import json
from pathlib import Path
from src.launch.orchestrator import STAGES
from src.pim.import_pipeline import PIMImportPipeline
from src.payment.activation import validate_payment_config
from src.shipping.activation import validate_shipping_config
from src.marketplace.activation import validate_channel
from src.telephony.activation import validate_phone
from src.production.preflight import validate_environment

class Repo:
    def __init__(self): self.items={}
    def upsert(self,item): self.items[item["sku"]]=item

def test_stage_order():
    assert STAGES == [
        "domain_production_server","pim_real_product_data","supplier",
        "payment","shipping","marketplace","telephony","security_e2e","launch"
    ]

def test_pim():
    p=PIMImportPipeline(Repo())
    r=p.import_items([{"sku":"X","title":"X","price":"10","currency":"EUR","stock":2}],"test")
    assert r["imported"]==1

def test_activation_gates():
    assert validate_payment_config({"provider":"x","merchant_account":"m","webhook_secret":"s"})["passed"]
    assert validate_shipping_config({"carrier":"x","account_id":"a","api_credential":"c"})["passed"]
    assert validate_channel({"channel":"eBay","seller_account":"s","api_credentials":"c"})["passed"]
    assert validate_phone({"provider":"x","phone_number":"+1","credentials":"c","public_webhook":"https://x","media_stream":"wss://x"})["passed"]

def test_preflight():
    assert validate_environment({
        "APP_BASE_URL":"https://buzzard.example",
        "APP_DOMAIN":"buzzard.example",
        "POSTGRES_DB":"b","POSTGRES_USER":"u","POSTGRES_PASSWORD":"p"
    })["passed"]

def test_launch_config():
    p=Path(__file__).parents[1]/"config/launch_state.json"
    data=json.loads(p.read_text())
    assert data["launch"]["status"]=="blocked_until_all_previous_pass"
