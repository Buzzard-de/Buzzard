from src.council.contracts import AgentFinding
class SeasonAi:
    agent_id="season_ai"
    name="Season AI"
    input_topics="season,demand,market,forecast".split(",")
    def __init__(self,memory=None): self.memory=memory
    def analyze(self,objective,context,prior_findings):
        return AgentFinding(agent_id=self.agent_id,topic=self.agent_id,
            finding=f"{self.name} assessment for: {objective}. Prior shared findings were supplied.",
            confidence=0.82 if self.agent_id=="customs_bureaucracy_ai" else 0.75,
            recommendations=["cross-check with shared evidence and other specialists"],
            risks=["current external data and official sources must be verified"],
            requires_human_approval=self.agent_id in ["chief_strategy_ai","profit_ai","compliance_risk_ai","customs_bureaucracy_ai"])
