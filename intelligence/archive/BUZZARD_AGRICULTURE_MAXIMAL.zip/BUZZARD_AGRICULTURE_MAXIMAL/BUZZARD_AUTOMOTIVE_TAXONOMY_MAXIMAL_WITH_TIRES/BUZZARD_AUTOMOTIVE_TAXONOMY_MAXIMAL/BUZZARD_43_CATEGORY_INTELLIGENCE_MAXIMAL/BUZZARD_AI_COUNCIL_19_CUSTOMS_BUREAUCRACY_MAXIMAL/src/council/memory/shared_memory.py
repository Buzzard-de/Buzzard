
class SharedIntelligenceMemory:
    def __init__(self): self.findings=[]
    def add_finding(self,f): self.findings.append(f); return f.finding_id
    def search(self,topic=None,limit=50):
        rows=self.findings
        if topic: rows=[x for x in rows if topic.lower() in x.topic.lower() or topic.lower() in x.finding.lower()]
        return rows[-limit:]
    def context(self,topics,limit_per_topic=10): return {t:self.search(t,limit_per_topic) for t in topics}
