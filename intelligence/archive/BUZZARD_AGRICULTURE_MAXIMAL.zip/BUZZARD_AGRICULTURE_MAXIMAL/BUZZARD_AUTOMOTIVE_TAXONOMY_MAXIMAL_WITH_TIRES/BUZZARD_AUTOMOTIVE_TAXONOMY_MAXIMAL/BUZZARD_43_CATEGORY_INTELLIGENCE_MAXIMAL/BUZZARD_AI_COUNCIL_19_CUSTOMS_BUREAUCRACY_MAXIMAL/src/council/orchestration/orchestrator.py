
class CouncilOrchestrator:
    def __init__(self,router,memory,guardrails): self.router=router; self.memory=memory; self.guardrails=guardrails
    def run_case(self,case,agent_ids):
        for aid in agent_ids:
            a=self.router.get(aid)
            f=self.guardrails.validate(a.analyze(case.objective,case.context,self.memory.context(a.input_topics)))
            self.memory.add_finding(f); case.findings.append(f)
        return case
    def consensus(self,case):
        return {"status":"review_required","findings":len(case.findings),
                "confidence":round(sum(f.confidence for f in case.findings)/len(case.findings),3) if case.findings else 0}
