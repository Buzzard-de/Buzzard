
class CouncilGuardrails:
    def validate(self,finding):
        if not 0 <= finding.confidence <= 1: raise ValueError("INVALID_CONFIDENCE")
        if not finding.finding.strip(): raise ValueError("EMPTY_FINDING")
        return finding
