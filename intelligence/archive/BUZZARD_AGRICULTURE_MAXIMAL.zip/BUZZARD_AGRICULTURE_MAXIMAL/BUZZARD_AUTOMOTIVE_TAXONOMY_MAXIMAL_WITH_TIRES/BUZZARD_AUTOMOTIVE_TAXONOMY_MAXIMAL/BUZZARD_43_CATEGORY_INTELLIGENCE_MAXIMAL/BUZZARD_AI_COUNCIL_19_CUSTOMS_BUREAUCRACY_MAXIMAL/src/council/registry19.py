from .orchestration.router import AgentRouter
from .agents.chief_strategy_ai import ChiefStrategyAi
from .agents.market_intelligence_ai import MarketIntelligenceAi
from .agents.demand_analyst_ai import DemandAnalystAi
from .agents.competition_ai import CompetitionAi
from .agents.profit_ai import ProfitAi
from .agents.supply_ai import SupplyAi
from .agents.forecast_ai import ForecastAi
from .agents.tiktok_intelligence_ai import TiktokIntelligenceAi
from .agents.youtube_intelligence_ai import YoutubeIntelligenceAi
from .agents.marketplace_intelligence_ai import MarketplaceIntelligenceAi
from .agents.compliance_risk_ai import ComplianceRiskAi
from .agents.logistics_ai import LogisticsAi
from .agents.customer_voice_ai import CustomerVoiceAi
from .agents.returns_ai import ReturnsAi
from .agents.manufacturer_product_ai import ManufacturerProductAi
from .agents.season_ai import SeasonAi
from .agents.product_quality_ai import ProductQualityAi
from .agents.country_opportunity_ai import CountryOpportunityAi
from .agents.customs_bureaucracy_ai import CustomsBureaucracyAi
AGENT_CLASSES=[ChiefStrategyAi,MarketIntelligenceAi,DemandAnalystAi,CompetitionAi,ProfitAi,SupplyAi,ForecastAi,TiktokIntelligenceAi,YoutubeIntelligenceAi,MarketplaceIntelligenceAi,ComplianceRiskAi,LogisticsAi,CustomerVoiceAi,ReturnsAi,ManufacturerProductAi,SeasonAi,ProductQualityAi,CountryOpportunityAi,CustomsBureaucracyAi]
def build_registry19(memory=None):
    r=AgentRouter()
    for cls in AGENT_CLASSES: r.register(cls(memory))
    return r
