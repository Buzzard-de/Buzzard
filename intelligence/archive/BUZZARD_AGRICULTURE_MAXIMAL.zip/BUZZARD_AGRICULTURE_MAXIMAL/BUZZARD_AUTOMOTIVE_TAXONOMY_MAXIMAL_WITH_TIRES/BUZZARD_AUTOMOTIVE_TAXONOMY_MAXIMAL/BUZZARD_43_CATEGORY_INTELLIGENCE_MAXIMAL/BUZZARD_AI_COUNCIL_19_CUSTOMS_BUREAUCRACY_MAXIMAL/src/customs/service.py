from .rules.engine import CustomsRulesEngine
from .documents.checklist import CustomsDocumentChecklist
from .alerts.risk import CustomsRiskEngine
from .models import CustomsAssessment

class CustomsBureaucracyAI:
    agent_id="customs_bureaucracy_ai"
    name="Customs & Bureaucracy AI"
    input_topics=["country","logistics","profit","supply","compliance","manufacturer","product","marketplace"]

    def __init__(self, rules, docs, risk):
        self.rules=rules; self.docs=docs; self.risk=risk

    def assess(self, route, profile):
        classification=self.rules.classify(profile)
        restriction=self.rules.restrictions(profile,route.destination)
        origin=self.rules.origin(profile,route.destination)
        risk=self.risk.assess(profile,route)
        documents=self.docs.required(route,profile)
        risks=list(risk["risks"])
        if restriction.get("restricted"): risks.append("destination_restriction")
        if classification["status"]!="verified": risks.append("classification_not_verified")
        human=bool(risks or restriction.get("human_review_required"))
        return CustomsAssessment(
            status="review_required" if human else "precheck_pass",
            product_id=profile.product_id,
            route=route,
            tariff_code=classification["code"],
            duties_estimate=None,
            import_tax_estimate=None,
            documents=documents,
            risks=sorted(set(risks)),
            evidence=profile.evidence,
            human_review_required=human,
            notes={
                "classification":classification["status"],
                "restriction":restriction.get("status","unknown"),
                "origin":origin.get("status","unknown")
            }
        )

    def analyze(self, objective, context, prior_findings):
        from src.council.contracts import AgentFinding
        return AgentFinding(
            agent_id=self.agent_id,
            topic="customs_bureaucracy",
            finding=f"Customs/bureaucracy screening for: {objective}",
            confidence=0.85,
            recommendations=[
                "verify HS/CN/TARIC classification against official sources",
                "verify origin and preferential treatment",
                "check destination restrictions and permits",
                "calculate landed cost only after verified rates"
            ],
            risks=["customs_rules_change","classification_or_origin_may_require_professional_review"],
            requires_human_approval=True
        )
