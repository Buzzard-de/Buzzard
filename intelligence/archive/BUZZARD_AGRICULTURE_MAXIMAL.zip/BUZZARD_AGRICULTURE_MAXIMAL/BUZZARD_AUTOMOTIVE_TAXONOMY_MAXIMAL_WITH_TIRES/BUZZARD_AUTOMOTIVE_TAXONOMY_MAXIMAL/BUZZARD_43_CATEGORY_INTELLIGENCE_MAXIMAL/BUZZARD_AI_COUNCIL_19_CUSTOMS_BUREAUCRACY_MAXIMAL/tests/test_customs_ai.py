
from src.customs.models import TradeRoute, ProductTradeProfile
from src.customs.calculators.landed_cost import LandedCostCalculator
from src.customs.alerts.risk import CustomsRiskEngine
from src.customs.documents.checklist import CustomsDocumentChecklist
from src.council.registry19 import build_registry19
def test_landed_cost():
    x=LandedCostCalculator().calculate(100,10,0,0.10,0.19,5)
    assert x["duty"]=="11.00" and x["landed_cost"]=="148.99"
def test_risk():
    r=CustomsRiskEngine().assess(ProductTradeProfile("p","battery charger"),TradeRoute("DE","TR"))
    assert "special_product_controls_possible" in r["risks"]
def test_documents():
    p=ProductTradeProfile("p","x",origin_country="DE",licenses=["license_check"])
    d=CustomsDocumentChecklist().required(TradeRoute("DE","TR"),p)
    assert "commercial_invoice" in d and "license_check" in d
def test_19th_agent():
    r=build_registry19()
    assert len(r.all())==19
    assert r.get("customs_bureaucracy_ai").name=="Customs & Bureaucracy AI"
