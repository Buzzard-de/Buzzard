from src.category_intelligence.registry import build_43_agents
from src.category_intelligence.agent import CategoryIntelligenceAgent
from src.category_intelligence.models import SellerOffer, CategoryNode
from src.category_intelligence.pricing.engine import PriceIntelligenceEngine
from src.category_intelligence.crawling.policy import PublicWebPolicy
from src.category_intelligence.opportunities.scoring import OpportunityScorer

def defs():
    return [{"category_id":f"C{i:02d}","name":f"Category {i}"} for i in range(1,44)]

def test_exactly_43_agents():
    agents=build_43_agents(defs())
    assert len(agents)==43

def test_agents_are_specialized():
    agents=build_43_agents(defs())
    assert agents["C01"].category_id=="C01"
    assert agents["C43"].category_id=="C43"
    assert agents["C01"] is not agents["C02"]

def test_price_engine():
    offers=[
        SellerOffer("s1","Seller 1","P1","Product",10),
        SellerOffer("s2","Seller 2","P1","Product",12),
        SellerOffer("s3","Seller 3","P2","Product 2",20),
    ]
    x=PriceIntelligenceEngine().seller_comparison(offers)
    assert x["summary"]["unique_sellers"]==3
    assert x["summary"]["min"]==10

def test_taxonomy_gap():
    a=CategoryNode("a","Our Category",1)
    b=CategoryNode("b","Competitor Subcategory",2,"a","competitor")
    agent=CategoryIntelligenceAgent("C01","Category 1")
    report=agent.analyze([], [a], [a,b])
    assert len(report.missing_categories)==1

def test_public_web_guardrail():
    p=PublicWebPolicy()
    assert p.allow("https://example.com",robots_allowed=True)[0]
    assert not p.allow("https://example.com",robots_allowed=False)[0]
    assert not p.allow("https://example.com",authenticated=True)[0]

def test_opportunity_score():
    s=OpportunityScorer().score(10,10,70,70,80,90,0,0)
    assert 0 <= s <= 100
