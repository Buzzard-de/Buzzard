from src.automotive_taxonomy.models import TaxonomyNode, VehicleProfile, ProductNode, FitmentRule
from src.automotive_taxonomy.catalog.engine import AutomotiveTaxonomy
from src.automotive_taxonomy.compatibility.selector import VehicleSelector
from src.automotive_taxonomy.compatibility.fitment import FitmentEngine
from src.automotive_taxonomy.validation.validator import AutomotiveTaxonomyValidator
from src.automotive_taxonomy.catalog.master_seed import MASTER_SYSTEMS

def build():
    nodes=[
      TaxonomyNode("auto","Otomotiv",1),
      TaxonomyNode("brakes","Fren Sistemi",2,"auto"),
      TaxonomyNode("pads","Fren Balataları",3,"brakes"),
      TaxonomyNode("front-pads","Ön Fren Balataları",4,"pads")
    ]
    return AutomotiveTaxonomy(nodes=nodes)

def test_master_seed_is_large():
    assert len(MASTER_SYSTEMS) >= 90

def test_path():
    t=build()
    assert [n.name for n in t.path("front-pads")] == [
        "Otomotiv","Fren Sistemi","Fren Balataları","Ön Fren Balataları"
    ]

def test_children():
    t=build()
    assert len(t.children("brakes"))==1

def test_vehicle_selector():
    v=VehicleProfile("v1","BMW","320d",year_from=2018,year_to=2020,engine_code="B47")
    s=VehicleSelector([v])
    assert len(s.select(make="BMW",model="320d",year=2019,engine_code="B47"))==1
    assert len(s.select(make="BMW",model="320d",year=2022))==0

def test_fitment():
    t=build()
    f=FitmentEngine(t)
    v=VehicleProfile("v1","BMW","320d")
    f.add_rule(FitmentRule("p1","v1","front","front","B47","verified","source",0.95))
    assert len(f.find(v,"p1","front"))==1

def test_validator():
    t=build()
    assert AutomotiveTaxonomyValidator().validate(t)==[]
