from src.automotive_taxonomy.tires.taxonomy import TIRE_TAXONOMY
from src.automotive_taxonomy.tires.service import TireIntelligence

def test_separate_category():
    assert "passenger_car" in TIRE_TAXONOMY
    assert "tractor" in TIRE_TAXONOMY
    assert "motorcycle" in TIRE_TAXONOMY
    assert "construction_industrial" in TIRE_TAXONOMY

def test_deep_tree():
    assert "summer" in TIRE_TAXONOMY["passenger_car"]["subcategories"]
    assert "UHP" in TIRE_TAXONOMY["passenger_car"]["subcategories"]["performance"]["sub_sub"]

def test_size():
    assert TireIntelligence().validate_size(205,55,16)["valid"]
    assert not TireIntelligence().validate_size(0,55,16)["valid"]
