# Buzzard Tarım & Tarım Makineleri

Ana kategori mantığı:
Tarım & Tarım Makineleri
→ Makine / ekipman / yedek parça / sarf
→ Alt kategori
→ Alt-alt kategori
→ Ürün
→ Makine uyumluluğu

Kapsam:
- Traktör
- Biçerdöver
- Balya
- Biçme
- Ekim
- Gübreleme
- İlaçlama
- Toprak işleme
- Hasat
- Yem/hayvancılık
- Römork/taşıma
- Sulama
- Sera
- Bağ/bahçe
- Tarım makineleri yedek parçaları
- Sarf/bakım
- Tarım ekipmanları
- El aletleri/atölye

Uyumluluk:
Makine tipi → marka → model → yıl → motor → motor kodu → sistem → parça.
