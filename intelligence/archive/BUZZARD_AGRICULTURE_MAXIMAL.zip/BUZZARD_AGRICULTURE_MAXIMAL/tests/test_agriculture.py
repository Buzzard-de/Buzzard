from src.agriculture.taxonomy.master import AGRICULTURE_TAXONOMY
from src.agriculture.service.catalog import AgricultureCatalogService
from src.agriculture.intelligence.market import AgricultureMarketSignals

def test_major_branches():
    for k in ["tractor","combine_harvester","spare_parts","consumables","irrigation","greenhouse","tools"]:
        assert k in AGRICULTURE_TAXONOMY

def test_deep_categories():
    assert "engine" in AGRICULTURE_TAXONOMY["spare_parts"]["subcategories"]
    assert "Piston" in AGRICULTURE_TAXONOMY["spare_parts"]["subcategories"]["engine"]["sub_sub"]

def test_catalog_service():
    s=AgricultureCatalogService(AGRICULTURE_TAXONOMY)
    assert s.list_subcategories("tractor")
    assert s.list_sub_subcategories("tractor","standard")

def test_market_score():
    x=AgricultureMarketSignals().score(90,60,80,85,10)
    assert 0<=x<=100
