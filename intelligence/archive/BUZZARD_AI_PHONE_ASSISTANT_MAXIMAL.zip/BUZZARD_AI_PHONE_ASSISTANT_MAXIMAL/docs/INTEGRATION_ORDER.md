# Deployment order

1. Create/verify business phone number.
2. Configure telephony/SIP provider.
3. Connect TelephonyAdapter.
4. Connect realtime voice adapter.
5. Connect PIM product_search.
6. Connect live inventory/price.
7. Connect TecDoc/compatibility source where applicable.
8. Connect order/lead tools.
9. Configure human handoff destination.
10. Run multilingual call tests.
11. Run failure/latency/load tests.
12. Enable production traffic gradually.

Do not activate real sales actions until authentication, authorization, audit logging,
payment/order safeguards and data-protection configuration are complete.
