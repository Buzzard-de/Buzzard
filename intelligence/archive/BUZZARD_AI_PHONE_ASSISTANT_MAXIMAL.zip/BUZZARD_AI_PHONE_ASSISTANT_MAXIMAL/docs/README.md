# BUZZARD AI PHONE ASSISTANT – MAXIMAL

## Architecture

Phone/SIP provider
→ Telephony Adapter
→ Realtime Voice Adapter
→ Language Router
→ Intent & Entity Layer
→ Agent Tool Gateway
→ PIM / Inventory / Compatibility / Orders
→ Response
→ Voice
→ Call Summary / CRM

## Multilingual
Uses the existing Buzzard multilingual layer. The phone agent does not maintain a
separate product vocabulary: it resolves user language into the same canonical
Product ID, Category ID and Attribute IDs used by the web/PIM/AI system.

## Live deployment
The package is integration-ready. Real calling requires a telephony/SIP provider,
verified phone number, credentials and production voice/realtime configuration.
No credentials are stored in this package.

## OpenAI integration
The adapter boundary is intentionally provider-neutral. OpenAI's API platform supports
audio and agentic application building; the actual production voice model/provider
should be selected and configured in the deployment environment.
