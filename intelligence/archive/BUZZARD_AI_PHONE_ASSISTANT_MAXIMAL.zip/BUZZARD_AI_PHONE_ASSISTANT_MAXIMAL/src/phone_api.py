from fastapi import FastAPI
from pydantic import BaseModel, Field
from .phone.language_router import detect_language, is_rtl
from .phone.intent import detect_intent, extract_entities
from .phone.session import CallSession
import uuid

app = FastAPI(title="BUZZARD AI Phone Assistant", version="1.0.0")

class AnalyzeRequest(BaseModel):
    text: str
    language: str | None = None

class AnalyzeResponse(BaseModel):
    call_id: str
    language: str
    rtl: bool
    intent: str
    entities: dict = Field(default_factory=dict)

@app.get("/api/phone/health")
def health():
    return {
        "service":"buzzard-ai-phone-assistant",
        "status":"ready",
        "telephony":"adapter-required",
        "realtime_voice":"adapter-required",
        "live_calling":"not_enabled_until_provider_configured"
    }

@app.post("/api/phone/analyze", response_model=AnalyzeResponse)
def analyze(req: AnalyzeRequest):
    lang=req.language or detect_language(req.text)
    s=CallSession(str(uuid.uuid4()), lang)
    s.state="intent"
    return AnalyzeResponse(
        call_id=s.call_id,
        language=lang,
        rtl=is_rtl(lang),
        intent=detect_intent(req.text),
        entities=extract_entities(req.text)
    )
