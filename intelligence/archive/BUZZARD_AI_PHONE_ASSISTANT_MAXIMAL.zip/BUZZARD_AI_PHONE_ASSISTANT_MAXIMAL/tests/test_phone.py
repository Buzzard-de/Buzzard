from src.phone.language_router import detect_language, is_rtl
from src.phone.intent import detect_intent

def test_arabic():
    assert detect_language("أريد البحث عن منتج") == "ar"
    assert is_rtl("ar")

def test_german_intent():
    assert detect_intent("Haben Sie diesen Artikel auf Lager?") == "availability"

def test_human_handoff():
    assert detect_intent("Ich möchte mit einem Mitarbeiter sprechen") == "human"
