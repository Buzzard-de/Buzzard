# BUZZARD CATEGORY AUDIT MAXIMAL

Amaç: canlı Buzzard24 kategorileri ile 48 ana kategorilik Master Taxonomy'yi
güvenli biçimde karşılaştırmak.

Aksiyonlar:
KEEP / MOVE_CONTENT / RESTRUCTURE / SEPARATE / REVIEW

DELETE bilinçli olarak kapalıdır.

Not: Bu paket canlı siteyi kendiliğinden değiştirmez. Tam 41 canlı kategori
exportu sisteme verildiğinde audit engine kesin mapping raporu üretir.
