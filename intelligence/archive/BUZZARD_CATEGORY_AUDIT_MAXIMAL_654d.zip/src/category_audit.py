import json,re
from pathlib import Path

def norm(s):
    s=s.casefold().replace("ä","a").replace("ö","o").replace("ü","u").replace("ß","ss")
    return re.sub(r"\s+"," ",re.sub(r"[^a-z0-9çğıöşü\s&-]"," ",s)).strip()

class CategoryAuditEngine:
    ACTIONS={"KEEP","MOVE_CONTENT","RESTRUCTURE","SEPARATE","REVIEW"}
    def __init__(self,master_path,live_path,policy_path):
        self.master=json.loads(Path(master_path).read_text(encoding="utf-8"))
        self.live=json.loads(Path(live_path).read_text(encoding="utf-8"))["categories"]
        self.policy=json.loads(Path(policy_path).read_text(encoding="utf-8"))
    def mains(self):
        return [n for n in self.master["nodes"] if n["level"]==1]
    def exact(self,name):
        q=norm(name)
        return [n for n in self.mains() if norm(n["name"])==q]
    def recommendation(self,item):
        name=item["name"]; q=norm(name)
        if name in self.policy:
            p=self.policy[name]
            return {"action":p["action"],"target":p["target"],
                    "reason":"Explicitly approved category-audit rule."}
        if self.exact(name):
            return {"action":"KEEP","target":self.exact(name)[0]["name"],
                    "reason":"Exact canonical Master match."}
        if "reifen" in q or "felgen" in q:
            return {"action":"MOVE_CONTENT","target":"Lastikler – Tüm Motorlu Araçlar",
                    "reason":"Tire/wheel content belongs to the dedicated tire ecosystem."}
        if "landwirtschaft" in q or "agrartechnik" in q:
            return {"action":"RESTRUCTURE","target":"Tarım & Tarım Makineleri",
                    "reason":"Agriculture content belongs to the canonical agriculture ecosystem."}
        if "baumaschinen" in q:
            return {"action":"RESTRUCTURE","target":"İnşaat & İnşaat Makineleri",
                    "reason":"Construction-machine content belongs to the canonical construction ecosystem."}
        return {"action":"REVIEW","target":None,
                "reason":"No safe deterministic mapping; human/category-AI review required."}
    def audit(self):
        return [{**x,**self.recommendation(x)} for x in self.live]
    def validate(self):
        assert len(self.mains())==48
        assert all(x["action"] in self.ACTIONS for x in self.audit())
        assert all(x["action"]!="DELETE" for x in self.audit())
        return True
