from src.category_audit import CategoryAuditEngine

def e():
    return CategoryAuditEngine("data/taxonomy.json","data/live_categories_INPUT.json","data/audit_policy.json")

def test_master_48():
    assert len(e().mains())==48

def test_tire_move():
    r=[x for x in e().audit() if x["name"]=="Reifen & Felgen"][0]
    assert r["action"]=="MOVE_CONTENT"
    assert r["target"]=="Lastikler – Tüm Motorlu Araçlar"

def test_agriculture():
    r=[x for x in e().audit() if x["name"]=="Landwirtschaft & Agrartechnik"][0]
    assert r["action"]=="RESTRUCTURE"

def test_construction():
    r=[x for x in e().audit() if x["name"]=="Baumaschinen & Ersatzteile"][0]
    assert r["action"]=="RESTRUCTURE"

def test_no_delete():
    assert all(x["action"]!="DELETE" for x in e().audit())

def test_unknown_is_safe_review():
    r=[x for x in e().audit() if x["name"]=="Textil"][0]
    assert r["action"] in {"KEEP","REVIEW"}
