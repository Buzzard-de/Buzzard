from src.livestock.taxonomy.master import LIVESTOCK_TAXONOMY
from src.livestock.catalog import LivestockCatalog
from src.livestock.intelligence.opportunity import LivestockOpportunity

def test_main_groups():
    for k in ["cattle","sheep_goat","poultry","horse","beekeeping","aquaculture","machinery","automation"]:
        assert k in LIVESTOCK_TAXONOMY

def test_deep_taxonomy():
    assert "dairy" in LIVESTOCK_TAXONOMY["cattle"]["subcategories"]
    assert "Sağım" in LIVESTOCK_TAXONOMY["cattle"]["subcategories"]["dairy"]["sub_sub"]
    assert "Vakum Pompası" in LIVESTOCK_TAXONOMY["milking"]["subcategories"]["vacuum"]["sub_sub"]

def test_catalog():
    c=LivestockCatalog(LIVESTOCK_TAXONOMY)
    assert c.subcategories("cattle")
    assert c.sub_subcategories("cattle","dairy")

def test_score():
    s=LivestockOpportunity().score(90,80,85,75,70,10)
    assert 0<=s<=100
