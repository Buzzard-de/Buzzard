# BUZZARD MAIN COLUMN – 48 CATEGORY ENGINE

Bu paket, BUZZARD web sayfasındaki ana kategori/mega-menü sütununu
48 ana kategori, 796 alt kategori ve 6.411 alt-alt kategoriye bağlar.

Dosyalar:
- `index.html` — doğrudan tarayıcıda açılabilen responsive demo
- `data/taxonomy.json` — UI veri kaynağı
- `src/BuzzardCategoryMainColumn.jsx` — React/Next.js entegrasyon komponenti
- `docs/INTEGRATION.md` — entegrasyon notları
