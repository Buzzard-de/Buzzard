# BUZZARD MASTER TAXONOMY — 48 MAXIMAL

Kesinleştirilmiş birleşik master:
- 48 ana kategori
- 796 alt kategori
- 6.411 alt-alt kategori
- 7.255 toplam taxonomy node

43 doğrulanmış eski ana kategori korunmuş; sonradan ayrı ana kategori olarak
eklenen 5 alan aynı üç seviyeli yapıya normalize edilmiştir.

Canlı satış, ödeme hesabı veya gerçek API kimlik bilgileri içermez.
