from src.taxonomy_service import BuzzardMasterTaxonomy

def test_counts():
    assert BuzzardMasterTaxonomy().counts()=={
        "main_categories":48,
        "subcategories":796,
        "sub_subcategories":6411,
        "total_nodes":7255
    }

def test_integrity():
    assert BuzzardMasterTaxonomy().validate()

def test_new_categories():
    t=BuzzardMasterTaxonomy()
    for x in [
        "Lastikler – Tüm Motorlu Araçlar",
        "Tarım & Tarım Makineleri",
        "Hayvancılık",
        "Güneş & Rüzgâr Enerjisi",
        "İnşaat & İnşaat Makineleri"
    ]:
        assert t.search(x)

def test_tire_children():
    assert len(BuzzardMasterTaxonomy().children("bz.44"))==52
