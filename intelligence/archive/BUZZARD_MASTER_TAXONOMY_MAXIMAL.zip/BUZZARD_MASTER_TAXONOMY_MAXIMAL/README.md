# BUZZARD MASTER TAXONOMY – MAXIMAL

Bu paket, konuşmada onaylanan 43 ana kategoriyi tek bir üretime hazır taxonomy çekirdeğinde toplar.

## Hiyerarşi
Hauptkategorie → Unterkategorie → Unter-Unterkategorie → Produkt

## İçerik
- `data/taxonomy.json` – ana veri kaynağı
- `data/taxonomy.csv` – PIM/ERP/import için tablo
- `docs/MASTER_TAXONOMY.md` – okunabilir tam ağaç
- `src/taxonomy_service.py` – arama, çocuklar ve path servisleri
- `src/api.py` – FastAPI entegrasyon örneği
- `tests/test_taxonomy.py` – bütünlük testleri

## Üretim notu
Bu taxonomy genişletilebilir tasarlanmıştır. Gerçek tedarikçi/TecDoc/marketplace verileri geldikçe yeni düğümler eklenir; mevcut ID'ler korunur.
