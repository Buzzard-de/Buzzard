from fastapi import FastAPI, HTTPException, Query
from .taxonomy_service import all_nodes, get_node, children, search, path

app = FastAPI(title="BUZZARD Master Taxonomy API", version="1.0.0")

@app.get("/api/taxonomy")
def taxonomy():
    return {"count": len(all_nodes()), "nodes": all_nodes()}

@app.get("/api/categories")
def categories(level: int = Query(1, ge=1, le=3)):
    return [n for n in all_nodes() if n["level"] == level]

@app.get("/api/category/{node_id}")
def category(node_id: str):
    n=get_node(node_id)
    if not n: raise HTTPException(404, "Category not found")
    return {"node":n, "children":children(node_id), "path":path(node_id)}

@app.get("/api/search")
def category_search(q: str = Query(..., min_length=1)):
    return search(q)
