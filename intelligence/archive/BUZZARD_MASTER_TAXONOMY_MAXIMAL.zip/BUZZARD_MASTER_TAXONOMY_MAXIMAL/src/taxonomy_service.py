import json
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "data" / "taxonomy.json"

def load():
    return json.loads(DATA.read_text(encoding="utf-8"))

def all_nodes():
    return load()["nodes"]

def get_node(node_id):
    return next((n for n in all_nodes() if n["id"] == node_id), None)

def children(parent_id):
    return [n for n in all_nodes() if n["parent_id"] == parent_id]

def search(term):
    t = term.casefold()
    return [n for n in all_nodes() if t in n["name"].casefold() or t in n["slug"].casefold()]

def path(node_id):
    result=[]
    cur=get_node(node_id)
    while cur:
        result.append(cur)
        cur=get_node(cur["parent_id"]) if cur["parent_id"] else None
    return list(reversed(result))
