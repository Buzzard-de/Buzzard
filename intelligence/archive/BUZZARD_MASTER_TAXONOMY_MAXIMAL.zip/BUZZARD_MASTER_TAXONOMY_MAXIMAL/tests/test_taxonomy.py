import json
from pathlib import Path

DATA = Path(__file__).parents[1] / "data" / "taxonomy.json"

def test_taxonomy_integrity():
    data=json.loads(DATA.read_text(encoding="utf-8"))
    nodes=data["nodes"]
    assert data["master_category_count"] == 43
    assert len([n for n in nodes if n["level"] == 1]) == 43
    assert len({n["id"] for n in nodes}) == len(nodes)
    assert len({n["slug"] for n in nodes}) == len(nodes)
    ids={n["id"] for n in nodes}
    for n in nodes:
        if n["parent_id"]:
            assert n["parent_id"] in ids
