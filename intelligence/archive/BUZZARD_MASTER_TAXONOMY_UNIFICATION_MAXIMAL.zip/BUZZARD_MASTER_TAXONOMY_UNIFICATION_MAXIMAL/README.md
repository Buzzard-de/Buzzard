# BUZZARD MASTER TAXONOMY UNIFICATION MAXIMAL

Amaç: Shop (41-root) ve Intelligence (43-root) taxonomy sistemlerini tek canonical
BUZZARD_MASTER_TAXONOMY altında birleştirmek.

## Kural
- 43 canonical root vardır.
- Eski Shop/Intelligence ID'leri silinmez; alias/migration mapping ile canonical ID'ye bağlanır.
- Ürünler, siparişler, analytics ve AI indeksleri canonical ID'ye geçirilir.
- Legacy alias'lar geriye dönük uyumluluk için tutulur.

## Dosyalar
- data/canonical_taxonomy.json
- data/category_id_mapping.csv
- docs/MIGRATION.sql
- src/taxonomy_service.py
- src/api.py
- tests/test_taxonomy.py

Bu paket gerçek canlı veriyi kendiliğinden deploy etmez; Cursor/CI/CD üzerinde mevcut repo ve veritabanına uygulanacak migration paketidir.
