from fastapi import FastAPI, HTTPException
from .taxonomy_service import load, roots, children, get, path
app=FastAPI(title='BUZZARD Canonical Taxonomy API',version='2.0.0')
@app.get('/api/taxonomy/status')
def status():
    d=load(); return {'canonical_roots':d['master_root_count'],'nodes':len(d['nodes']),'status':'ready'}
@app.get('/api/taxonomy/roots')
def taxonomy_roots(): return roots()
@app.get('/api/taxonomy/{node_id}')
def taxonomy_node(node_id:str):
    n=get(node_id)
    if not n: raise HTTPException(404,'Category not found')
    return {'node':n,'children':children(node_id),'path':path(node_id)}
