import json
from pathlib import Path

DATA=Path(__file__).resolve().parents[1]/'data/canonical_taxonomy.json'
def load(): return json.loads(DATA.read_text(encoding='utf-8'))
def roots(): return [n for n in load()['nodes'] if n['level']==1]
def children(parent_id): return [n for n in load()['nodes'] if n['parent_id']==parent_id]
def get(node_id): return next((n for n in load()['nodes'] if n['id']==node_id),None)
def path(node_id):
    out=[]; n=get(node_id)
    while n:
        out.append(n); n=get(n['parent_id']) if n.get('parent_id') else None
    return list(reversed(out))
