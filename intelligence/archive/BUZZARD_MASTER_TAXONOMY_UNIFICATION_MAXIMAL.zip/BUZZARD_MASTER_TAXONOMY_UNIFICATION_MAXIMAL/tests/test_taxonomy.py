import json
from pathlib import Path
DATA=Path(__file__).parents[1]/'data/canonical_taxonomy.json'
def test_canonical_integrity():
    d=json.loads(DATA.read_text(encoding='utf-8')); ns=d['nodes']
    assert d['master_root_count']==43
    roots=[n for n in ns if n['level']==1]
    assert len(roots)==43
    ids={n['id'] for n in ns}
    assert len(ids)==len(ns)
    assert len({n['slug'] for n in ns})==len(ns)
    assert all(n['parent_id'] is None or n['parent_id'] in ids for n in ns)
