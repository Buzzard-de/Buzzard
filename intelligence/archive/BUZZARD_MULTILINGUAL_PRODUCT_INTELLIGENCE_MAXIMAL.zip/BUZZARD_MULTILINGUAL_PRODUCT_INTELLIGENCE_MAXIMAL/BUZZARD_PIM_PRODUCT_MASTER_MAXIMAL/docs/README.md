# BUZZARD PIM / PRODUCT MASTER MAXIMAL
Tek Product Master kaynağı.
Ürün kimliği → canonical kategori → teknik özellikler → çok dilli içerik → varyantlar → medya → ilişkiler → kalite workflow.
Tedarikçi akışı: CSV/XML/JSON/API → snapshot → normalize → duplicate → kategori/attribute mapping → quality gate → review → publish.
Operasyonel stok, sipariş, ödeme ve finans gerçekleri commerce/ERP katmanında kalır.
