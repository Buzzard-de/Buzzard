from fastapi import FastAPI
import json
from pathlib import Path
app=FastAPI(title="BUZZARD PIM Product Master API",version="1.0.0")
ROOT=Path(__file__).parents[1]
@app.get("/api/pim/health")
def health():
 d=json.loads((ROOT/"data/taxonomy.json").read_text(encoding="utf-8"))
 return {"service":"pim","status":"ready","canonical_main_categories":len([n for n in d["nodes"] if n["level"]==1])}
@app.get("/api/pim/schema")
def schema():
 return json.loads((ROOT/"schemas/product_master.json").read_text(encoding="utf-8"))
