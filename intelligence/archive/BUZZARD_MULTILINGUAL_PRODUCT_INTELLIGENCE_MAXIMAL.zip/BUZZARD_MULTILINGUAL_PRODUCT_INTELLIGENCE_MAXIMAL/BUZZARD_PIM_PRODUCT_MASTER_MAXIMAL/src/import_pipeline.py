import json,hashlib
def normalize(raw):
 return {"supplier_sku":str(raw.get("supplier_sku") or raw.get("sku") or "").strip(),
 "brand":str(raw.get("brand") or "").strip(),"mpn":str(raw.get("mpn") or "").strip(),
 "gtin":str(raw.get("gtin") or raw.get("ean") or "").strip(),
 "title":str(raw.get("title") or raw.get("name") or "").strip(),
 "category_hint":str(raw.get("category_hint") or raw.get("category") or "").strip(),"raw":raw}
def dedupe_key(r):
 if r["gtin"]: return "gtin:"+r["gtin"]
 if r["brand"] and r["mpn"]: return "brand-mpn:"+r["brand"].casefold()+"|"+r["mpn"].casefold()
 return "supplier-sku:"+r["supplier_sku"]
def process(records):
 seen=set(); accepted=[]; duplicates=[]
 for raw in records:
  r=normalize(raw); k=dedupe_key(r)
  (duplicates if k in seen else accepted).append(r); seen.add(k)
 return {"accepted_candidates":accepted,"duplicates":duplicates}
