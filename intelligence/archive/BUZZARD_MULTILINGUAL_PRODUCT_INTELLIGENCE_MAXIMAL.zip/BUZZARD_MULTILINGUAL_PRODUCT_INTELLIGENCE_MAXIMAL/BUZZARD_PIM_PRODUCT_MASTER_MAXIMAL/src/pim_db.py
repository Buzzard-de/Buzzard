import sqlite3, uuid, datetime
from pathlib import Path
DB=Path(__file__).parents[1]/"data"/"buzzard_pim.sqlite3"
SCHEMA="""
CREATE TABLE IF NOT EXISTS products(
 product_id TEXT PRIMARY KEY, parent_product_id TEXT, sku TEXT UNIQUE NOT NULL,
 gtin TEXT, mpn TEXT, brand_id TEXT, manufacturer_id TEXT,
 canonical_category_id TEXT NOT NULL, product_type TEXT, attribute_set_id TEXT,
 status TEXT NOT NULL DEFAULT 'draft', quality_score INTEGER DEFAULT 0,
 completeness_score INTEGER DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS product_i18n(
 product_id TEXT, language TEXT, title TEXT, short_description TEXT,
 long_description TEXT, seo_title TEXT, seo_description TEXT, slug TEXT,
 PRIMARY KEY(product_id,language));
CREATE TABLE IF NOT EXISTS product_attributes(
 product_id TEXT, attribute_key TEXT, value_json TEXT,
 PRIMARY KEY(product_id,attribute_key));
CREATE TABLE IF NOT EXISTS product_media(
 media_id TEXT PRIMARY KEY, product_id TEXT, media_type TEXT, uri TEXT, sort_order INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS supplier_products(
 supplier_product_id TEXT PRIMARY KEY, supplier_id TEXT, supplier_sku TEXT,
 product_id TEXT, gtin TEXT, mpn TEXT, raw_snapshot_json TEXT,
 status TEXT DEFAULT 'imported', UNIQUE(supplier_id,supplier_sku));
CREATE TABLE IF NOT EXISTS product_relationships(
 product_id TEXT, related_product_id TEXT, relation_type TEXT,
 PRIMARY KEY(product_id,related_product_id,relation_type));
CREATE TABLE IF NOT EXISTS import_runs(
 import_run_id TEXT PRIMARY KEY, supplier_id TEXT, source_type TEXT,
 source_name TEXT, started_at TEXT, finished_at TEXT,
 received_count INTEGER DEFAULT 0, accepted_count INTEGER DEFAULT 0,
 rejected_count INTEGER DEFAULT 0, duplicate_count INTEGER DEFAULT 0, status TEXT);
"""
def connect():
 c=sqlite3.connect(DB); c.executescript(SCHEMA); return c
