def validate_product(p):
    errors=[]; warnings=[]
    for k in ("sku","canonical_category_id"):
        if not p.get(k): errors.append("MISSING:"+k)
    if p.get("canonical_category_id") and not p["canonical_category_id"].startswith("bz."):
        errors.append("CATEGORY_NOT_CANONICAL")
    for k in ("gtin","mpn","brand_id","title","images"):
        if not p.get(k): warnings.append("MISSING_RECOMMENDED:"+k)
    return {"valid":not errors,"errors":errors,"warnings":warnings,
            "quality_score":max(0,100-len(errors)*25-len(warnings)*5)}
