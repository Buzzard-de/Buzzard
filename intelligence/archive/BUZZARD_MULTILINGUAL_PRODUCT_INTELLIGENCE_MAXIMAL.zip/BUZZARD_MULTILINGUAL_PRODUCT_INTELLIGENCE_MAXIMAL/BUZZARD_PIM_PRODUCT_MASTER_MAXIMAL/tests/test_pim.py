import json
from pathlib import Path
def test_schema():
 s=json.loads((Path(__file__).parents[1]/"schemas/product_master.json").read_text())
 assert s["entity"]=="ProductMaster"
def test_taxonomy():
 d=json.loads((Path(__file__).parents[1]/"data/taxonomy.json").read_text())
 assert len([n for n in d["nodes"] if n["level"]==1])==43
def test_template(): assert (Path(__file__).parents[1]/"data/product_import_template.csv").exists()
