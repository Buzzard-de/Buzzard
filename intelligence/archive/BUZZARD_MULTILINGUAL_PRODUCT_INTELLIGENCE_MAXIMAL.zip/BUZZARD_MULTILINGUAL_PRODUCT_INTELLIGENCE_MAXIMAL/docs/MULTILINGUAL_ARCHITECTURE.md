# BUZZARD MULTILINGUAL PRODUCT INTELLIGENCE

Ürün tek bir canonical Product ID ile tutulur. Dil sadece ürünün içerik/arama/AI temsilidir.

Kullanıcı Almanca, Türkçe, Arapça, İsveççe veya başka desteklenen bir dille arasa da:
Dil tespiti → normalize et → eş anlamlıları genişlet → canonical entity/category/attribute çöz → aynı ürünü bul → kullanıcı dilinde cevapla.

Arapça için RTL desteği vardır.

Çeviri belleği ve terminoloji sözlüğü sayesinde teknik ürün adları, OEM/MPN, marka ve kategori isimleri rastgele çevrilmez; canonical ID'lere bağlanır.

Hukuki, güvenlik, tıbbi ve teknik uyumluluk metinlerinde insan onayı gereklidir.
