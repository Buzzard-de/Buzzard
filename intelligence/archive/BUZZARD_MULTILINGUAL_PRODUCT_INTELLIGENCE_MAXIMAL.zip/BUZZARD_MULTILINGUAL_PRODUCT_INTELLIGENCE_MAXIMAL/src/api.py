from fastapi import FastAPI
from .language_service import supported_languages, normalize_request
app=FastAPI(title="BUZZARD Multilingual Product Intelligence",version="1.0.0")
@app.get("/api/languages")
def languages(): return {"count":len(supported_languages()),"languages":supported_languages()}
@app.post("/api/language/normalize")
def normalize(payload:dict): return normalize_request(payload.get("text",""),payload.get("language"))
