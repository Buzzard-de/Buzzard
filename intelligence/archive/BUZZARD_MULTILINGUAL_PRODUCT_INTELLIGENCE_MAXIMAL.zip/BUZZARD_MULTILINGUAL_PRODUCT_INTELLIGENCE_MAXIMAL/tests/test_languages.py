import json
from pathlib import Path
def test_language_count():
 d=json.loads((Path(__file__).parents[1]/"data/languages.json").read_text())
 assert d["supported_count"] >= 50
def test_arabic_rtl():
 d=json.loads((Path(__file__).parents[1]/"data/languages.json").read_text())
 assert any(x["code"]=="ar" and x["rtl"] for x in d["languages"])
def test_groups():
 d=json.loads((Path(__file__).parents[1]/"data/languages.json").read_text())
 assert set(["Europe","Nordic","Balkans","Arab"]).issubset(set(d["groups"]))
