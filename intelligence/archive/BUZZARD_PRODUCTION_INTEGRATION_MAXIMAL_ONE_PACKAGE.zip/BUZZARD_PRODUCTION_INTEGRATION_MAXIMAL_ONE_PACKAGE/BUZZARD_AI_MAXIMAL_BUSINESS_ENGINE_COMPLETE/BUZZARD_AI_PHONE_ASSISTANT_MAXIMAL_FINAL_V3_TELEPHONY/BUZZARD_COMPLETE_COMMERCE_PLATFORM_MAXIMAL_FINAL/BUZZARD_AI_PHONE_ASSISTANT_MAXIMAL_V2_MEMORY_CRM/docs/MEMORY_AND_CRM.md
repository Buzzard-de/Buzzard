# Telefon Asistanı V2 – Hafıza & CRM
Session memory = mevcut görüşme.
Customer memory = doğrulanmış ve izin verilen geçmiş bağlam.
Örnekler: tercih edilen dil, önceki görüşme özeti, açık talepler.
Kimlik doğrulanmadan özel sipariş/müşteri bilgileri açılmaz.
Şifre, ödeme bilgisi ve gereksiz hassas bilgiler hafızaya alınmaz.
Görüşme kaydı varsayılan kapalıdır; saklama süreleri ve hukuki dayanak production'da yapılandırılmalıdır.
