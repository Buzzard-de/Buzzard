import hashlib,json,uuid
from .store import connect,now
class CustomerMemory:
 def __init__(self,con=None): self.con=con or connect()
 def hash_phone(self,phone): return hashlib.sha256("".join(x for x in (phone or "") if x.isdigit() or x=="+").encode()).hexdigest()
 def find_or_create(self,phone,language="de",display_name=None):
  h=self.hash_phone(phone); r=self.con.execute("SELECT customer_id FROM customers WHERE phone_hash=?",(h,)).fetchone()
  if r:return r[0]
  cid=str(uuid.uuid4()); self.con.execute("INSERT INTO customers VALUES(?,?,?,?,?,?,?)",(cid,h,language,display_name,now(),now(),"active")); self.con.commit(); return cid
 def save_fact(self,cid,key,value,call_id=None,confidence=1.0,approved=False,expires_at=None):
  self.con.execute("""INSERT INTO memory_facts VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(customer_id,fact_key) DO UPDATE SET fact_value=excluded.fact_value,confidence=excluded.confidence,source_call_id=excluded.source_call_id,approved=excluded.approved,expires_at=excluded.expires_at""",(str(uuid.uuid4()),cid,key,json.dumps(value,ensure_ascii=False),confidence,call_id,int(approved),now(),expires_at)); self.con.commit()
 def approved_facts(self,cid):
  return [{"key":k,"value":json.loads(v),"confidence":c} for k,v,c in self.con.execute("SELECT fact_key,fact_value,confidence FROM memory_facts WHERE customer_id=? AND approved=1",(cid,))]
 def log_call(self,call_id,cid,language,outcome,summary):
  self.con.execute("INSERT OR REPLACE INTO calls VALUES(?,?,?,?,?,?,?)",(call_id,cid,language,now(),now(),outcome,summary)); self.con.commit()
 def recent_calls(self,cid,limit=5):
  return [{"call_id":a,"language":b,"started_at":c,"outcome":d,"summary":e} for a,b,c,d,e in self.con.execute("SELECT call_id,language,started_at,outcome,summary FROM calls WHERE customer_id=? ORDER BY started_at DESC LIMIT ?",(cid,limit))]
