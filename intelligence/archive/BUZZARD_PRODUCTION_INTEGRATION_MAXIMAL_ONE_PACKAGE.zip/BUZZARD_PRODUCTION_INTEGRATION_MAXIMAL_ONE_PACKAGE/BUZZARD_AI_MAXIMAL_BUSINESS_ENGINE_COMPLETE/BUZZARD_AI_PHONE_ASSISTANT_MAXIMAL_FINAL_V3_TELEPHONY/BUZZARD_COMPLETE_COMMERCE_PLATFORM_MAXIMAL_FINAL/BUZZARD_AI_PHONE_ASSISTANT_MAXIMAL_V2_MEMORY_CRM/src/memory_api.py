from fastapi import FastAPI
from pydantic import BaseModel
from .memory.service import CustomerMemory
from .memory.crm_context import build_agent_context
app=FastAPI(title="BUZZARD Phone Memory & CRM Context",version="2.0.0")
memory=CustomerMemory()
class CustomerRequest(BaseModel):
 phone:str; language:str="de"; display_name:str|None=None
@app.post("/api/phone-memory/customer")
def customer(req:CustomerRequest): return {"customer_id":memory.find_or_create(req.phone,req.language,req.display_name)}
@app.get("/api/phone-memory/context/{customer_id}")
def context(customer_id:str,verification_level:str="none"): return build_agent_context(memory,customer_id,verification_level)
