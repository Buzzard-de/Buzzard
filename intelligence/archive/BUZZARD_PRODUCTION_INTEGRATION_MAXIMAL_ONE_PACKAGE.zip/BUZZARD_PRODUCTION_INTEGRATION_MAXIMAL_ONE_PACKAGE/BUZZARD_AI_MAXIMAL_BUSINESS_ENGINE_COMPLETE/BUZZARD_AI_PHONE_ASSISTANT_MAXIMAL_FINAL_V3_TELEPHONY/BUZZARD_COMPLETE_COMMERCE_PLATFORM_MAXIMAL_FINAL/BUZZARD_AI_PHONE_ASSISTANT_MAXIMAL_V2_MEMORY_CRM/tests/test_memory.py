from src.memory.store import connect
from src.memory.service import CustomerMemory
def test_memory():
 m=CustomerMemory(connect()); cid=m.find_or_create("+491234567890","de"); m.save_fact(cid,"preferred_language","de",approved=True)
 assert any(x["key"]=="preferred_language" for x in m.approved_facts(cid))
