class MarketplaceSyndicator:
 def __init__(self,adapters): self.adapters=adapters
 def publish(self,product,channels):
  return {c:(self.adapters[c].upsert_product(product) if c in self.adapters else {"status":"not_configured"}) for c in channels}
