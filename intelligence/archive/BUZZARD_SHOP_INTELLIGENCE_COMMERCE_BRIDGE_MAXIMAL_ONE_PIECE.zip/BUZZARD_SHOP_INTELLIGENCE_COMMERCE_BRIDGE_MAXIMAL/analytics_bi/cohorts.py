class CohortEngine:
    def build(self, customers):
        result={}
        for c in customers:
            cohort=c.get("cohort","unknown")
            result.setdefault(cohort,{"customers":0,"revenue":0.0})
            result[cohort]["customers"]+=1
            result[cohort]["revenue"]+=float(c.get("revenue",0))
        for x in result.values():
            x["revenue"]=round(x["revenue"],2)
            x["revenue_per_customer"]=round(x["revenue"]/x["customers"],2) if x["customers"] else 0
        return result
