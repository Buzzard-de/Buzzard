class ExecutiveDashboard:
    def render(self, kpis, alerts=None):
        return {
            "kpis": {k.name: {"value":k.value,"unit":k.unit,"target":k.target} for k in kpis},
            "alerts": [a.__dict__ for a in (alerts or [])]
        }
