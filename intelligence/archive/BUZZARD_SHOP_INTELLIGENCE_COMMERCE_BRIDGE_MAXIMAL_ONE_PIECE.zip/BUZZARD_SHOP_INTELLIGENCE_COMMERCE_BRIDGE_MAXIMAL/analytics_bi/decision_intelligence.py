class DecisionIntelligence:
    def recommend(self, snapshot):
        k=snapshot.get("kpis",{})
        gp=k.get("gross_profit",{}).get("value",0)
        roas=k.get("ad_roas",{}).get("value",0)
        rr=k.get("return_rate",{}).get("value",0)
        if gp < 0:
            return "PROTECT_CASH_AND_REVIEW_COSTS"
        if rr > 0.10:
            return "INVESTIGATE_RETURNS"
        if roas > 3:
            return "SCALE_PROFITABLE_MARKETING"
        return "OPTIMIZE_AND_MONITOR"
