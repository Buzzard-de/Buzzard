from analytics_bi.metrics import revenue,costs,gross_profit,order_count,refund_total,return_rate,ad_roas
from analytics_bi.profitability import product_profit
from analytics_bi.forecast import forecast_next
from analytics_bi.alerts import AlertEngine
from analytics_bi.dashboard import ExecutiveDashboard
from analytics_bi.models import KPI

class AnalyticsBIEngine:
    def __init__(self):
        self.alerts=AlertEngine()
        self.dashboard=ExecutiveDashboard()

    def kpis(self,events):
        r=revenue(events); c=costs(events); gp=gross_profit(events)
        return [
            KPI("revenue",r,"EUR"),
            KPI("costs",c,"EUR"),
            KPI("gross_profit",gp,"EUR"),
            KPI("orders",order_count(events),"count"),
            KPI("refunds",refund_total(events),"EUR"),
            KPI("return_rate",return_rate(events),"ratio"),
            KPI("ad_roas",ad_roas(events),"x")
        ]

    def dashboard_snapshot(self,events):
        kpis=self.kpis(events)
        alerts=[]
        margin=(gross_profit(events)/revenue(events)) if revenue(events) else 0
        a=self.alerts.low_margin(margin)
        if a: alerts.append(a)
        rr=return_rate(events)
        a=self.alerts.high_return_rate(rr)
        if a: alerts.append(a)
        return self.dashboard.render(kpis,alerts)
