def rank_products(products):
    return sorted(products,key=lambda p:float(p.get("profit",0)),reverse=True)

def rank_suppliers(suppliers):
    return sorted(suppliers,key=lambda s:float(s.get("score",0)),reverse=True)
