from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from core.settings import settings
from api.service import BuzzardService
from monitoring.health import health
from commerce.api.routes import router as commerce_router
from web.storefront_api import router as storefront_router
from api.production_routes import router as production_router

app = FastAPI(title="Buzzard AI API", version="1.0")
service = BuzzardService()
app.include_router(commerce_router)
app.include_router(storefront_router)
app.include_router(production_router)

class TaskRequest(BaseModel):
    task_id: str
    objective: str
    priority: str = "NORMAL"

def authorize(token):
    if settings.api_token and token != settings.api_token:
        raise HTTPException(status_code=401, detail="Unauthorized")

@app.get("/health")
def get_health():
    return health()

@app.post("/tasks")
def create_task(req: TaskRequest, authorization: str | None = Header(default=None)):
    authorize(authorization)
    return service.submit(req.task_id, req.objective, req.priority)
