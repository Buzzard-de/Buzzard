from fastapi import APIRouter
from production.integrations import IntegrationRegistry
from production.marketplaces import EbayAdapter, AmazonAdapter
from production.payments import GenericPaymentAdapter
from production.shipping import GenericCarrierAdapter
from production.automotive import TecDocAdapter
from production.agents import AgentRuntime
from production.readiness import ProductionReadiness

router=APIRouter(prefix="/production",tags=["production"])

def registry():
    r=IntegrationRegistry()
    for adapter in [EbayAdapter(),AmazonAdapter(),GenericPaymentAdapter(),GenericCarrierAdapter(),TecDocAdapter()]:
        req=adapter.integration.required_env
        r.register(adapter.integration.name,*req)
    r.register("llm","LLM_API_URL","LLM_API_KEY","LLM_MODEL")
    return r

@router.get("/integrations")
def integrations():
    return registry().status()

@router.get("/agents")
def agents():
    return AgentRuntime().status()

@router.get("/readiness")
def readiness():
    statuses=registry().status()
    payment=statuses["payment"]["status"]=="CONFIGURED"
    shipping=statuses["carrier"]["status"]=="CONFIGURED"
    ai=AgentRuntime().llm.status()["status"]=="CONFIGURED"
    return ProductionReadiness().evaluate(statuses,0,payment,shipping,ai)
