class IncidentManager:
    def __init__(self):
        self.incidents=[]

    def open(self,severity,title,details=None):
        incident={"id":len(self.incidents)+1,"severity":severity,
                  "title":title,"details":details or {},"status":"OPEN"}
        self.incidents.append(incident)
        return incident

    def close(self,incident_id):
        for i in self.incidents:
            if i["id"]==incident_id:
                i["status"]="CLOSED"
                return i
        return None
