from dataclasses import dataclass, asdict
from typing import Optional

@dataclass
class Product:
    sku: str
    name: str
    category: str
    price: float
    stock: int = 0
    active: bool = True
    brand: str = ""
    supplier_id: Optional[str] = None

class Catalog:
    def __init__(self):
        self.products={}

    def upsert(self, product: Product):
        if not product.sku or not product.name or not product.category:
            raise ValueError("product_identity_required")
        if product.price < 0 or product.stock < 0:
            raise ValueError("invalid_product_values")
        self.products[product.sku]=product
        return product

    def get(self, sku):
        return self.products.get(sku)

    def active_products(self):
        return [p for p in self.products.values() if p.active]

    def search(self, query):
        q=query.lower().strip()
        return [p for p in self.active_products()
                if q in p.sku.lower() or q in p.name.lower() or q in p.category.lower()]
