from dataclasses import dataclass
import os

@dataclass
class Integration:
    name: str
    required_env: tuple

    def status(self):
        missing=[k for k in self.required_env if not os.getenv(k)]
        return {
            "name":self.name,
            "status":"CONFIGURED" if not missing else "NOT_CONFIGURED",
            "missing":missing
        }

class IntegrationRegistry:
    def __init__(self):
        self.items={}
    def register(self,name,*required_env):
        self.items[name]=Integration(name,tuple(required_env))
    def status(self):
        return {n:i.status() for n,i in self.items.items()}
