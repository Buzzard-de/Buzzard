from .bridge import ShopIntelligenceBridge
