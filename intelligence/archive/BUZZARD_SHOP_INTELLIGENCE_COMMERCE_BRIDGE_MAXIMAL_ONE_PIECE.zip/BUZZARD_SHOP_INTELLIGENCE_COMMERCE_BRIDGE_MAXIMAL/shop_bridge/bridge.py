from shop_bridge.events import CommerceEvent,CommerceEventStore
from shop_bridge.feature_gate import SalesGate
from shop_bridge.order_pipeline import OrderPipeline
from shop_bridge.intelligence import IntelligenceHooks
class ShopIntelligenceBridge:
    def __init__(self,catalog=None,checkout=None,analytics=None,decision=None): self.catalog=catalog; self.checkout=checkout; self.events=CommerceEventStore(); self.gate=SalesGate(); self.orders=OrderPipeline(); self.intelligence=IntelligenceHooks(analytics,decision)
    def readiness(self,external=None):
        external=external or {}; status={'catalog':'READY' if self.catalog and self.catalog.active_products() else 'BLOCKED','payment':external.get('payment','BLOCKED'),'shipping':external.get('shipping','BLOCKED'),'order_pipeline':'READY','intelligence_bridge':'READY'}; return {**status,**self.gate.evaluate(status)}
    def emit(self,name,payload=None):
        e=self.events.append(CommerceEvent(name,payload or {})); return {'event':e.__dict__,'intelligence':self.intelligence.on_event(e)}
    def create_order(self,checkout,external=None):
        r=self.readiness(external)
        if not r['sales_enabled']: raise RuntimeError('SALES_BLOCKED:'+','.join(r['missing']))
        o=self.orders.create(checkout); self.emit('ORDER_CREATED',o.__dict__); return o
    def payment_confirmed(self,o,ref): self.orders.mark_paid(o,ref); self.emit('PAYMENT_CONFIRMED',{'order_id':o.order_id,'amount':o.subtotal}); return o
    def shipped(self,o,tracking): self.orders.mark_shipped(o,tracking); self.emit('SHIPMENT_CREATED',{'order_id':o.order_id,'tracking_id':tracking}); return o
    def delivered(self,o): self.orders.mark_delivered(o); self.emit('ORDER_DELIVERED',{'order_id':o.order_id}); return o
