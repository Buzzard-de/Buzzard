class SalesGate:
    REQUIRED=('catalog','payment','shipping','order_pipeline','intelligence_bridge')
    def evaluate(self,status):
        missing=[k for k in self.REQUIRED if status.get(k)!='READY']
        return {'sales_enabled':not missing,'missing':missing}
    def enforce(self,status):
        r=self.evaluate(status)
        if not r['sales_enabled']: raise RuntimeError('SALES_BLOCKED:'+','.join(r['missing']))
        return True
