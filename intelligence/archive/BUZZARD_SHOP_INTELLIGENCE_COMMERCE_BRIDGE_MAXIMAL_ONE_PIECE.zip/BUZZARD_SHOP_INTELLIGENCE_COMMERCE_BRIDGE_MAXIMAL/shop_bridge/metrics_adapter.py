class CommerceAnalyticsAdapter:
    MAP={'ORDER_CREATED':'ORDER','PAYMENT_CONFIRMED':'SALE','ORDER_DELIVERED':'DELIVERED'}
    def convert(self,events): return [{'event_id':e.event_id,'event_type':self.MAP.get(e.name,e.name),'timestamp':e.timestamp,'value':float(e.payload.get('subtotal',e.payload.get('amount',0)) or 0),'cost':float(e.payload.get('cost',0) or 0),'metadata':e.payload} for e in events]
