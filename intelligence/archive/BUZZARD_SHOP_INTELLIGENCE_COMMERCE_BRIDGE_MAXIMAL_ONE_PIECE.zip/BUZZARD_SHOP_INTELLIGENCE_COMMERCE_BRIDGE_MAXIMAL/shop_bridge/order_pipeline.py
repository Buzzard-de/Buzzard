from dataclasses import dataclass,field
@dataclass
class Order:
    order_id:str; customer_id:str; country:str; lines:list; subtotal:float
    status:str='PAYMENT_PENDING'; payment_status:str='PENDING'; fulfillment_status:str='PENDING'; shipping_status:str='PENDING'; metadata:dict=field(default_factory=dict)
class OrderPipeline:
    def create(self,c): return Order(c['order_id'],c['customer_id'],c['country'],c['lines'],c['subtotal'])
    def mark_paid(self,o,ref): o.status='PAID'; o.payment_status='PAID'; o.fulfillment_status='READY'; o.metadata['payment_reference']=ref; return o
    def start_fulfillment(self,o):
        if o.status!='PAID': raise RuntimeError('ORDER_NOT_PAID')
        o.status='FULFILLING'; o.fulfillment_status='IN_PROGRESS'; return o
    def mark_shipped(self,o,tracking):
        if o.status!='FULFILLING': raise RuntimeError('ORDER_NOT_IN_FULFILLMENT')
        o.status='SHIPPED'; o.shipping_status='SHIPPED'; o.metadata['tracking_id']=tracking; return o
    def mark_delivered(self,o):
        if o.status!='SHIPPED': raise RuntimeError('ORDER_NOT_SHIPPED')
        o.status='DELIVERED'; o.shipping_status='DELIVERED'; return o
