from control_center.orchestrator import ControlCenter
from control_center.events import Event
from control_center.command_router import CommandRouter
from control_center.incidents import IncidentManager
from control_center.integration_status import IntegrationStatus
from control_center.end_to_end import EndToEndPlan

def test_event_bus():
    c=ControlCenter()
    seen=[]
    c.bus.subscribe("ORDER_CREATED",lambda e: seen.append(e.payload["id"]) or "OK")
    assert c.emit("ORDER_CREATED",{"id":"O1"})==["OK"]
    assert seen==["O1"]

def test_workflow_and_authorization():
    c=ControlCenter()
    c.register_workflow("order_to_delivery",["order","payment","fulfillment","logistics"])
    c.access.grant("aslan_bey","operations")
    assert c.authorize("aslan_bey","operations")
    assert c.execute_workflow("order_to_delivery")["status"]=="READY"

def test_command_router():
    r=CommandRouter()
    r.register("ping",lambda p: {"status":"OK","payload":p})
    assert r.dispatch("ping",{"x":1})["status"]=="OK"
    assert r.dispatch("unknown")["status"]=="UNKNOWN_COMMAND"

def test_incidents():
    i=IncidentManager()
    x=i.open("HIGH","test")
    assert i.close(x["id"])["status"]=="CLOSED"

def test_integrations():
    s=IntegrationStatus()
    s.set("ebay","NOT_CONFIGURED")
    assert s.snapshot()["ebay"]["status"]=="NOT_CONFIGURED"

def test_end_to_end():
    plan=EndToEndPlan().plan("O1")
    assert plan["steps"][0]=="customer"
    assert plan["steps"][-1]=="audit"
