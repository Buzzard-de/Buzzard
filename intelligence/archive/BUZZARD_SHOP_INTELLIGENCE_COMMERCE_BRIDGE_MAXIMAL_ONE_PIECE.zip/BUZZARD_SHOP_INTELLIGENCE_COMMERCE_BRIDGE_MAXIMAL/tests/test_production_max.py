from production.catalog import Catalog, Product
from production.pricing import PricingGuard
from production.checkout import CheckoutEngine
from production.importers import import_json,import_csv,import_xml
from production.marketplaces import EbayAdapter,AmazonAdapter
from production.payments import GenericPaymentAdapter
from production.shipping import GenericCarrierAdapter
from production.automotive import TecDocAdapter
from production.agents import AgentRuntime
from production.readiness import ProductionReadiness

def make_catalog():
    c=Catalog()
    c.upsert(Product("S1","Test Product","Test",20,5))
    return c

def test_catalog_search():
    c=make_catalog()
    assert c.search("test")[0].sku=="S1"

def test_pricing_guard():
    p=PricingGuard(minimum_profit=.50)
    assert p.evaluate(20,10,2,2,1).allowed
    assert not p.evaluate(15,10,2,2,1).allowed

def test_checkout_flow():
    c=make_catalog()
    e=CheckoutEngine(c,PricingGuard())
    cart=e.create_cart()
    e.add(cart.cart_id,"S1",2)
    q=e.quote(cart.cart_id)
    assert q["subtotal"]==40
    result=e.checkout(cart.cart_id,"C1","DE")
    assert result["status"]=="PAYMENT_REQUIRED"

def test_importers():
    assert import_json('[{"sku":"A","name":"A","category":"X","price":2,"stock":3}]')[0].sku=="A"
    assert import_csv("sku,name,category,price,stock\nB,B,X,3,4\n")[0].sku=="B"
    assert import_xml("<products><product><sku>C</sku><name>C</name><category>X</category><price>4</price><stock>5</stock></product></products>")[0].sku=="C"

def test_external_integrations_do_not_fake_success():
    assert EbayAdapter().status()["status"]=="NOT_CONFIGURED"
    assert AmazonAdapter().status()["status"]=="NOT_CONFIGURED"
    assert GenericPaymentAdapter().status()["status"]=="NOT_CONFIGURED"
    assert GenericCarrierAdapter().status()["status"]=="NOT_CONFIGURED"
    assert TecDocAdapter().status()["status"]=="NOT_CONFIGURED"

def test_agents():
    s=AgentRuntime().status()
    assert set(s["roles"])=={"d ogu_bey","aslan_bey","esat_bey"} if False else set(s["roles"])=={"dogu_bey","aslan_bey","esat_bey"}
    assert s["llm"]["status"]=="NOT_CONFIGURED"

def test_readiness_blocks_live_shop_without_payment():
    r=ProductionReadiness().evaluate({},0,False,False,False)
    assert r["ready"] is False
    names={x["name"] for x in r["checks"]}
    assert {"catalog","payment","shipping"}<=names
