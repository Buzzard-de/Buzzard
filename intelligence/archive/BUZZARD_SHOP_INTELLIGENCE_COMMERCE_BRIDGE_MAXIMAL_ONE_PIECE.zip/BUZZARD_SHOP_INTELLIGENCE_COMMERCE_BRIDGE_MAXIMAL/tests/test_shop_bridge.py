from production.catalog import Catalog,Product
from production.pricing import PricingGuard
from production.checkout import CheckoutEngine
from shop_bridge.bridge import ShopIntelligenceBridge
from shop_bridge.feature_gate import SalesGate
from shop_bridge.metrics_adapter import CommerceAnalyticsAdapter
def setup():
 c=Catalog(); c.upsert(Product('S1','Test','Test',50,10)); co=CheckoutEngine(c,PricingGuard()); return c,co,ShopIntelligenceBridge(c,co)
def test_gate_blocks_without_providers():
 _,_,b=setup(); r=b.readiness(); assert not r['sales_enabled']; assert 'payment' in r['missing'] and 'shipping' in r['missing']
def test_gate_allows_when_ready():
 r=SalesGate().evaluate({'catalog':'READY','payment':'READY','shipping':'READY','order_pipeline':'READY','intelligence_bridge':'READY'}); assert r['sales_enabled']
def test_lifecycle():
 c,co,b=setup(); cart=co.create_cart(); co.add(cart.cart_id,'S1',1); q=co.quote(cart.cart_id); o=b.orders.create({'order_id':'O1','customer_id':'C1','country':'DE','lines':q['lines'],'subtotal':q['subtotal']}); b.payment_confirmed(o,'P1'); b.orders.start_fulfillment(o); b.shipped(o,'T1'); b.delivered(o); assert o.status=='DELIVERED'
def test_events_to_analytics():
 _,_,b=setup(); b.emit('ORDER_CREATED',{'order_id':'O1','subtotal':50}); b.emit('PAYMENT_CONFIRMED',{'order_id':'O1','amount':50}); rows=CommerceAnalyticsAdapter().convert(b.events.events); assert rows[0]['event_type']=='ORDER' and rows[1]['event_type']=='SALE'
def test_hooks():
 _,_,b=setup(); b.intelligence.analytics=True; b.intelligence.decision=True; r=b.emit('ORDER_CREATED',{'order_id':'O2'}); assert r['intelligence']['analytics']=='ATTACHED' and r['intelligence']['decision']=='ATTACHED'
