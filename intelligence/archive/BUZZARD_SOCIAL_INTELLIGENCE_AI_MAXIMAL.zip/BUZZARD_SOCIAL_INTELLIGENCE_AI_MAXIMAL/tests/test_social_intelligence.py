from src.social_intelligence.agent import SocialIntelligenceAI
from src.social_intelligence.models import SocialEvidence
from src.social_intelligence.signals.engine import SocialSignalEngine
from src.social_intelligence.privacy.policy import SocialPublicDataPolicy
from src.social_intelligence.analysis.opportunity import SocialOpportunityEngine

def test_platforms():
    ai=SocialIntelligenceAI()
    assert len(ai.platforms)==9
    assert {"facebook","instagram","tiktok","youtube","pinterest","reddit","x","linkedin","forums"}==set(ai.platforms)

def test_public_policy():
    p=SocialPublicDataPolicy()
    assert p.allow_source({"public_or_authorized":True})[0]
    assert not p.allow_source({"private":True,"public_or_authorized":True})[0]
    assert not p.allow_source({"authenticated_area":True,"public_or_authorized":True})[0]

def test_signal_engine():
    e=SocialEvidence(source_url="https://example.com/post/1", platform="instagram", observed_at="2026-08-16", title="engine oil", engagement={"likes":100,"comments":10,"shares":5})
    x=SocialSignalEngine().aggregate([e])
    assert len(x)==1
    assert x[0]["platforms"]==["instagram"]

def test_cross_platform():
    es=[
      SocialEvidence(source_url="https://example.com/1", platform="instagram", observed_at="2026-08-16", title="product", engagement={"likes":100}),
      SocialEvidence(source_url="https://example.com/2", platform="tiktok", observed_at="2026-08-16", title="product", engagement={"likes":100}),
      SocialEvidence(source_url="https://example.com/3", platform="youtube", observed_at="2026-08-16", title="product", engagement={"views":1000})
    ]
    assert SocialSignalEngine().cross_platform_strength(es) > 40

def test_opportunity():
    x=SocialOpportunityEngine().score(90,80,70,80,80,10)
    assert 0 <= x <= 100
