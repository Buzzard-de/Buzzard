# BUZZARD SUPPLIER IMPORT & PRODUCT ENRICHMENT ENGINE – MAXIMAL

## Zweck
Tedarikçi verisini PIM'e güvenli şekilde sokan motor.

## Pipeline
Ingest → Snapshot → Parse → Normalize → Identity Resolution → Duplicate Detection
→ Category Mapping → Attribute Mapping → Multilingual Enrichment
→ Media Normalization → Quality Gate → Compliance Gate → Review Queue → PIM Publish.

## Güvenlik prensipleri
- Varsayılan çalışma `dry_run=true`.
- Onaylanmış ürünler tedarikçi feed'i ile körlemesine overwrite edilmez.
- Yeni kategori otomatik canlıya çıkmaz.
- Her mutation audit edilebilir olmalıdır.
- Duplicate şüphesi ürün oluşturmaz; review/duplicate kuyruğuna gider.

## Sonraki entegrasyon
Gerçek supplier API/XML/CSV bağlantıları `connectors/` altındaki adapter kontratlarına bağlanır.
Canlı credential/endpoint bilgileri kaynak koduna yazılmaz.
