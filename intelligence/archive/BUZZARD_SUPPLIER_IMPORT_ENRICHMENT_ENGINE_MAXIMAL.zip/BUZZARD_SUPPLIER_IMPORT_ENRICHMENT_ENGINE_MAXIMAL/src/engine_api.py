from fastapi import FastAPI
from pydantic import BaseModel, Field
from .engine.pipeline import ImportEngine

app=FastAPI(title="BUZZARD Supplier Import & Enrichment Engine",version="1.0.0")

class RunRequest(BaseModel):
    supplier_id:str
    records:list[dict]=Field(default_factory=list)
    dry_run:bool=True

@app.get("/api/import-engine/health")
def health():
    return {"service":"supplier-import-enrichment","status":"ready","dry_run_default":True}

@app.post("/api/import-engine/preview")
def preview(req:RunRequest):
    return ImportEngine(req.supplier_id,dry_run=True).process(req.records)
