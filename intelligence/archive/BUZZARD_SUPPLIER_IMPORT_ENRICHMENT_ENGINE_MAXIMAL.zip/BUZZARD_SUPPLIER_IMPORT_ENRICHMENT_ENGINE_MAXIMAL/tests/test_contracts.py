import json
from pathlib import Path
def test_taxonomy():
    d=json.loads((Path(__file__).parents[1]/"data/taxonomy.json").read_text())
    assert len([n for n in d["nodes"] if n["level"]==1])==43
def test_config():
    d=json.loads((Path(__file__).parents[1]/"data/import_engine_config.json").read_text())
    assert d["dry_run_default"] is True
    assert "deduplicate" in d["pipeline"]
