from src.engine.pipeline import ImportEngine

def test_normalization_and_quality():
    r={"supplier_sku":" A-1 ","ean":"12345670","brand":"Acme","mpn":"x-1",
       "title":"Test Product","category":"Brake Pad","attributes":{"Farbe":"Rot"}}
    result=ImportEngine("supplier-1").process([r])
    assert result["received"]==1
    assert result["results"][0]["normalized"]["supplier_sku"]=="A-1"
    assert "color" in result["results"][0]["attributes"]

def test_duplicate():
    engine=ImportEngine("s")
    idx={("supplier_sku","s|A-1"):"product-1"}
    result=engine.process([{"supplier_sku":"A-1","title":"X"}])
    # Engine's current index key format is intentionally exact.
    assert result["results"][0]["decision"]=="duplicate"
