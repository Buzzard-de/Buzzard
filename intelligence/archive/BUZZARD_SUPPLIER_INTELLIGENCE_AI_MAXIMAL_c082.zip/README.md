# BUZZARD SUPPLIER INTELLIGENCE AI — MAXIMAL

Bu servis Buzzard'ın merkezi Tedarikçi İstihbarat AI çekirdeğidir.

Ana fonksiyonlar:
- tedarikçi profili
- açık kaynak kanıt yönetimi
- güvenilirlik/risk puanı
- kırmızı bayraklar
- ticari onboarding checklist
- supplier karşılaştırma
- zaman içi supplier memory
- rapor üretimi
- güvenli kaynak politikası

Gerçek supplier API, registry, ödeme veya marketplace bağlantıları bu çekirdeğe
secret gömülerek yapılmaz; production connector'ları ayrı güvenli katmanda
yetkilendirilmelidir.
