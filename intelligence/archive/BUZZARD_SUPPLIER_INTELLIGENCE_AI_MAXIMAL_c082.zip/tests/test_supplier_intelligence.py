from src.supplier_intelligence import *

def profile():
    return SupplierProfile(
        supplier_id="SUP-001",
        legal_name="Example Supplier GmbH",
        country="DE",
        website="https://example.com",
        evidence=[
            Evidence("official_company_site","https://example.com","company identity","2026-08-16"),
            Evidence("official_registry","registry-ref","legal registration","2026-08-16")
        ],
        commercial_terms={"tax_vat":"verified","moq":1,"api_xml_csv":True}
    )

def signals(v=90):
    return {k:v for k in SupplierIntelligenceEngine.WEIGHTS}

def test_high_quality_supplier():
    e=SupplierIntelligenceEngine()
    r=e.score(profile(),signals(90))
    assert r.score >= 85
    assert r.decision==Decision.APPROVE

def test_missing_evidence_caps_score():
    p=profile(); p.evidence=[]
    e=SupplierIntelligenceEngine()
    r=e.score(p,signals(100))
    assert r.score <= 59

def test_fraud_signal_is_not_approved():
    e=SupplierIntelligenceEngine()
    r=e.score(profile(),signals(95),["suspected_fraud"])
    assert r.decision in {Decision.REVIEW,Decision.REJECT}

def test_unknown_missing_signal_is_not_positive():
    e=SupplierIntelligenceEngine()
    r=e.score(profile(),{})
    assert r.score < 65

def test_onboarding_checklist():
    c=SupplierIntelligenceEngine().onboarding_checklist(profile())
    assert c["tax_vat"] is True
    assert c["moq"] is True
    assert c["stock_feed"] is False

def test_source_policy():
    p=SupplierDiscoveryPolicy()
    assert p.validate_source("official_registry")
    assert not p.validate_source("private_account")

def test_memory():
    m=SupplierMemory()
    m.record("SUP-001","price_change",{"old":10,"new":11})
    assert len(m.history("SUP-001"))==1

def test_compare():
    e=SupplierIntelligenceEngine()
    a=profile()
    b=SupplierProfile("SUP-002","B GmbH",evidence=[
        Evidence("official_company_site","https://b.example","identity","2026-08-16"),
        Evidence("official_registry","registry-b","registration","2026-08-16")
    ])
    rows=e.compare([a,b],{"SUP-001":signals(90),"SUP-002":signals(70)})
    assert rows[0][0]=="SUP-001"
