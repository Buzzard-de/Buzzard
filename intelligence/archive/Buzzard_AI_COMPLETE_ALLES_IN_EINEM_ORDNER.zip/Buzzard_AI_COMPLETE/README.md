# Buzzard AI – Consolidated Complete Workspace

Agents:
- Doğu Bey — Intelligence & OSINT specialist
- Aslan Bey — Müsteşar / orchestrator
- Esat Bey — defensive security specialist

Core: SQLite database, shared memory, task manager, source registry, verification, research adapter, reports, audit, API and monitoring foundations.

External services are deliberately adapter-based. Configure real LLM/search providers and production infrastructure through environment variables; no credentials are included.

Run: `python main.py`
API (after installing requirements): `uvicorn api.app:app --reload`
