from dataclasses import dataclass
import os
@dataclass(frozen=True)
class Settings:
    database_path: str=os.getenv('BUZZARD_DB','buzzard.db')
    api_token: str=os.getenv('BUZZARD_API_TOKEN','')
    llm_api_key: str=os.getenv('LLM_API_KEY','')
    llm_model: str=os.getenv('LLM_MODEL','')
    search_api_key: str=os.getenv('SEARCH_API_KEY','')
    search_provider: str=os.getenv('SEARCH_PROVIDER','')
    app_env: str=os.getenv('APP_ENV','development')
settings=Settings()
