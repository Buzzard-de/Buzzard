from config.settings import settings
from database.db import Database
from memory.store import MemoryStore
from sources.registry import SourceRegistry
from research.engine import ResearchEngine
from tasks.manager import TaskManager
from agents.dogu_bey.agent import DoguBey
from agents.aslan_bey.agent import AslanBey
from agents.esat_bey.agent import EsatBey
from agents.shared.registry import AgentRegistry

def build():
    db=Database(settings.database_path); sources=SourceRegistry(db); research=ResearchEngine(sources); memory=MemoryStore(db); tasks=TaskManager(db)
    dogu=DoguBey(research,memory,db); aslan=AslanBey(tasks,db); esat=EsatBey(db); registry=AgentRegistry(db)
    for a in (dogu,aslan,esat): registry.register(a)
    return {'db':db,'dogu_bey':dogu,'aslan_bey':aslan,'esat_bey':esat,'memory':memory,'tasks':tasks,'research':research,'agents':registry}
if __name__=='__main__':
    x=build(); print('Buzzard AI initialized:', [a['name'] for a in x['agents'].list()])
