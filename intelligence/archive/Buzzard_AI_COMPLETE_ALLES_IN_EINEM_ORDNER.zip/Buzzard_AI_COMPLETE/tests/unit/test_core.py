import tempfile,os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from database.db import Database
from memory.store import MemoryStore
from tasks.manager import TaskManager

def test_memory_and_tasks():
    f=tempfile.NamedTemporaryFile(delete=False); f.close(); db=Database(f.name)
    m=MemoryStore(db); assert m.put('x',{'a':1})==1; assert m.latest('x')['a']==1
    t=TaskManager(db); tid=t.create('x','y'); assert t.list()[0]['id']==tid
    os.unlink(f.name)
