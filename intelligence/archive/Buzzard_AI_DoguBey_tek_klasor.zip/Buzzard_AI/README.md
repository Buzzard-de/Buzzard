# Buzzard Intelligence v29 — Official Source Verification Engine

v29, önemli iddiaları mümkün olduğunda resmî kaynaklara bağlayan doğrulama katmanıdır.

Amaç:
- bir claim/iddiayı kaydetmek
- resmî kaynak URL'sini kaydetmek
- kurum/üretici kaynağını tanımlamak
- kaynak tarihini ve gözlem tarihini tutmak
- doğrulama durumunu yönetmek
- birincil kaynak ile ikincil kaynağı ayırmak
- çelişen kaynakları işaretlemek
- yeniden doğrulama ihtiyacını takip etmek

Kaynak türleri:
- OFFICIAL_GOVERNMENT
- OFFICIAL_MANUFACTURER
- OFFICIAL_PLATFORM
- OFFICIAL_STANDARD
- SECONDARY
- USER_PROVIDED

Durumlar:
- UNVERIFIED
- PENDING
- VERIFIED
- CONFLICT
- OUTDATED
- REJECTED

ÖNEMLİ:
v29 bir hukuk/vergi danışmanı değildir.
"Resmî kaynak bulundu" demek "ürün hukuken kesin uygundur" anlamına gelmez.
Kaynağın kapsamı, tarihi ve iddiayı gerçekten destekleyip desteklemediği ayrıca incelenmelidir.
Kaynak yoksa sistem doğrulanmış gerçek üretmez.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Claim:
```bash
python main.py claim --entity "5W-30 Motor Yağı" --text "Üretici ürünü listeliyor."
```

Kaynak:
```bash
python main.py source --claim-id 1 --type OFFICIAL_MANUFACTURER --url "https://example.com" --publisher "Example"
```

Doğrulama:
```bash
python main.py verify --claim-id 1 --status VERIFIED --note "Birincil üretici kaynağıyla doğrulandı."
```
