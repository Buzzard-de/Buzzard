import argparse
from buzzard_intelligence.verify import OfficialVerifier

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v29 Official Verification")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    c=s.add_parser("claim")
    c.add_argument("--entity",required=True)
    c.add_argument("--text",required=True)
    c.add_argument("--category",default="GENERAL")

    so=s.add_parser("source")
    so.add_argument("--claim-id",type=int,required=True)
    so.add_argument("--type",required=True)
    so.add_argument("--url",required=True)
    so.add_argument("--publisher",required=True)
    so.add_argument("--published",default="")
    so.add_argument("--note",default="")

    v=s.add_parser("verify")
    v.add_argument("--claim-id",type=int,required=True)
    v.add_argument("--status",required=True)
    v.add_argument("--note",default="")

    args=p.parse_args()
    app=OfficialVerifier()

    if args.cmd=="init":
        app.init(); print("v29 Official Source Verification hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo doğrulama kayıtları hazır.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="claim":
        app.init(); print(app.add_claim(args.entity,args.text,args.category))
    elif args.cmd=="source":
        app.init()
        print(app.add_source(
            args.claim_id,args.type,args.url,args.publisher,args.published,args.note
        ))
    elif args.cmd=="verify":
        app.init(); print(app.verify(args.claim_id,args.status,args.note))
    else:
        p.print_help()

if __name__=="__main__":
    main()
