import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from buzzard_intelligence.verify import OfficialVerifier

DB = Path("buzzard_official_verification_v29.db")

TASK_PRIORITIES = {"CRITICAL", "HIGH", "NORMAL", "LOW"}
TASK_STATUSES = {"QUEUED", "IN_PROGRESS", "WAITING", "COMPLETED", "FAILED", "CANCELLED"}


class AslanSecretary:
    """
    Aslan Bey v1 — Doğu Bey'in müsteşar/koordinasyon katmanı.

    Tasarım ilkesi:
    - Doğu Bey'in mevcut OfficialVerifier altyapısını değiştirmez.
    - Aynı SQLite veritabanına görev/koordinasyon tabloları ekler.
    - Araştırma/doğrulama işini kendisi yapmaz; Doğu Bey/istihbarat katmanını koordine eder.
    """

    def __init__(self):
        self.verifier = OfficialVerifier()

    def connect(self):
        c = sqlite3.connect(DB)
        c.row_factory = sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        # Önce mevcut Doğu Bey v29 altyapısının tablolarını garanti eder.
        self.verifier.init()
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS aslan_tasks(
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                objective TEXT NOT NULL,
                priority TEXT NOT NULL DEFAULT 'NORMAL',
                status TEXT NOT NULL DEFAULT 'QUEUED',
                assigned_agent TEXT NOT NULL DEFAULT 'DoguBey',
                parent_task_id INTEGER,
                result_summary TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                completed_at TEXT
            );

            CREATE TABLE IF NOT EXISTS aslan_task_events(
                id INTEGER PRIMARY KEY,
                task_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS aslan_reviews(
                id INTEGER PRIMARY KEY,
                task_id INTEGER NOT NULL,
                review_type TEXT NOT NULL,
                decision TEXT NOT NULL,
                notes TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def _validate_priority(self, priority):
        priority = priority.upper()
        if priority not in TASK_PRIORITIES:
            raise ValueError("Geçersiz öncelik: " + ", ".join(sorted(TASK_PRIORITIES)))
        return priority

    def create_task(self, title, objective, priority="NORMAL",
                    assigned_agent="DoguBey", parent_task_id=None):
        priority = self._validate_priority(priority)
        now = self.now()
        with self.connect() as c:
            cur = c.execute("""
                INSERT INTO aslan_tasks
                (title, objective, priority, status, assigned_agent,
                 parent_task_id, created_at, updated_at)
                VALUES (?, ?, ?, 'QUEUED', ?, ?, ?, ?)
            """, (title, objective, priority, assigned_agent,
                  parent_task_id, now, now))
            task_id = cur.lastrowid
            c.execute("""
                INSERT INTO aslan_task_events
                (task_id, event_type, details, created_at)
                VALUES (?, 'CREATED', ?, ?)
            """, (task_id, f"assigned_agent={assigned_agent}", now))
        return task_id

    def update_status(self, task_id, status, details=""):
        status = status.upper()
        if status not in TASK_STATUSES:
            raise ValueError("Geçersiz durum: " + ", ".join(sorted(TASK_STATUSES)))

        now = self.now()
        completed_at = now if status == "COMPLETED" else None

        with self.connect() as c:
            task = c.execute(
                "SELECT id FROM aslan_tasks WHERE id=?", (task_id,)
            ).fetchone()
            if not task:
                raise ValueError("Görev bulunamadı.")

            c.execute("""
                UPDATE aslan_tasks
                SET status=?, updated_at=?,
                    completed_at=COALESCE(?, completed_at)
                WHERE id=?
            """, (status, now, completed_at, task_id))

            c.execute("""
                INSERT INTO aslan_task_events
                (task_id, event_type, details, created_at)
                VALUES (?, ?, ?, ?)
            """, (task_id, "STATUS_CHANGED", details, now))

    def record_result(self, task_id, result_summary):
        now = self.now()
        with self.connect() as c:
            task = c.execute(
                "SELECT id FROM aslan_tasks WHERE id=?", (task_id,)
            ).fetchone()
            if not task:
                raise ValueError("Görev bulunamadı.")

            c.execute("""
                UPDATE aslan_tasks
                SET result_summary=?, status='COMPLETED',
                    updated_at=?, completed_at=?
                WHERE id=?
            """, (result_summary, now, now, task_id))

            c.execute("""
                INSERT INTO aslan_task_events
                (task_id, event_type, details, created_at)
                VALUES (?, 'RESULT_RECORDED', ?, ?)
            """, (task_id, result_summary, now))

    def review_claim(self, task_id, claim_id, notes=""):
        """
        Doğu Bey'in doğrulama sonucunu müsteşar seviyesinde kontrol eder.
        VERIFIED kararını otomatik üretmez; mevcut kaynak/verifikasyon kaydını
        okur ve yöneticiye denetim kararı verir.
        """
        with self.connect() as c:
            claim = c.execute("""
                SELECT id, entity, claim_text, status, verification_score
                FROM claims WHERE id=?
            """, (claim_id,)).fetchone()

            if not claim:
                raise ValueError("Claim bulunamadı.")

            sources = c.execute("""
                SELECT source_type, publisher, source_quality, url
                FROM sources
                WHERE claim_id=?
                ORDER BY source_quality DESC
            """, (claim_id,)).fetchall()

        source_count = len(sources)
        best_quality = max((r["source_quality"] for r in sources), default=0)

        if claim["status"] == "CONFLICT":
            decision = "ESCALATE"
            review_notes = "Çelişkili kaynaklar mevcut; yönetici incelemesi gerekli."
        elif claim["status"] == "VERIFIED" and best_quality >= 90 and source_count >= 1:
            decision = "ACCEPT"
            review_notes = "Doğu Bey doğrulaması güçlü birincil/resmî kaynakla destekleniyor."
        elif claim["status"] in {"PENDING", "UNVERIFIED"}:
            decision = "REQUEST_MORE_RESEARCH"
            review_notes = "Doğrulama tamamlanmamış; ek araştırma gerekiyor."
        elif claim["status"] in {"OUTDATED", "REJECTED"}:
            decision = "REJECT_FOR_REPORT"
            review_notes = "Mevcut kayıt güncel/geçerli doğrulanmış bilgi olarak kullanılamaz."
        else:
            decision = "ESCALATE"
            review_notes = "Manuel inceleme gerekli."

        if notes:
            review_notes += " " + notes

        now = self.now()
        with self.connect() as c:
            c.execute("""
                INSERT INTO aslan_reviews
                (task_id, review_type, decision, notes, created_at)
                VALUES (?, 'CLAIM_VERIFICATION', ?, ?, ?)
            """, (task_id, decision, review_notes, now))

        return {
            "task_id": task_id,
            "claim_id": claim_id,
            "decision": decision,
            "claim_status": claim["status"],
            "verification_score": claim["verification_score"],
            "source_count": source_count,
            "best_source_quality": best_quality,
            "notes": review_notes,
        }

    def dashboard(self):
        with self.connect() as c:
            tasks = c.execute("""
                SELECT status, priority, COUNT(*) AS count
                FROM aslan_tasks
                GROUP BY status, priority
                ORDER BY priority, status
            """).fetchall()

            recent = c.execute("""
                SELECT id, title, priority, status, assigned_agent, updated_at
                FROM aslan_tasks
                ORDER BY updated_at DESC
                LIMIT 20
            """).fetchall()

        out = ["=== ASLAN BEY v1 — MÜSTEŞAR KONTROL PANELİ ===", "", "ÖZET"]
        if tasks:
            for r in tasks:
                out.append(f"- {r['priority']} | {r['status']} | {r['count']}")
        else:
            out.append("- Henüz görev yok.")

        out += ["", "SON GÖREVLER"]
        for r in recent:
            out.append(
                f"- #{r['id']} {r['title']} | {r['priority']} | "
                f"{r['status']} | {r['assigned_agent']}"
            )
        return "\n".join(out)
