import argparse
from buzzard_intelligence.verify import OfficialVerifier
from buzzard_intelligence.aslan import AslanSecretary


def main():
    p = argparse.ArgumentParser(
        description="Buzzard Intelligence v29 + Aslan Bey v1"
    )
    s = p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    c = s.add_parser("claim")
    c.add_argument("--entity", required=True)
    c.add_argument("--text", required=True)
    c.add_argument("--category", default="GENERAL")

    so = s.add_parser("source")
    so.add_argument("--claim-id", type=int, required=True)
    so.add_argument("--type", required=True)
    so.add_argument("--url", required=True)
    so.add_argument("--publisher", required=True)
    so.add_argument("--published", default="")
    so.add_argument("--note", default="")

    v = s.add_parser("verify")
    v.add_argument("--claim-id", type=int, required=True)
    v.add_argument("--status", required=True)
    v.add_argument("--note", default="")

    t = s.add_parser("aslan-task")
    t.add_argument("--title", required=True)
    t.add_argument("--objective", required=True)
    t.add_argument("--priority", default="NORMAL")
    t.add_argument("--agent", default="DoguBey")
    t.add_argument("--parent-task-id", type=int)

    ts = s.add_parser("aslan-status")
    ts.add_argument("--task-id", type=int, required=True)
    ts.add_argument("--status", required=True)
    ts.add_argument("--details", default="")

    tr = s.add_parser("aslan-result")
    tr.add_argument("--task-id", type=int, required=True)
    tr.add_argument("--summary", required=True)

    rv = s.add_parser("aslan-review")
    rv.add_argument("--task-id", type=int, required=True)
    rv.add_argument("--claim-id", type=int, required=True)
    rv.add_argument("--notes", default="")

    s.add_parser("aslan-dashboard")

    args = p.parse_args()

    if args.cmd in {"aslan-task", "aslan-status", "aslan-result",
                    "aslan-review", "aslan-dashboard"}:
        app = AslanSecretary()
        app.init()

        if args.cmd == "aslan-task":
            task_id = app.create_task(
                args.title, args.objective, args.priority,
                args.agent, args.parent_task_id
            )
            print(f"Aslan Bey görev #{task_id} oluşturdu.")

        elif args.cmd == "aslan-status":
            app.update_status(args.task_id, args.status, args.details)
            print(f"Görev #{args.task_id} -> {args.status.upper()}")

        elif args.cmd == "aslan-result":
            app.record_result(args.task_id, args.summary)
            print(f"Görev #{args.task_id} tamamlandı ve sonuç kaydedildi.")

        elif args.cmd == "aslan-review":
            result = app.review_claim(args.task_id, args.claim_id, args.notes)
            print(result)

        elif args.cmd == "aslan-dashboard":
            print(app.dashboard())
        return

    app = OfficialVerifier()

    if args.cmd == "init":
        app.init()
        AslanSecretary().init()
        print("Buzzard v29 + Aslan Bey v1 altyapısı hazır.")
    elif args.cmd == "demo":
        app.init()
        app.demo()
        AslanSecretary().init()
        print("Demo doğrulama kayıtları hazır.")
    elif args.cmd == "report":
        app.init()
        print(app.report())
    elif args.cmd == "claim":
        app.init()
        print(app.add_claim(args.entity, args.text, args.category))
    elif args.cmd == "source":
        app.init()
        print(app.add_source(
            args.claim_id, args.type, args.url, args.publisher,
            args.published, args.note
        ))
    elif args.cmd == "verify":
        app.init()
        print(app.verify(args.claim_id, args.status, args.note))
    else:
        p.print_help()


if __name__ == "__main__":
    main()
