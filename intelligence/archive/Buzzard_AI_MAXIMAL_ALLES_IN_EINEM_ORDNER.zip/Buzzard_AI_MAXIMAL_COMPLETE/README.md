# Buzzard AI – Unified Foundation

Bu paket, mevcut Doğu Bey doğrulama çekirdeğini koruyarak tek proje altında Doğu Bey, Aslan Bey ve Esat Bey için genişletilebilir bir temel sağlar.

## Roller
- Doğu Bey: açık kaynak istihbarat/araştırma, kaynak ve doğrulama.
- Aslan Bey: müsteşar, görev orkestrasyonu, koordinasyon ve denetim.
- Esat Bey: savunma/güvenlik; saldırı yapmaz.

## Kurulum
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python main.py init
python main.py agents
python -m pytest -q
```

## API
```bash
uvicorn api.app:app --reload
```

## Not
Araştırma motoru yalnızca açık HTTP/HTTPS kaynaklarını getirir; gizli, yetkisiz veya korumalı verilere erişim tasarlanmamıştır. Gerçek üretim kullanımı öncesi kimlik doğrulama, rate limiting, secret management, dış API anahtarları ve kapsamlı güvenlik testleri eklenmelidir.
