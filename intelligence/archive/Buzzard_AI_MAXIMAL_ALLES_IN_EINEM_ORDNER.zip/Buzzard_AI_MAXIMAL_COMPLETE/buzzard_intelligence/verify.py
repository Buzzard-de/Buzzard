# Compatibility export: the original v29 verifier is retained here.
from agents.dogu_bey.verify import OfficialVerifier
