from database.db import connect, init_db
from core.time import now

class SupplierService:
    def __init__(self): init_db()
    def upsert(self,name,**kwargs):
        allowed={'country','dropshipping','white_label','api_type','reliability_score','active'}
        vals={k:v for k,v in kwargs.items() if k in allowed}
        with connect() as c:
            r=c.execute('SELECT id FROM suppliers WHERE name=?',(name,)).fetchone()
            if r:
                sets=', '.join(f'{k}=?' for k in vals); c.execute(f'UPDATE suppliers SET {sets},updated_at=? WHERE id=?',(*vals.values(),now(),r['id'])) if sets else None
                return r['id']
            cur=c.execute(f"INSERT INTO suppliers(name,{','.join(vals) if vals else 'country'},created_at,updated_at) VALUES(?,{','.join('?' for _ in vals) if vals else '?'},?,?)",(name,*vals.values(),now(),now()))
            return cur.lastrowid
