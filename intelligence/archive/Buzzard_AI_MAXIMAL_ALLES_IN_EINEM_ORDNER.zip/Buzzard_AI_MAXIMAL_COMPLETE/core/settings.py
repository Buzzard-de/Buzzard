import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    app_env: str = os.getenv("APP_ENV", "development")
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///buzzard.db")
    llm_api_key: str = os.getenv("LLM_API_KEY", "")
    llm_model: str = os.getenv("LLM_MODEL", "")
    search_endpoint: str = os.getenv("SEARCH_ENDPOINT", "")
    search_api_key: str = os.getenv("SEARCH_API_KEY", "")
    api_token: str = os.getenv("API_TOKEN", "")

settings = Settings()
