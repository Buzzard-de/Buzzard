from crm.events import CustomerEventStore
from crm.tickets import TicketEngine
from crm.reviews import ReviewEngine
from crm.loyalty import LoyaltyEngine
from crm.abandoned_cart import AbandonedCartEngine
from crm.notifications import CRMNotificationService
from crm.segments import segment_customer

class CRMEngine:
    def __init__(self):
        self.events=CustomerEventStore()
        self.tickets=TicketEngine()
        self.reviews=ReviewEngine()
        self.loyalty=LoyaltyEngine()
        self.carts=AbandonedCartEngine()
        self.notifications=CRMNotificationService()

    def segment(self,lifetime_value,order_count,support_tickets=0):
        return segment_customer(lifetime_value,order_count,support_tickets)

    def customer_snapshot(self,customer_id):
        return {
            "customer_id":customer_id,
            "events":len(self.events.for_customer(customer_id)),
            "tickets":len([t for t in self.tickets.tickets.values() if t.customer_id==customer_id]),
            "loyalty_points":self.loyalty.balance(customer_id),
            "average_rating":self.reviews.average(customer_id),
            "abandoned_cart":self.carts.recoverable(customer_id),
        }
