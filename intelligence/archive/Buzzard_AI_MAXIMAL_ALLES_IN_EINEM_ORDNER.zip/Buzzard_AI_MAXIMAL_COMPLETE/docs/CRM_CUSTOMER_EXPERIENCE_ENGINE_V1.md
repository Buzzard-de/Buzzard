# Buzzard CRM & Customer Experience Engine v1

Includes:
- customer events and 360° snapshot
- customer segmentation
- support ticket lifecycle
- reviews and ratings
- loyalty points
- abandoned-cart recovery foundation
- notification adapter
- privacy/consent helpers
- CLV calculation helper
- deterministic tests

External email/SMS/push providers are not faked; without configured credentials
the notification layer reports `NOT_CONFIGURED`.
