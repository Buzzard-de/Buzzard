# Buzzard Customer, Billing & Returns Engine v1

Includes:
- customer registry and addresses
- invoice creation and VAT calculation
- payment ledger
- refund requests
- credit notes
- payment reconciliation
- privacy redaction helper
- deterministic tests

This is an application-layer foundation. Country-specific tax/legal decisions
must be validated against the applicable jurisdiction and professional advice
before production use.
