# Buzzard Logistics & Smart Shipping Engine v1

The engine:
- validates parcels
- evaluates carrier quotes
- selects cheapest / fastest / balanced options
- supports DHL, DPD, GLS, Hermes and UPS adapters
- supports tracking and label integration points
- supports volume-contract pricing
- does not claim a real carrier quote when credentials/API integration is absent

Real carrier APIs and negotiated business rates must be configured separately.
