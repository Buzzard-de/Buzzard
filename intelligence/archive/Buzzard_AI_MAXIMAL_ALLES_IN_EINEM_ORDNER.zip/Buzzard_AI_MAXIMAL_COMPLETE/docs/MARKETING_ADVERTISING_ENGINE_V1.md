# Buzzard Marketing & Advertising Engine v1

Includes:
- campaign model
- budget allocation
- ROAS and conversion-rate evaluation
- attribution events
- audience/consent gates
- optimization recommendations
- creative registry
- Google Ads provider adapter
- Meta Ads provider adapter
- provider status checks
- deterministic tests

Google Ads integration requires the appropriate Google Ads account/MCC and
developer credentials. Meta Marketing API requires a developer app, ad account,
access token and applicable permissions. Credentials are never stored in code.

The provider adapters intentionally return NOT_CONFIGURED until real credentials
are supplied; they do not fake external campaign creation or reporting.
