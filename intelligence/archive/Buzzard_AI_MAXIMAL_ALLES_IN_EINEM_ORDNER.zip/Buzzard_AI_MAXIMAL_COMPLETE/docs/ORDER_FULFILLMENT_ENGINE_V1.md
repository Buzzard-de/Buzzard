# Buzzard Order & Fulfillment Engine v1

This module manages the operational lifecycle from order validation through
payment authorization, inventory reservation, supplier selection and
fulfillment submission.

It includes:
- order state machine
- payment gateway
- inventory reservation
- supplier selection
- fulfillment gateway
- returns
- customer status notifications
- deterministic tests

External payment and fulfillment providers are credential-aware and never
pretend that an external transaction succeeded.
