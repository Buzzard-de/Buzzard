# Buzzard V2 upgrade

V2 upgrades were added for all modules that previously stopped at V1:

- Logistics: policy routing, volume tiers, carrier webhooks
- Order/Fulfillment: idempotency, orchestration, split-by-supplier
- Customer/Billing/Returns: document numbering, tax-policy abstraction, accounting ledger
- CRM: customer journeys, service-level targets, consent ledger
- Marketing/Advertising: experiments, budget pacing, decision rules

The V2 layer is additive and preserves the V1 architecture.
External providers still require real credentials and provider-specific implementation.
