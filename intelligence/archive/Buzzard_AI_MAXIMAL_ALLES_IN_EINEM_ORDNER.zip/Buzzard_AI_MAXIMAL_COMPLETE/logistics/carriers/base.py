from abc import ABC, abstractmethod
from logistics.models import Parcel, Destination, CarrierQuote

class CarrierAdapter(ABC):
    name = "base"

    @abstractmethod
    def quote(self, parcel: Parcel, destination: Destination) -> CarrierQuote:
        raise NotImplementedError

    def create_label(self, shipment: dict):
        return {"status": "NOT_CONFIGURED", "carrier": self.name}

    def track(self, tracking_number: str):
        return {"status": "NOT_CONFIGURED", "carrier": self.name, "tracking_number": tracking_number}
