from dataclasses import dataclass

@dataclass
class VolumeTier:
    min_shipments: int
    rate: float

@dataclass
class CarrierContractV2:
    carrier: str
    tiers: list

    def rate_for_volume(self, shipments, list_rate):
        applicable=[t for t in self.tiers if shipments >= t.min_shipments]
        return round((max(applicable,key=lambda t:t.min_shipments).rate
                      if applicable else list_rate),2)
