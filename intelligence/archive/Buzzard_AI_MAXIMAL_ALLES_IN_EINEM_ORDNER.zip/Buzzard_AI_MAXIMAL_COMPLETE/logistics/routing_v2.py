from logistics.models import Parcel, Destination, CarrierQuote

class ShippingPolicyV2:
    def __init__(self, excluded=None, max_price=None, max_days=None):
        self.excluded={x.lower() for x in (excluded or [])}
        self.max_price=max_price
        self.max_days=max_days

    def filter_quotes(self, quotes):
        out=[]
        for q in quotes:
            if not q.available or q.carrier.lower() in self.excluded:
                continue
            if self.max_price is not None and q.price > self.max_price:
                continue
            if self.max_days is not None and q.delivery_days > self.max_days:
                continue
            out.append(q)
        return out

    def choose(self, quotes, priority="balanced"):
        quotes=self.filter_quotes(quotes)
        if not quotes:
            return None
        if priority=="fastest":
            return min(quotes,key=lambda q:(q.delivery_days,q.price))
        if priority=="cheapest":
            return min(quotes,key=lambda q:(q.price,q.delivery_days))
        return min(quotes,key=lambda q:(q.price + 0.75*q.delivery_days))
