from logistics.engine import SmartShippingEngine
from logistics.models import Parcel, Destination

class LogisticsService:
    def __init__(self, engine=None):
        self.engine=engine or SmartShippingEngine()

    def recommend(self, weight_kg,length_cm,width_cm,height_cm,country,postal_code,priority="balanced"):
        parcel=Parcel(weight_kg,length_cm,width_cm,height_cm)
        destination=Destination(country,postal_code)
        decision=self.engine.choose(parcel,destination,priority)
        return decision
