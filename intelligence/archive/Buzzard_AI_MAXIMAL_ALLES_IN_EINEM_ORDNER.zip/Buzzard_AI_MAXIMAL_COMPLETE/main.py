import argparse
from database.db import init_db
from core.registry import AgentRegistry
from agents.aslan_bey import AslanBey
from agents.esat_bey import EsatBey
from agents.dogu_bey import DoguBey
from reports.builder import ReportBuilder
from ai.provider import AIProvider
from monitoring.health import health

def bootstrap():
 init_db(); r=AgentRegistry(); r.register('dogu_bey','Uzman İstihbarat ve Araştırma AI'); r.register('aslan_bey','Müsteşar / AI Operasyon ve İstihbarat Koordinatörü'); r.register('esat_bey','AI Siber Güvenlik ve Savunma Uzmanı')
def main():
 p=argparse.ArgumentParser(description='Buzzard AI unified system v2'); s=p.add_subparsers(dest='cmd'); s.add_parser('init'); s.add_parser('agents'); s.add_parser('report'); s.add_parser('dashboard'); s.add_parser('health'); s.add_parser('ai-status')
 t=s.add_parser('task'); t.add_argument('--title',required=True); t.add_argument('--description',required=True); t.add_argument('--priority',default='NORMAL')
 u=s.add_parser('dispatch'); u.add_argument('--task-id',type=int,required=True); u.add_argument('--url',required=True)
 args=p.parse_args(); bootstrap(); aslan=AslanBey()
 if args.cmd=='init': print('Buzzard AI initialized.')
 elif args.cmd=='agents': print(*[f"{a['name']} | {a['role']} | {a['status']}" for a in AgentRegistry().all()],sep='\n')
 elif args.cmd=='report': print(ReportBuilder().build_executive())
 elif args.cmd=='dashboard': print(aslan.dashboard())
 elif args.cmd=='health': print(health())
 elif args.cmd=='ai-status': print(AIProvider().status())
 elif args.cmd=='task': print(aslan.create_research_task(args.title,args.description,args.priority))
 elif args.cmd=='dispatch': print(aslan.dispatch(args.task_id,args.url))
 else:p.print_help()
if __name__=='__main__': main()
