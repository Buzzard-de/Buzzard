from marketing.budget import BudgetEngine
from marketing.attribution import AttributionEngine
from marketing.providers import GoogleAdsProvider, MetaAdsProvider

class MarketingEngine:
    def __init__(self):
        self.budget=BudgetEngine()
        self.attribution=AttributionEngine()
        self.providers={
            "google_ads":GoogleAdsProvider(),
            "meta_ads":MetaAdsProvider()
        }

    def provider_status(self):
        return {name:p.status() for name,p in self.providers.items()}

    def allocate_budget(self,total,channels,weights=None):
        return self.budget.allocate(total,channels,weights)

    def create_campaign(self,provider,campaign):
        p=self.providers.get(provider)
        if p is None: return {"status":"UNSUPPORTED_PROVIDER"}
        return p.create_campaign(campaign)
