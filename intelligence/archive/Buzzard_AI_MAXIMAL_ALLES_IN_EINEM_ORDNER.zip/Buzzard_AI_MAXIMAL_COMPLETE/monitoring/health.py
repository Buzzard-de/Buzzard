from database.db import connect

def health():
    with connect() as c:
        c.execute("SELECT 1").fetchone()
    return {"status": "ok", "database": "ok"}
