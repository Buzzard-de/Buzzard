def split_by_supplier(order, supplier_gateway):
    groups={}
    for item in order.items:
        supplier=supplier_gateway.select([item],order.country)
        if supplier is None:
            groups.setdefault(None,[]).append(item)
        else:
            groups.setdefault(supplier,[]).append(item)
    return groups
