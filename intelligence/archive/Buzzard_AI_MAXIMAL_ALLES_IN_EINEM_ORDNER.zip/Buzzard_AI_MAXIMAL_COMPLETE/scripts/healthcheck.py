from monitoring.health import health
print(health())
