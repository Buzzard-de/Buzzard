from agents.aslan_bey import AslanBey
from agents.esat_bey import EsatBey

a = AslanBey()
tid = a.create_research_task("SMOKE-001", "Create a public-source research plan", "NORMAL")
print("TASK:", tid)
print("DASHBOARD:", a.dashboard())
print("SECURITY:", EsatBey().scan_text("clean public information"))
