import importlib
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def main():
    result = subprocess.run([sys.executable, '-m', 'pytest', '-q', 'tests'], cwd=ROOT, capture_output=True, text=True)
    print(result.stdout)
    if result.returncode:
        print(result.stderr)
        raise SystemExit(result.returncode)
    errors=[]
    for path in ROOT.rglob('*.py'):
        if '__pycache__' in path.parts or path.name.startswith('test_'):
            continue
        rel=path.relative_to(ROOT).with_suffix('')
        module='.'.join(rel.parts)
        try:
            importlib.import_module(module)
        except Exception as exc:
            errors.append((module,str(exc)))
    if errors:
        for module,error in errors:
            print(f'IMPORT ERROR: {module}: {error}')
        raise SystemExit(2)
    print('ALL CHECKS PASSED')

if __name__ == '__main__':
    main()
