from logistics.routing_v2 import ShippingPolicyV2
from logistics.models import CarrierQuote
from logistics.contracts_v2 import VolumeTier, CarrierContractV2
from logistics.webhooks_v2 import CarrierWebhookRegistry
from order_engine.idempotency import IdempotencyStore
from customer_billing.document_numbering_v2 import DocumentNumbering
from customer_billing.ledger_v2 import AccountingLedgerV2
from crm.journeys_v2 import CustomerJourneyEngineV2
from crm.consent_v2 import ConsentLedgerV2
from marketing.experiments_v2 import ExperimentResult
from marketing.pacing_v2 import budget_pacing
from marketing.rules_v2 import MarketingDecisionRulesV2

def test_logistics_v2_policy():
    q=[CarrierQuote("A","std",5,delivery_days=3),CarrierQuote("B","std",8,delivery_days=1)]
    assert ShippingPolicyV2(max_price=6).choose(q,"cheapest").carrier=="A"

def test_contract_tiers():
    c=CarrierContractV2("DHL",[VolumeTier(100,6.5),VolumeTier(500,5.8)])
    assert c.rate_for_volume(600,8)==5.8

def test_webhook():
    r=CarrierWebhookRegistry()
    r.register("DELIVERED",lambda p: {"status":"OK","id":p["id"]})
    assert r.dispatch("DELIVERED",{"id":"1"})["status"]=="OK"

def test_idempotency():
    s=IdempotencyStore()
    s.put("k",{"status":"DONE"})
    assert s.get("k")["status"]=="DONE"

def test_numbering_and_ledger():
    n=DocumentNumbering("INV")
    assert n.next()=="INV-00000001"
    l=AccountingLedgerV2()
    l.post("cash",debit=100,reference="O1")
    l.post("cash",credit=40,reference="O2")
    assert l.balance("cash")==60

def test_crm_journey():
    j=CustomerJourneyEngineV2()
    assert j.enroll("C1","WELCOME")["status"]=="ACTIVE"
    assert j.advance("C1")["step"]==1

def test_consent_ledger():
    c=ConsentLedgerV2()
    assert c.allowed("C1","marketing") is False
    c.set("C1","marketing",True,"checkout")
    assert c.allowed("C1","marketing") is True

def test_marketing_experiment():
    assert ExperimentResult("E1",2.0,3.0).winner()=="B"

def test_pacing():
    assert budget_pacing(600,0.5,1000)["status"]=="OVER_PACE"

def test_marketing_rules():
    r=MarketingDecisionRulesV2()
    assert r.decide(1.0)=="PAUSE_OR_REVIEW"
    assert r.decide(4.0)=="SCALE"
