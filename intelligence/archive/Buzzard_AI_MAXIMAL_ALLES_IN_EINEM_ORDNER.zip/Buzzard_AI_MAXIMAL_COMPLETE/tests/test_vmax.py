from vmax.platform import BuzzardMaxPlatform
from vmax.security import WebhookVerifier
from vmax.reliability import RetryPolicy
from vmax.idempotency import IdempotencyRegistry
from vmax.rate_limit import TokenBucket
from vmax.data_quality import DataQuality
from vmax.feature_flags import FeatureFlags
from vmax.catalog import ProductIntelligence
from vmax.decisions import DecisionEngine

def test_platform():
    p=BuzzardMaxPlatform()
    p.register_module("commerce","VMAX",["catalog","pricing","orders"])
    p.health.set("commerce","OK")
    p.policy.add("public_research",True)
    s=p.snapshot()
    assert s["modules"]["commerce"]["version"]=="VMAX"
    assert s["health"]["commerce"]["status"]=="OK"

def test_webhook_signature():
    import hmac,hashlib
    payload="hello"; secret="secret"
    sig=hmac.new(secret.encode(),payload.encode(),hashlib.sha256).hexdigest()
    assert WebhookVerifier.verify(payload,sig,secret)

def test_retry():
    state={"n":0}
    def fn():
        state["n"]+=1
        if state["n"]<3: raise RuntimeError("temporary")
        return "OK"
    assert RetryPolicy(max_attempts=3,base_delay=0).run(fn)=="OK"

def test_idempotency():
    r=IdempotencyRegistry()
    assert r.execute("x",lambda:5)==5
    assert r.execute("x",lambda:9)==5

def test_rate_limit():
    b=TokenBucket(capacity=1,refill_per_second=0)
    assert b.allow()
    assert not b.allow()

def test_data_quality():
    q=DataQuality()
    assert q.score({"a":1,"b":2},["a","b"])==1.0

def test_feature_flag():
    f=FeatureFlags(); f.set("x",True)
    assert f.enabled("x")

def test_product_intelligence():
    p=ProductIntelligence().score(10,20,2,2,1)
    assert p["profit"]==5

def test_decision():
    d=DecisionEngine()
    assert d.decide({"profitable":True,"stock_available":True})=="PROCEED"
    assert d.decide({"security_block":True})=="BLOCK"
