class DataQuality:
    def required(self,data,fields):
        return [f for f in fields if not data.get(f)]
    def score(self,data,fields):
        if not fields: return 1.0
        return round(sum(bool(data.get(f)) for f in fields)/len(fields),2)
