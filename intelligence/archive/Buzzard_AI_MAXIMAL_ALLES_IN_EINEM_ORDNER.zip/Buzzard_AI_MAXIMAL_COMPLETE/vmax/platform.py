from vmax.registry import ModuleRegistry
from vmax.audit import AuditTrail
from vmax.health import HealthRegistry
from vmax.policy import PolicyEngine

class BuzzardMaxPlatform:
    def __init__(self):
        self.registry=ModuleRegistry()
        self.audit=AuditTrail()
        self.health=HealthRegistry()
        self.policy=PolicyEngine()

    def register_module(self,name,version,capabilities):
        return self.registry.register(name,version,capabilities)

    def snapshot(self):
        return {
            "modules":self.registry.snapshot(),
            "health":self.health.snapshot(),
            "audit_events":len(self.audit.events),
            "policy_rules":self.policy.count()
        }
