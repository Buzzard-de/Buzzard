from database.db import init_db,connect
from memory.store import MemoryStore
from agents.aslan_bey import AslanBey
from agents.esat_bey import EsatBey

def setup_module(): init_db()
def test_memory_versioning():
 m=MemoryStore(); m.put('test','x','one',confidence=50); m.put('test','x','two',confidence=80); assert m.get('test','x')['version']==2; assert len(m.history('test','x'))>=1
def test_task_and_security():
 a=AslanBey(); tid=a.create_research_task('t','d'); assert a.tasks.get(tid)['assigned_to']=='dogu_bey'; s=EsatBey(); assert s.scan_text('hello')['safe']
