import hashlib, os, requests
from datetime import datetime, timezone
from urllib.parse import urlparse

class PublicFetcher:
    def __init__(self):
        self.ua=os.getenv("BUZZARD_USER_AGENT","Buzzard-Intelligence/1.0")

    def fetch(self,url):
        p=urlparse(url)
        if p.scheme not in ("http","https"):
            raise ValueError("Nur http/https.")
        r=requests.get(
            url,
            headers={"User-Agent":self.ua},
            timeout=30,
            allow_redirects=True
        )
        r.raise_for_status()
        raw=r.content
        return {
            "url":r.url,
            "status_code":r.status_code,
            "content_type":r.headers.get("content-type",""),
            "observed_at":datetime.now(timezone.utc).isoformat(),
            "sha256":hashlib.sha256(raw).hexdigest(),
            "bytes":len(raw),
            "text":raw.decode(r.encoding or "utf-8",errors="replace")
        }
