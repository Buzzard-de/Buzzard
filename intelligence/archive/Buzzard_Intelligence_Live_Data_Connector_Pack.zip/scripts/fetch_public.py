import argparse, json
from dotenv import load_dotenv
from connectors.public_fetch import PublicFetcher
load_dotenv()
p=argparse.ArgumentParser(); p.add_argument("--url",required=True); a=p.parse_args()
print(json.dumps(PublicFetcher().fetch(a.url),ensure_ascii=False,indent=2)[:30000])
