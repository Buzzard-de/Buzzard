import os
from pathlib import Path
from dotenv import load_dotenv
load_dotenv(Path(".env"))

checks={
"eBay":bool(os.getenv("EBAY_CLIENT_ID") and os.getenv("EBAY_CLIENT_SECRET")),
"Amazon Creators":all(os.getenv(k) for k in [
"AMAZON_CLIENT_ID","AMAZON_CLIENT_SECRET","AMAZON_REFRESH_TOKEN","AMAZON_PARTNER_TAG"]),
"Google Ads":all(os.getenv(k) for k in [
"GOOGLE_ADS_DEVELOPER_TOKEN","GOOGLE_ADS_CLIENT_ID",
"GOOGLE_ADS_CLIENT_SECRET","GOOGLE_ADS_REFRESH_TOKEN","GOOGLE_ADS_CUSTOMER_ID"])
}
for name,ok in checks.items():
    print(f"{name}: {'READY' if ok else 'NOT_CONFIGURED'}")
print("Public URL Fetcher: READY")
