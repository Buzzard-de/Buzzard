import argparse, json
from dotenv import load_dotenv
from connectors.ebay import EbayClient
load_dotenv()
p=argparse.ArgumentParser(); p.add_argument("--query",required=True); a=p.parse_args()
x=EbayClient()
print(json.dumps(x.search(a.query),ensure_ascii=False,indent=2)[:30000])
