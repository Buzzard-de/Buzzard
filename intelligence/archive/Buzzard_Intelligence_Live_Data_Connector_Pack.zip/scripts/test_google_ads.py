import json
from dotenv import load_dotenv
from connectors.google_ads import GoogleAdsClient
load_dotenv()
x=GoogleAdsClient()
q="""SELECT customer.id, campaign.id, campaign.name, metrics.impressions,
metrics.clicks, metrics.cost_micros
FROM campaign
WHERE segments.date DURING LAST_7_DAYS"""
print(json.dumps(x.query(q),ensure_ascii=False,indent=2)[:30000])
