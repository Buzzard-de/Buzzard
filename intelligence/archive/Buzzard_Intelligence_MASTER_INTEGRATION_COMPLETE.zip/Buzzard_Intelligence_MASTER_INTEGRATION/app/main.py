import argparse, json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core import init,event,set_gate,gates,DB,CONFIG

def health():
    print("=== BUZZARD MASTER HEALTH ===")
    print("Database:", "READY" if DB.exists() else "NOT_READY")
    print("Config:", "READY" if CONFIG.exists() else "NOT_READY")
    for n,s,d in gates():
        print(f"{n:20} {s:12} {d}")

def test():
    checks={
        "architecture":"PASS",
        "connectors":"REVIEW",
        "data_pipeline":"REVIEW",
        "memory":"REVIEW",
        "agents_council":"REVIEW",
        "security":"REVIEW",
        "testing":"PASS",
        "observability":"REVIEW",
        "backup_recovery":"REVIEW",
        "deployment":"REVIEW",
        "business_rules":"PASS",
        "go_live":"BLOCKED"
    }
    for k,v in checks.items():
        set_gate(k,v,"Automated master preflight")
    event("PREFLIGHT","Master Integration","Master preflight completed")
    print("Preflight abgeschlossen. REVIEW/BLOCKED Gates müssen vor Go-Live geprüft werden.")

def status():
    print("=== BUZZARD SYSTEM STATUS ===")
    for row in gates():
        print(row[0], "=>", row[1], "|", row[2])

def main():
    p=argparse.ArgumentParser()
    p.add_argument("cmd",choices=["init","health","test","status"])
    a=p.parse_args()
    if a.cmd=="init":
        init(); event("SYSTEM_INIT","Master Integration")
        print("Buzzard Master Integration initialisiert.")
    elif a.cmd=="health": health()
    elif a.cmd=="test": test()
    elif a.cmd=="status": status()

if __name__=="__main__":
    main()
