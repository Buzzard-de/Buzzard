from pathlib import Path
import sqlite3

root=Path(__file__).resolve().parents[1]
db=root/"buzzard_master.db"
if not db.exists():
    print("BLOCKED: zuerst python app/main.py init")
    raise SystemExit(1)

with sqlite3.connect(db) as c:
    rows=c.execute("SELECT name,status FROM gates").fetchall()

bad=[(n,s) for n,s in rows if s not in ("PASS","APPROVED")]
if bad:
    print("GO-LIVE BLOCKED")
    for x in bad: print("-",x[0],x[1])
    raise SystemExit(2)

print("GO-LIVE READY")
