from pathlib import Path
import json

def test_config_exists():
    p=Path(__file__).resolve().parents[1]/"config/system.json"
    assert p.exists()
    data=json.loads(p.read_text(encoding="utf-8"))
    assert data["system"]=="Buzzard Intelligence"
    assert data["human_approval_required"] is True
    assert data["minimum_net_profit_eur"]==0.50
