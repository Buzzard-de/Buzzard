# Buzzard Intelligence — Marketplace & Website Monitoring

Der Agent soll relevante E-Commerce-, Marketplace-, Preisvergleichs-, Retail-,
Automotive- und B2B-Websites regelmäßig beobachten.

## Was überwacht werden soll

Je nach erlaubter Datenquelle:
- neue Kategorien
- neue Produkte
- Produktverfügbarkeit
- öffentlich sichtbare Preise
- Preisänderungen
- Rabatte/Aktionen
- sichtbare Bestseller/Featured/Popular-Signale
- Marken
- Produktanzahl
- Kategorieänderungen
- Such-/Sortiertrends, wenn öffentlich und erlaubt
- sichtbare Liefer-/Versandinformationen
- Markt-/Länderverfügbarkeit
- relevante Wettbewerbsänderungen

## Rechtliche technische Regel

Der Agent darf nur:
1. offizielle APIs/Feeds/Partnerzugänge nutzen, wenn Buzzard dazu berechtigt ist,
2. oder öffentlich zugängliche Seiten nur im Rahmen ihrer Nutzungsbedingungen,
   robots/access rules und geltenden Rechtsvorgaben beobachten.

Keine CAPTCHA-Umgehung, kein Login-Bypass, kein Scraping geschützter Bereiche,
keine privaten Daten und keine Umgehung technischer Zugriffskontrollen.

Wenn eine Website keinen zulässigen Datenzugang bietet, wird sie als
`REVIEW_REQUIRED` markiert und nicht gewaltsam ausgelesen.

## Wichtig

Die Liste ist ein Startkatalog. Nicht jede Website bietet eine offene API.
Der Connector entscheidet deshalb zwischen:
API -> Feed -> autorisiertem Partnerzugang -> zulässiger öffentlicher Recherche -> REVIEW_REQUIRED.
