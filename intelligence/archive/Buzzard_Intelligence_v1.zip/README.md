# Buzzard Intelligence v1

Amaç:
- 100+ ana kategoriyi takip edebilen genişletilebilir bir istihbarat çekirdeği.
- Kategori / alt kategori / alt-alt kategori hafızası.
- Ürün gözlemleri, fiyat, platform, ülke ve kaynak kaydı.
- Aynı ürün/kategori tekrar görüldüğünde geçmişle karşılaştırma.
- Değişimleri ve yeni keşifleri raporlama.
- Karar vermez; yalnızca kaynaklı bilgi üretir.

Not:
Bu MVP otomatik olarak sınırsız web taraması yapmaz. Veri toplama katmanı, izin verilen açık kaynaklar, resmi API'ler, XML/CSV feed'ler ve kullanım şartları izin veren sayfalarla genişletilmelidir. robots.txt, kullanım şartları, telif ve veri koruma kurallarına uyulmalıdır.

## Kurulum

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
pip install -r requirements.txt
python main.py init
python main.py seed
python main.py report
```

## Örnek

```bash
python main.py add-observation \
  --category "Otomotiv" \
  --subcategory "Fren Sistemi" \
  --product "Örnek Fren Balatası" \
  --platform "Example Marketplace" \
  --country "DE" \
  --price 49.90 \
  --currency EUR \
  --popularity 82 \
  --source-url "https://example.com/public-page"
```

Sonra:

```bash
python main.py report
python main.py changes
```
