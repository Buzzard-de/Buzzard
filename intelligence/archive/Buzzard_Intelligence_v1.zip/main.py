import argparse
from buzzard_intelligence import IntelligenceDB, SEED_CATEGORIES

def main():
    parser = argparse.ArgumentParser(description="Buzzard Intelligence v1")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("init")
    sub.add_parser("seed")
    sub.add_parser("report")
    sub.add_parser("changes")

    p = sub.add_parser("add-observation")
    p.add_argument("--category", required=True)
    p.add_argument("--subcategory", default="")
    p.add_argument("--subsubcategory", default="")
    p.add_argument("--product", required=True)
    p.add_argument("--brand", default="")
    p.add_argument("--platform", default="")
    p.add_argument("--country", default="")
    p.add_argument("--price", type=float)
    p.add_argument("--currency", default="EUR")
    p.add_argument("--popularity", type=float)
    p.add_argument("--source-url", required=True)

    args = parser.parse_args()
    db = IntelligenceDB()

    if args.cmd == "init":
        db.init()
        print("Buzzard Intelligence database hazır.")
    elif args.cmd == "seed":
        db.init()
        db.seed_categories(SEED_CATEGORIES)
        print(f"{len(SEED_CATEGORIES)} ana kategori hafızaya alındı.")
    elif args.cmd == "add-observation":
        db.init()
        db.add_observation(
            category=args.category,
            subcategory=args.subcategory,
            subsubcategory=args.subsubcategory,
            product=args.product,
            brand=args.brand,
            platform=args.platform,
            country=args.country,
            price=args.price,
            currency=args.currency,
            popularity=args.popularity,
            source_url=args.source_url,
        )
        print("Gözlem hafızaya kaydedildi.")
    elif args.cmd == "report":
        db.init()
        print(db.report())
    elif args.cmd == "changes":
        db.init()
        print(db.changes())
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
