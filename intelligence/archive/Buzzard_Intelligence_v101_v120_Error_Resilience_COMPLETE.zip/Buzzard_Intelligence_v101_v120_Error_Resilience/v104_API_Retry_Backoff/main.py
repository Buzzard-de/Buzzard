import argparse, json, traceback
from pathlib import Path
from datetime import datetime, timezone

DB=Path("buzzard_v104.json")

def now(): return datetime.now(timezone.utc).isoformat()

def load():
    if DB.exists():
        return json.loads(DB.read_text(encoding="utf-8"))
    return {"version":104,"module":'API Retry & Backoff',"records":[],"errors":[],"events":[]}

def save(x):
    DB.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding="utf-8")

def init():
    save(load())
    print("v104 API Retry & Backoff bereit.")

def demo():
    x=load()
    x["records"].append({
        "type":"HEALTH_TEST",
        "module":'API Retry & Backoff',
        "status":"PASS",
        "created_at":now()
    })
    x["events"].append({"event":"TEST_COMPLETED","created_at":now()})
    save(x)
    print("Demo/Health-Test: PASS")

def report():
    x=load()
    print("=== BUZZARD v104 — API RETRY & BACKOFF ===")
    print("Status: READY")
    print("Records:",len(x.get("records",[])))
    print("Errors:",len(x.get("errors",[])))
    for e in x.get("errors",[])[:20]:
        print("-",e)

def main():
    p=argparse.ArgumentParser()
    p.add_argument("cmd",choices=["init","demo","report"])
    a=p.parse_args()
    try:
        {"init":init,"demo":demo,"report":report}[a.cmd]()
    except Exception as exc:
        # No secrets / full credentials are ever printed.
        print("ERROR:",type(exc).__name__,str(exc))
        raise SystemExit(1)

if __name__=="__main__":
    main()
