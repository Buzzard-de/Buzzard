# Buzzard Intelligence v10 — Council Integration

v10, istihbarat motorunu Buzzard Kurmay Heyeti'ne bağlayan iletişim omurgasıdır.

Amaç:
- istihbarat bulgularını ortak olay kuyruğuna aktarmak
- görev sahibi belirlemek
- önem/öncelik seviyesi vermek
- bilgi ile kararı birbirinden ayırmak
- ekip arkadaşlarının ortak hafızaya kontrollü erişmesini sağlamak
- audit trail tutmak

Kurallar:
1. İstihbaratçı veri ve sinyal üretir.
2. İstihbaratçı tek başına ticari karar vermez.
3. Yönetici/kurmay üyesi değerlendirme kaydı oluşturabilir.
4. Her olay kaynak ve zaman bilgisi taşır.
5. Kritik bilgi için doğrulama durumu tutulur.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py inbox
python main.py council
```

Olay ekleme:
```bash
python main.py event --type TREND --title "Yeni yükselen kategori" --details "..." --source "https://example.com"
```

Bu v10 bir çekirdek iletişim katmanıdır. Gerçek çoklu-agent orkestrasyonu, kullanıcı yetkileri, API kimlik doğrulaması ve mesajlaşma adapter'ları sonraki geliştirmelerde eklenebilir.
