import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_council_v10.db")

class Council:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS events(
                id INTEGER PRIMARY KEY,
                event_type TEXT NOT NULL,
                title TEXT NOT NULL,
                details TEXT,
                source TEXT,
                priority INTEGER NOT NULL,
                from_agent TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'NEW',
                assigned_to TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS reviews(
                id INTEGER PRIMARY KEY,
                event_id INTEGER NOT NULL,
                agent TEXT NOT NULL,
                decision TEXT NOT NULL,
                note TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS audit_log(
                id INTEGER PRIMARY KEY,
                event_id INTEGER,
                action TEXT NOT NULL,
                actor TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def create_event(self,event_type,title,details,source,priority,from_agent):
        now=self.now()
        with self.connect() as c:
            cur=c.execute("""
                INSERT INTO events
                (event_type,title,details,source,priority,from_agent,status,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?)
            """,(event_type,title,details,source,max(1,min(10,priority)),
                 from_agent,"NEW",now,now))
            event_id=cur.lastrowid
            c.execute("""
                INSERT INTO audit_log(event_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """,(event_id,"CREATED",from_agent,title,now))
        return f"İstihbarat olayı #{event_id} Kurmay Heyeti kuyruğuna gönderildi."

    def assign(self,event_id,agent):
        now=self.now()
        with self.connect() as c:
            r=c.execute("SELECT id FROM events WHERE id=?",(event_id,)).fetchone()
            if not r:
                return "Olay bulunamadı."
            c.execute("""
                UPDATE events SET assigned_to=?,status='ASSIGNED',updated_at=?
                WHERE id=?
            """,(agent,now,event_id))
            c.execute("""
                INSERT INTO audit_log(event_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """,(event_id,"ASSIGNED","Council Manager",agent,now))
        return f"#{event_id} -> {agent} atandı."

    def review(self,event_id,decision,note,agent):
        now=self.now()
        with self.connect() as c:
            r=c.execute("SELECT id FROM events WHERE id=?",(event_id,)).fetchone()
            if not r:
                return "Olay bulunamadı."
            c.execute("""
                INSERT INTO reviews(event_id,agent,decision,note,created_at)
                VALUES(?,?,?,?,?)
            """,(event_id,agent,decision,note,now))
            c.execute("""
                UPDATE events SET status='REVIEWED',updated_at=? WHERE id=?
            """,(now,event_id))
            c.execute("""
                INSERT INTO audit_log(event_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """,(event_id,"REVIEWED",agent,decision,now))
        return f"#{event_id} değerlendirmesi kaydedildi."

    def inbox(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT id,event_type,title,details,source,priority,
                       from_agent,status,assigned_to,created_at
                FROM events
                WHERE status!='REVIEWED'
                ORDER BY priority DESC,created_at DESC
            """).fetchall()

        if not rows:
            return "Kurmay Heyeti gelen kutusu boş."

        out=["=== BUZZARD KURMAY HEYETİ — İSTİHBARAT GELEN KUTUSU ==="]
        for r in rows:
            out.append(
                f"#{r['id']} [{r['priority']}/10] {r['event_type']} | "
                f"{r['title']} | durum={r['status']} | "
                f"sorumlu={r['assigned_to'] or '-'} | kaynak={r['source'] or '-'}"
            )
        return "\\n".join(out)

    def council_board(self):
        with self.connect() as c:
            stats=c.execute("""
                SELECT status,COUNT(*) n FROM events GROUP BY status
            """).fetchall()
            reviews=c.execute("""
                SELECT event_id,agent,decision,note,created_at
                FROM reviews ORDER BY created_at DESC LIMIT 20
            """).fetchall()

        out=["=== BUZZARD KURMAY HEYETİ PANOSU ===","",
             "OLAY DURUMLARI"]
        for r in stats:
            out.append(f"- {r['status']}: {r['n']}")

        out += ["","SON DEĞERLENDİRMELER"]
        if not reviews:
            out.append("- Henüz değerlendirme yok.")
        for r in reviews:
            out.append(
                f"- olay #{r['event_id']} | {r['agent']} | "
                f"{r['decision']} | {r['note'] or '-'}"
            )

        out += [
            "",
            "YETKİ AYRIMI:",
            "İstihbaratçı = veri, kaynak ve sinyal.",
            "Kurmay Heyeti = değerlendirme ve öneri.",
            "Nihai ticari karar = yetkilendirilmiş insan/yönetici."
        ]
        return "\\n".join(out)

    def demo(self):
        self.create_event(
            "CATEGORY_DISCOVERY",
            "Yeni kategori sinyali",
            "Örnek alt kategori açık kaynakta keşfedildi.",
            "https://example.com",
            8,
            "Buzzard Intelligence"
        )
        self.create_event(
            "TREND",
            "Yükselen ürün sinyali",
            "Bir ürünün yayımlanmış popülerlik sinyali yükseliyor.",
            "https://example.com",
            7,
            "Buzzard Intelligence"
        )
