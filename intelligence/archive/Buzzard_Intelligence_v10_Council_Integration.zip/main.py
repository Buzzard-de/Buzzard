import argparse
from buzzard_intelligence.council import Council

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v10 Council")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("inbox")
    s.add_parser("council")

    e=s.add_parser("event")
    e.add_argument("--type",required=True)
    e.add_argument("--title",required=True)
    e.add_argument("--details",default="")
    e.add_argument("--source",default="")
    e.add_argument("--priority",type=int,default=5)
    e.add_argument("--from-agent",default="Buzzard Intelligence")

    a=s.add_parser("assign")
    a.add_argument("--event-id",type=int,required=True)
    a.add_argument("--agent",required=True)

    r=s.add_parser("review")
    r.add_argument("--event-id",type=int,required=True)
    r.add_argument("--decision",required=True)
    r.add_argument("--note",default="")
    r.add_argument("--agent",default="Council Manager")

    args=p.parse_args()
    app=Council()

    if args.cmd=="init":
        app.init(); print("v10 Kurmay Heyeti bağlantısı hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo istihbarat olayları oluşturuldu.")
    elif args.cmd=="inbox":
        app.init(); print(app.inbox())
    elif args.cmd=="council":
        app.init(); print(app.council_board())
    elif args.cmd=="event":
        app.init()
        print(app.create_event(args.type,args.title,args.details,args.source,args.priority,args.from_agent))
    elif args.cmd=="assign":
        app.init(); print(app.assign(args.event_id,args.agent))
    elif args.cmd=="review":
        app.init(); print(app.review(args.event_id,args.decision,args.note,args.agent))
    else:
        p.print_help()

if __name__=="__main__":
    main()
