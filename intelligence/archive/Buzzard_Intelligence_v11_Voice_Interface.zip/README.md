# Buzzard Intelligence v11 — Voice Interface

v11, Buzzard Intelligence için konuşma arayüzünün ilk çalışan iskeletidir.

Özellikler:
- Türkçe ve Almanca sesli giriş
- Mikrofon üzerinden konuşmayı metne dönüştürme (tarayıcı Speech Recognition destekliyorsa)
- Metni sesli okutma (Speech Synthesis)
- Dil seçimi
- Konuşma geçmişinin ekranda tutulması
- Gelecekte v10 Council API'sine bağlanabilecek REST uç noktası
- Avatar için genişletilebilir arayüz alanı

Önemli:
Bu sürüm bir "ses arayüzü"dür. Kendi başına yapay zekâ modeli değildir ve geçmiş konuşmaları otomatik olarak hatırlamaz. Kalıcı hafıza v2/v10 katmanından veya ileride bağlanacak backend'den gelmelidir.

Çalıştırma:
```bash
python server.py
```

Sonra tarayıcıda:
http://127.0.0.1:8787

Not:
Tarayıcı Speech Recognition desteği platforma göre değişebilir. Üretim sürümünde güvenilir bir speech-to-text ve text-to-speech sağlayıcısı backend üzerinden bağlanmalıdır.
