from flask import Flask, jsonify, request, send_from_directory

app = Flask(__name__, static_folder="web", static_url_path="")

@app.get("/")
def index():
    return send_from_directory("web", "index.html")

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "Buzzard Intelligence v11 Voice"})

@app.post("/api/message")
def message():
    data = request.get_json(silent=True) or {}
    text = str(data.get("text", "")).strip()
    language = data.get("language", "tr-TR")
    if not text:
        return jsonify({"ok": False, "error": "Boş mesaj"}), 400

    # v10 Council / gerçek AI backend'i burada bağlanacaktır.
    return jsonify({
        "ok": True,
        "language": language,
        "text": text,
        "reply": "Mesaj alındı. Gerçek Buzzard Intelligence backend'i bir sonraki entegrasyonda bağlanabilir."
    })

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8787, debug=False)
