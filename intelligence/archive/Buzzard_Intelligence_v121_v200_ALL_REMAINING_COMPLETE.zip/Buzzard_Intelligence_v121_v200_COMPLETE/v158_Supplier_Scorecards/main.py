import argparse, json
from pathlib import Path
from datetime import datetime, timezone

DB=Path("buzzard_v158.json")

def now(): return datetime.now(timezone.utc).isoformat()

def load():
    if DB.exists():
        return json.loads(DB.read_text(encoding="utf-8"))
    return {"version":158,"module":'Supplier Scorecards',"records":[],"events":[],"errors":[]}

def save(x):
    DB.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding="utf-8")

def init():
    save(load())
    print("v158 Supplier Scorecards initialisiert.")

def demo():
    x=load()
    x["records"].append({"type":"ARCHITECTURE_TEST","status":"PASS","created_at":now()})
    x["events"].append({"event":"DEMO_TEST","created_at":now()})
    save(x)
    print("Demo-Test: PASS")

def report():
    x=load()
    print("=== BUZZARD v158 — SUPPLIER SCORECARDS ===")
    print("Architecture status: READY")
    print("Records:",len(x["records"]))
    print("Errors:",len(x["errors"]))
    for r in x["records"][-10:]:
        print("-",r)

p=argparse.ArgumentParser()
p.add_argument("cmd",choices=["init","demo","report"])
a=p.parse_args()
{"init":init,"demo":demo,"report":report}[a.cmd]()
