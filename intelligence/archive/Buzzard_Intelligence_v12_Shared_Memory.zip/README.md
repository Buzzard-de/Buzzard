# Buzzard Intelligence v12 — Long-Term Shared Memory

v12, v11 ses arayüzünden ve v10 Kurmay Heyeti'nden bağımsız kullanılabilen ortak hafıza katmanıdır.

Amaç:
- Kalıcı konuşma kayıtları
- Proje kararları
- Görevler
- Tercihler
- İstihbarat bulguları
- Kaynaklar
- Varlıklar (ürün, kategori, tedarikçi vb.)
- Etiketler
- Güven seviyesi
- Zaman damgası
- Geçmiş değişiklikleri
- Hafızada arama

Temel prensip:
Bir bilgi "gerçek" olarak işaretlenmeden önce kaynak/doğrulama durumu tutulur.

Örnek:
```bash
python main.py init
python main.py add --type DECISION --text "Buzzard önce Almanya ve AB'ye odaklanacak." --source "user"
python main.py search --query "Almanya"
python main.py timeline
```

Bu katman ileride v10 Council, v11 Voice ve gerçek AI modeline ortak hafıza olarak bağlanabilir.
