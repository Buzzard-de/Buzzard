import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_shared_memory_v12.db")

class SharedMemory:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS memories(
                id INTEGER PRIMARY KEY,
                memory_type TEXT NOT NULL,
                content TEXT NOT NULL,
                source TEXT NOT NULL,
                confidence REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'ACTIVE',
                entity TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS tags(
                id INTEGER PRIMARY KEY,
                memory_id INTEGER NOT NULL,
                tag TEXT NOT NULL,
                UNIQUE(memory_id,tag)
            );

            CREATE TABLE IF NOT EXISTS memory_links(
                id INTEGER PRIMARY KEY,
                memory_id INTEGER NOT NULL,
                linked_memory_id INTEGER NOT NULL,
                relation TEXT NOT NULL,
                UNIQUE(memory_id,linked_memory_id,relation)
            );

            CREATE TABLE IF NOT EXISTS memory_audit(
                id INTEGER PRIMARY KEY,
                memory_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                actor TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def add(self,memory_type,text,source,confidence,tags="",entity=""):
        now=self.now()
        confidence=max(0,min(1,confidence))
        with self.connect() as c:
            cur=c.execute("""
                INSERT INTO memories
                (memory_type,content,source,confidence,status,entity,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?)
            """,(memory_type,text,source,confidence,"ACTIVE",entity,now,now))
            mid=cur.lastrowid

            for tag in [x.strip() for x in tags.split(",") if x.strip()]:
                c.execute(
                    "INSERT OR IGNORE INTO tags(memory_id,tag) VALUES(?,?)",
                    (mid,tag)
                )

            c.execute("""
                INSERT INTO memory_audit
                (memory_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """,(mid,"CREATED",source,text,now))

        return f"Hafıza #{mid} kaydedildi."

    def search(self,query):
        q=f"%{query}%"
        with self.connect() as c:
            rows=c.execute("""
                SELECT m.id,m.memory_type,m.content,m.source,m.confidence,
                       m.status,m.entity,m.created_at,
                       GROUP_CONCAT(t.tag,', ') tags
                FROM memories m
                LEFT JOIN tags t ON t.memory_id=m.id
                WHERE m.content LIKE ?
                   OR m.entity LIKE ?
                   OR t.tag LIKE ?
                GROUP BY m.id
                ORDER BY m.updated_at DESC
                LIMIT 100
            """,(q,q,q)).fetchall()

        if not rows:
            return "Hafızada sonuç bulunamadı."

        out=[f"=== BUZZARD ORTAK HAFIZA: {query} ==="]
        for r in rows:
            out.append(
                f"#{r['id']} | {r['memory_type']} | "
                f"{r['content']} | kaynak={r['source']} | "
                f"güven={r['confidence']:.2f} | durum={r['status']} | "
                f"etiket={r['tags'] or '-'}"
            )
        return "\\n".join(out)

    def update_status(self,mid,status):
        allowed={"ACTIVE","VERIFIED","DISPUTED","ARCHIVED","REJECTED"}
        if status not in allowed:
            return f"Geçersiz durum. Kullan: {', '.join(sorted(allowed))}"
        now=self.now()
        with self.connect() as c:
            r=c.execute("SELECT id FROM memories WHERE id=?",(mid,)).fetchone()
            if not r:
                return "Hafıza bulunamadı."
            c.execute(
                "UPDATE memories SET status=?,updated_at=? WHERE id=?",
                (status,now,mid)
            )
            c.execute("""
                INSERT INTO memory_audit
                (memory_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """,(mid,"STATUS_CHANGED","system",status,now))
        return f"Hafıza #{mid} -> {status}"

    def timeline(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT id,memory_type,content,source,confidence,status,created_at
                FROM memories
                ORDER BY created_at DESC
                LIMIT 100
            """).fetchall()

        if not rows:
            return "Ortak hafıza boş."

        out=["=== BUZZARD ORTAK HAFIZA ZAMAN ÇİZELGESİ ==="]
        for r in rows:
            out.append(
                f"{r['created_at']} | #{r['id']} | {r['memory_type']} | "
                f"{r['status']} | {r['content']}"
            )
        return "\\n".join(out)
