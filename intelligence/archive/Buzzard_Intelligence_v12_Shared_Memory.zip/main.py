import argparse
from buzzard_intelligence.memory import SharedMemory

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v12 Shared Memory")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("timeline")

    a=s.add_parser("add")
    a.add_argument("--type",required=True)
    a.add_argument("--text",required=True)
    a.add_argument("--source",default="system")
    a.add_argument("--confidence",type=float,default=0.8)
    a.add_argument("--tags",default="")
    a.add_argument("--entity",default="")

    q=s.add_parser("search")
    q.add_argument("--query",required=True)

    u=s.add_parser("update")
    u.add_argument("--id",type=int,required=True)
    u.add_argument("--status",required=True)

    args=p.parse_args()
    app=SharedMemory()

    if args.cmd=="init":
        app.init(); print("v12 ortak hafıza hazır.")
    elif args.cmd=="add":
        app.init()
        print(app.add(args.type,args.text,args.source,args.confidence,args.tags,args.entity))
    elif args.cmd=="search":
        app.init(); print(app.search(args.query))
    elif args.cmd=="timeline":
        app.init(); print(app.timeline())
    elif args.cmd=="update":
        app.init(); print(app.update_status(args.id,args.status))
    else:
        p.print_help()

if __name__=="__main__":
    main()
