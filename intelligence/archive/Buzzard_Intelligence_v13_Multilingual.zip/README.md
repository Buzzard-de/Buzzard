# Buzzard Intelligence v13 — Multilingual Intelligence Layer

v13, ortak hafızanın üzerine çok dilli istihbarat katmanı ekler.

Amaç:
- Türkçe, Almanca ve İngilizce bilgileri aynı hafıza içinde yönetmek
- Kaynağın dilini kaydetmek
- İstihbarat metnini normalize etmek
- Aynı ürün/kategori için farklı dillerdeki adları eşleştirmek
- Çeviri ihtiyacını görev olarak işaretlemek
- Dil bazlı kaynak kapsamını raporlamak

v13 otomatik olarak çevirinin doğru olduğunu varsaymaz; çeviri durumu ve güven seviyesi tutulur.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
python main.py add --language de --text "Motoröl 5W-30" --canonical "5W-30 Motor Yağı"
```
