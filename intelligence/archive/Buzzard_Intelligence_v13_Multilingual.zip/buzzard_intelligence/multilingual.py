import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_multilingual_v13.db")
SUPPORTED={"tr","de","en","ar","fr","es","it","nl","pl"}

class MultilingualMemory:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS canonical_entities(
                id INTEGER PRIMARY KEY,
                canonical_name TEXT NOT NULL,
                entity_type TEXT,
                created_at TEXT NOT NULL,
                UNIQUE(canonical_name,entity_type)
            );

            CREATE TABLE IF NOT EXISTS multilingual_terms(
                id INTEGER PRIMARY KEY,
                entity_id INTEGER NOT NULL,
                language TEXT NOT NULL,
                term TEXT NOT NULL,
                source TEXT NOT NULL,
                confidence REAL NOT NULL,
                translation_status TEXT NOT NULL DEFAULT 'UNVERIFIED',
                created_at TEXT NOT NULL,
                UNIQUE(entity_id,language,term)
            );

            CREATE TABLE IF NOT EXISTS language_sources(
                id INTEGER PRIMARY KEY,
                source TEXT NOT NULL,
                language TEXT NOT NULL,
                observations INTEGER NOT NULL DEFAULT 0,
                last_seen TEXT NOT NULL,
                UNIQUE(source,language)
            );
            """)

    def add(self,language,text,canonical,entity,source,confidence):
        language=language.lower().split("-")[0]
        if language not in SUPPORTED:
            return f"Dil henüz desteklenmiyor: {language}"

        now=self.now()
        with self.connect() as c:
            row=c.execute("""
                SELECT id FROM canonical_entities
                WHERE canonical_name=? AND entity_type IS ?
            """,(canonical,entity or None)).fetchone()

            if row:
                eid=row["id"]
            else:
                eid=c.execute("""
                    INSERT INTO canonical_entities
                    (canonical_name,entity_type,created_at)
                    VALUES(?,?,?)
                """,(canonical,entity or None,now)).lastrowid

            c.execute("""
                INSERT OR REPLACE INTO multilingual_terms
                (entity_id,language,term,source,confidence,translation_status,created_at)
                VALUES(?,?,?,?,?,'UNVERIFIED',?)
            """,(eid,language,text,source,max(0,min(1,confidence)),now))

            c.execute("""
                INSERT INTO language_sources(source,language,observations,last_seen)
                VALUES(?,?,1,?)
                ON CONFLICT(source,language)
                DO UPDATE SET observations=observations+1,last_seen=excluded.last_seen
            """,(source,language,now))

        return f"Çok dilli terim kaydedildi: [{language}] {text} -> {canonical}"

    def demo(self):
        samples=[
            ("tr","Motor Yağı 5W-30","5W-30 Motor Yağı"),
            ("de","Motoröl 5W-30","5W-30 Motor Yağı"),
            ("en","5W-30 Engine Oil","5W-30 Motor Yağı"),
            ("fr","Huile moteur 5W-30","5W-30 Motor Yağı"),
            ("ar","زيت محرك 5W-30","5W-30 Motor Yağı")
        ]
        for lang,text,canonical in samples:
            self.add(lang,text,canonical,"product","demo",.95)

    def report(self):
        with self.connect() as c:
            entities=c.execute("""
                SELECT e.canonical_name,e.entity_type,
                       COUNT(t.id) terms,
                       COUNT(DISTINCT t.language) languages
                FROM canonical_entities e
                LEFT JOIN multilingual_terms t ON t.entity_id=e.id
                GROUP BY e.id
                ORDER BY languages DESC,terms DESC
            """).fetchall()

            langs=c.execute("""
                SELECT language,SUM(observations) observations,
                       COUNT(DISTINCT source) sources
                FROM language_sources
                GROUP BY language
                ORDER BY observations DESC
            """).fetchall()

        out=["=== BUZZARD v13 ÇOK DİLLİ İSTİHBARAT RAPORU ===",
             "","KANONİK VARLIKLAR"]
        for r in entities:
            out.append(
                f"- {r['canonical_name']} | tür={r['entity_type'] or '-'} | "
                f"terim={r['terms']} | dil={r['languages']}"
            )

        out += ["","DİL KAPSAMI"]
        for r in langs:
            out.append(
                f"- {r['language']} | gözlem={r['observations']} | kaynak={r['sources']}"
            )

        out += [
            "",
            "PRENSİP:",
            "Farklı dillerdeki terimler tek kanonik varlığa bağlanabilir.",
            "Otomatik çeviri doğrulanmış gerçek kabul edilmez; kaynak ve güven seviyesi korunur."
        ]
        return "\\n".join(out)
