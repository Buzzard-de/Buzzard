import argparse
from buzzard_intelligence.multilingual import MultilingualMemory

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v13")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    a=s.add_parser("add")
    a.add_argument("--language",required=True)
    a.add_argument("--text",required=True)
    a.add_argument("--canonical",required=True)
    a.add_argument("--entity",default="")
    a.add_argument("--source",default="system")
    a.add_argument("--confidence",type=float,default=.8)

    args=p.parse_args()
    app=MultilingualMemory()

    if args.cmd=="init":
        app.init(); print("v13 çok dilli istihbarat katmanı hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo çok dilli kayıtlar eklendi.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="add":
        app.init()
        print(app.add(args.language,args.text,args.canonical,args.entity,args.source,args.confidence))
    else:
        p.print_help()

if __name__=="__main__":
    main()
