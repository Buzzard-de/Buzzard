# Buzzard Intelligence v14 — Legal Competitor & Market Intelligence

v14 yalnızca yasal ve açık kaynaklardan rakip/pazar sinyallerini düzenler.

Takip edilebilen açık bilgiler:
- kamuya açık ana kategori
- alt / alt-alt kategori
- listelenen ürünler
- yayımlanmış fiyatlar
- açıkça yayımlanan popülerlik / bestseller sinyalleri
- satış yapılan ülke/pazar
- kamuya açık marka ve mağaza bilgileri
- kaynak ve gözlem tarihi

Kesin sınırlar:
- gizli veya erişim kısıtlı veri yok
- giriş duvarı aşma yok
- CAPTCHA/bot koruması aşma yok
- özel müşteri/satıcı verisi yok
- rakibin özel API anahtarı veya gizli ticari bilgisi yok
- açıkça yayımlanmayan satış adedi tahmin edilmez

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Rakip ekleme:
```bash
python main.py add --name "Example Store" --country DE --source "https://example.com"
```

Açık ürün gözlemi:
```bash
python main.py product --competitor "Example Store" --category "Otomotiv" --name "Örnek Ürün" --price 49.90 --currency EUR --source "https://example.com/product"
```
