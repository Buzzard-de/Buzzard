import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_competitor_v14.db")

class CompetitorIntel:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS competitors(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                country TEXT,
                source TEXT NOT NULL,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS competitor_categories(
                id INTEGER PRIMARY KEY,
                competitor_id INTEGER NOT NULL,
                category TEXT NOT NULL,
                parent_category TEXT,
                level INTEGER NOT NULL,
                source TEXT NOT NULL,
                observed_at TEXT NOT NULL,
                UNIQUE(competitor_id,category,parent_category)
            );

            CREATE TABLE IF NOT EXISTS competitor_products(
                id INTEGER PRIMARY KEY,
                competitor_id INTEGER NOT NULL,
                category_id INTEGER,
                name TEXT NOT NULL,
                brand TEXT,
                price REAL,
                currency TEXT,
                popularity_signal REAL,
                source TEXT NOT NULL,
                observed_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS competitor_events(
                id INTEGER PRIMARY KEY,
                competitor_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                details TEXT,
                source TEXT,
                detected_at TEXT NOT NULL
            );
            """)

    def add_competitor(self,name,country,source):
        now=self.now()
        with self.connect() as c:
            c.execute("""
                INSERT OR IGNORE INTO competitors
                (name,country,source,first_seen,last_seen)
                VALUES(?,?,?,?,?)
            """,(name,country,source,now,now))
            c.execute("""
                UPDATE competitors SET last_seen=? WHERE name=?
            """,(now,name))
        return f"Rakip/kamuya açık mağaza kaydedildi: {name}"

    def add_product(self,competitor,category,name,brand,price,
                    currency,popularity,source):
        now=self.now()
        with self.connect() as c:
            comp=c.execute(
                "SELECT id FROM competitors WHERE name=?",(competitor,)
            ).fetchone()
            if not comp:
                return "Önce rakip kaydı oluşturulmalı."

            cat=c.execute("""
                SELECT id FROM competitor_categories
                WHERE competitor_id=? AND category=? AND parent_category IS NULL
            """,(comp["id"],category)).fetchone()

            if cat:
                catid=cat["id"]
            else:
                catid=c.execute("""
                    INSERT INTO competitor_categories
                    (competitor_id,category,parent_category,level,source,observed_at)
                    VALUES(?,?,?,?,?,?)
                """,(comp["id"],category,None,1,source,now)).lastrowid

            c.execute("""
                INSERT INTO competitor_products
                (competitor_id,category_id,name,brand,price,currency,
                 popularity_signal,source,observed_at)
                VALUES(?,?,?,?,?,?,?,?,?)
            """,(comp["id"],catid,name,brand,price,currency,popularity,source,now))

        return f"Açık ürün gözlemi kaydedildi: {name}"

    def demo(self):
        self.add_competitor(
            "Example Automotive Store","DE","https://example.com"
        )
        self.add_competitor(
            "Example Garden Store","DE","https://example.org"
        )
        self.add_product(
            "Example Automotive Store","Otomotiv",
            "Örnek Motor Yağı 5W-30","Brand A",54.90,"EUR",88,
            "https://example.com/product"
        )
        self.add_product(
            "Example Automotive Store","Otomotiv",
            "Örnek Fren Balatası","Brand B",49.90,"EUR",76,
            "https://example.com/brake"
        )
        self.add_product(
            "Example Garden Store","Bahçe",
            "Örnek Bahçe Hortumu","Brand C",29.90,"EUR",81,
            "https://example.org/hose"
        )

    def report(self):
        with self.connect() as c:
            competitors=c.execute("""
                SELECT id,name,country,source,last_seen
                FROM competitors ORDER BY name
            """).fetchall()

            cats=c.execute("""
                SELECT c.name competitor,COUNT(DISTINCT cc.category) categories
                FROM competitors c
                LEFT JOIN competitor_categories cc ON cc.competitor_id=c.id
                GROUP BY c.id
            """).fetchall()

            products=c.execute("""
                SELECT c.name competitor,cp.name product,
                       cc.category,cp.brand,cp.price,cp.currency,
                       cp.popularity_signal,cp.source
                FROM competitor_products cp
                JOIN competitors c ON c.id=cp.competitor_id
                LEFT JOIN competitor_categories cc ON cc.id=cp.category_id
                ORDER BY cp.popularity_signal DESC
                LIMIT 50
            """).fetchall()

        out=["=== BUZZARD v14 RAKİP / PAZAR İSTİHBARAT RAPORU ===",
             "","AÇIK KAYNAK RAKİPLER / MAĞAZALAR"]
        for r in competitors:
            out.append(
                f"- {r['name']} | ülke={r['country'] or '-'} | kaynak={r['source']}"
            )

        out += ["","KATEGORİ KAPSAMI"]
        for r in cats:
            out.append(f"- {r['competitor']} | açık kategori={r['categories']}")

        out += [
            "",
            "ÜRÜN / FİYAT / POPÜLERLİK SİNYALLERİ",
            "(Popülerlik yalnızca kaynak açıkça yayımlıyorsa sinyaldir.)"
        ]
        for r in products:
            out.append(
                f"- {r['competitor']} | {r['product']} | {r['category']} | "
                f"{r['price'] or '-'} {r['currency'] or ''} | "
                f"popülerlik={r['popularity_signal'] if r['popularity_signal'] is not None else '-'}"
            )

        out += [
            "",
            "ETİK / HUKUKİ KURAL:",
            "Yalnızca yasal, kamuya açık ve erişim izni bulunan bilgiler kullanılır.",
            "Gizli ticari bilgi, özel veri veya erişim kısıtını aşma yoktur."
        ]
        return "\\n".join(out)
