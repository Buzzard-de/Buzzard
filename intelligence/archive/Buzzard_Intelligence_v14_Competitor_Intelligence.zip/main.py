import argparse
from buzzard_intelligence.competitor import CompetitorIntel

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v14")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    a=s.add_parser("add")
    a.add_argument("--name",required=True)
    a.add_argument("--country",default="")
    a.add_argument("--source",required=True)

    pr=s.add_parser("product")
    pr.add_argument("--competitor",required=True)
    pr.add_argument("--category",required=True)
    pr.add_argument("--name",required=True)
    pr.add_argument("--brand",default="")
    pr.add_argument("--price",type=float)
    pr.add_argument("--currency",default="EUR")
    pr.add_argument("--popularity",type=float)
    pr.add_argument("--source",required=True)

    args=p.parse_args()
    app=CompetitorIntel()

    if args.cmd=="init":
        app.init(); print("v14 rakip/pazar istihbaratı hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo rakip istihbarat verisi eklendi.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="add":
        app.init(); print(app.add_competitor(args.name,args.country,args.source))
    elif args.cmd=="product":
        app.init()
        print(app.add_product(
            args.competitor,args.category,args.name,args.brand,
            args.price,args.currency,args.popularity,args.source
        ))
    else:
        p.print_help()

if __name__=="__main__":
    main()
