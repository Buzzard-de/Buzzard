# Buzzard Intelligence v15 — Authenticity & Trust Engine

v15 ürün/marka/tedarikçi güven sinyallerini düzenler.

Amaç:
- ürün kaynağını kaydetmek
- marka / üretici iddiasını ayırmak
- belge türlerini kaydetmek
- doğrulama durumunu takip etmek
- risk sinyali oluşturmak
- doğrulanmamış ürünü otomatik olarak "orijinal" kabul etmemek

Durumlar:
UNVERIFIED, PENDING, VERIFIED, REJECTED, DISPUTED

Risk sinyalleri:
- kaynak eksik
- belge eksik
- marka/üretici bilgisi belirsiz
- kaynaklar arasında çelişki
- doğrulama yapılmamış

Bu motor sahtecilik suçlaması üretmez. Sadece "doğrulama ihtiyacı" veya "risk sinyali" üretir.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Ürün ekleme:
```bash
python main.py product --name "Örnek Ürün" --brand "Example" --supplier "Example Supplier"
```

Belge ekleme:
```bash
python main.py evidence --product-id 1 --type INVOICE --issuer "Example Supplier" --reference "DOC-001"
```
