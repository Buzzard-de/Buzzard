import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_trust_v15.db")
STATUSES={"UNVERIFIED","PENDING","VERIFIED","REJECTED","DISPUTED"}

class TrustEngine:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS products(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                brand TEXT,
                supplier TEXT,
                source TEXT,
                status TEXT NOT NULL DEFAULT 'UNVERIFIED',
                trust_score REAL NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS evidence(
                id INTEGER PRIMARY KEY,
                product_id INTEGER NOT NULL,
                evidence_type TEXT NOT NULL,
                issuer TEXT,
                reference TEXT,
                verified INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS trust_events(
                id INTEGER PRIMARY KEY,
                product_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def add_product(self,name,brand,supplier,source):
        now=self.now()
        with self.connect() as c:
            cur=c.execute("""
                INSERT INTO products
                (name,brand,supplier,source,status,trust_score,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?)
            """,(name,brand,supplier,source,"UNVERIFIED",0,now,now))
            pid=cur.lastrowid

            c.execute("""
                INSERT INTO trust_events
                (product_id,event_type,severity,details,created_at)
                VALUES(?,?,?,?,?)
            """,(pid,"UNVERIFIED_PRODUCT","MEDIUM",
                 "Ürün henüz doğrulanmadı.",now))
        return f"Ürün #{pid} kaydedildi: doğrulama bekliyor."

    def add_evidence(self,product_id,etype,issuer,reference):
        now=self.now()
        with self.connect() as c:
            p=c.execute("SELECT id FROM products WHERE id=?",(product_id,)).fetchone()
            if not p:
                return "Ürün bulunamadı."
            c.execute("""
                INSERT INTO evidence
                (product_id,evidence_type,issuer,reference,created_at)
                VALUES(?,?,?,?,?)
            """,(product_id,etype,issuer,reference,now))
            c.execute("""
                UPDATE products SET status='PENDING',updated_at=? WHERE id=?
            """,(now,product_id))
        return f"Ürün #{product_id} için kanıt kaydedildi; doğrulama bekliyor."

    def verify(self,product_id,status,note):
        if status not in STATUSES:
            return "Geçersiz durum: "+", ".join(sorted(STATUSES))
        now=self.now()
        with self.connect() as c:
            p=c.execute("SELECT id FROM products WHERE id=?",(product_id,)).fetchone()
            if not p:
                return "Ürün bulunamadı."

            # Basit açıklanabilir skor; üretim sisteminde daha kapsamlı kurallar eklenebilir.
            score={"UNVERIFIED":0,"PENDING":35,"VERIFIED":100,
                   "REJECTED":0,"DISPUTED":20}[status]

            c.execute("""
                UPDATE products SET status=?,trust_score=?,updated_at=? WHERE id=?
            """,(status,score,now,product_id))

            severity="INFO" if status=="VERIFIED" else "HIGH"
            c.execute("""
                INSERT INTO trust_events
                (product_id,event_type,severity,details,created_at)
                VALUES(?,?,?,?,?)
            """,(product_id,"STATUS_CHANGE",severity,note or status,now))
        return f"Ürün #{product_id} -> {status}, güven skoru={score}"

    def demo(self):
        self.add_product(
            "Örnek Orijinal Motor Yağı","Brand A",
            "Example B2B Supplier","supplier-catalog"
        )
        self.add_evidence(1,"INVOICE","Example B2B Supplier","INV-2026-001")
        self.add_evidence(1,"MANUFACTURER_DATA","Brand A","CAT-2026-001")
        self.verify(1,"VERIFIED","Kaynak ve belgeler kontrol edildi.")

        self.add_product(
            "Doğrulanmamış Örnek Ürün","Unknown Brand",
            "Unknown Supplier","marketplace"
        )

    def report(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT p.id,p.name,p.brand,p.supplier,p.status,p.trust_score,
                       COUNT(e.id) evidence_count
                FROM products p
                LEFT JOIN evidence e ON e.product_id=p.id
                GROUP BY p.id
                ORDER BY
                  CASE p.status
                    WHEN 'REJECTED' THEN 1
                    WHEN 'DISPUTED' THEN 2
                    WHEN 'UNVERIFIED' THEN 3
                    WHEN 'PENDING' THEN 4
                    ELSE 5 END,
                  p.id
            """).fetchall()

        out=["=== BUZZARD v15 ORİJİNALİK / GÜVEN RAPORU ==="]
        if not rows:
            out.append("Henüz ürün yok.")
        for r in rows:
            out.append(
                f"- #{r['id']} {r['name']} | marka={r['brand'] or '-'} | "
                f"tedarikçi={r['supplier'] or '-'} | durum={r['status']} | "
                f"skor={r['trust_score']:.0f} | kanıt={r['evidence_count']}"
            )
        out += [
            "",
            "KURAL:",
            "VERIFIED olmadan sistem ürünü otomatik olarak 'orijinal' kabul etmez.",
            "Risk sinyali sahtecilik suçlaması değildir; insan doğrulaması gerektirebilir."
        ]
        return "\\n".join(out)
