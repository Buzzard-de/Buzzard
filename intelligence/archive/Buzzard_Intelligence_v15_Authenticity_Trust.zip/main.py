import argparse
from buzzard_intelligence.trust import TrustEngine

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v15")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    pr=s.add_parser("product")
    pr.add_argument("--name",required=True)
    pr.add_argument("--brand",default="")
    pr.add_argument("--supplier",default="")
    pr.add_argument("--source",default="")

    ev=s.add_parser("evidence")
    ev.add_argument("--product-id",type=int,required=True)
    ev.add_argument("--type",required=True)
    ev.add_argument("--issuer",default="")
    ev.add_argument("--reference",default="")

    vr=s.add_parser("verify")
    vr.add_argument("--product-id",type=int,required=True)
    vr.add_argument("--status",required=True)
    vr.add_argument("--note",default="")

    args=p.parse_args()
    app=TrustEngine()

    if args.cmd=="init":
        app.init(); print("v15 güven/orijinallik motoru hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo doğrulama verileri oluşturuldu.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="product":
        app.init(); print(app.add_product(args.name,args.brand,args.supplier,args.source))
    elif args.cmd=="evidence":
        app.init(); print(app.add_evidence(args.product_id,args.type,args.issuer,args.reference))
    elif args.cmd=="verify":
        app.init(); print(app.verify(args.product_id,args.status,args.note))
    else:
        p.print_help()

if __name__=="__main__":
    main()
