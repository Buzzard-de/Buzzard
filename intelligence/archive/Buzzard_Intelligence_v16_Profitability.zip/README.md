# Buzzard Intelligence v16 — Profitability Engine

v16 ürün bazında gerçek maliyetleri ve net kârı hesaplayan karar destek katmanıdır.

Hesaplamaya dahil edilebilir:
- tedarikçi ürün maliyeti
- dropshipping / tekli gönderim
- ödeme komisyonu
- pazaryeri komisyonu
- kargo
- ambalaj
- reklam
- diğer giderler
- KDV / vergi etkisi için girilen oranlar
- satış fiyatı

Temel Buzzard kuralı:
Net kâr < 0,50 € ise ürün "ekonomik olarak uygun değil" sinyali alır.

Not:
Vergi ve KDV mevzuatı ülkeye ve ürüne göre değişebilir. Bu motor verilen oranlarla matematik yapar; hukuki/vergi danışmanlığı yerine geçmez.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Ürün hesaplama:
```bash
python main.py calc --name "Örnek Ürün" --sale 29.90 --cost 12 --shipping 4 --marketplace 2.99 --payment 0.90 --ads 2 --packaging 0.50 --other 0.30 --tax 0
```
