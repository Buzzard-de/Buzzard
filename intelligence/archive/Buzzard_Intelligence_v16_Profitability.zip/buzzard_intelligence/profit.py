import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_profit_v16.db")
MIN_NET_PROFIT=0.50

class ProfitEngine:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.execute("""
            CREATE TABLE IF NOT EXISTS product_profit(
                id INTEGER PRIMARY KEY,
                product_name TEXT NOT NULL,
                sale_price REAL NOT NULL,
                product_cost REAL NOT NULL,
                shipping REAL NOT NULL,
                marketplace_fee REAL NOT NULL,
                payment_fee REAL NOT NULL,
                advertising REAL NOT NULL,
                packaging REAL NOT NULL,
                other_cost REAL NOT NULL,
                tax_effect REAL NOT NULL,
                total_cost REAL NOT NULL,
                net_profit REAL NOT NULL,
                net_margin REAL NOT NULL,
                status TEXT NOT NULL,
                calculated_at TEXT NOT NULL
            )
            """)

    def calculate(self,name,sale,cost,shipping,marketplace,payment,
                  ads,packaging,other,tax):
        values=[sale,cost,shipping,marketplace,payment,ads,packaging,other,tax]
        if any(v < 0 for v in values):
            return "Negatif maliyet/değer kabul edilmez."

        total=cost+shipping+marketplace+payment+ads+packaging+other+tax
        net=sale-total
        margin=(net/sale*100) if sale else 0

        if net >= MIN_NET_PROFIT:
            status="UYGUN"
        elif net >= 0:
            status="KÂR YETERSİZ"
        else:
            status="ZARAR"

        now=self.now()
        with self.connect() as c:
            c.execute("""
            INSERT INTO product_profit
            (product_name,sale_price,product_cost,shipping,marketplace_fee,
             payment_fee,advertising,packaging,other_cost,tax_effect,
             total_cost,net_profit,net_margin,status,calculated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,(name,sale,cost,shipping,marketplace,payment,ads,packaging,
                 other,tax,total,net,margin,status,now))

        return (
            f"{name}\\n"
            f"Satış: €{sale:.2f}\\n"
            f"Toplam gider: €{total:.2f}\\n"
            f"Net kâr: €{net:.2f}\\n"
            f"Net marj: %{margin:.2f}\\n"
            f"Durum: {status}"
        )

    def demo(self):
        self.calculate(
            "Örnek Ürün A",29.90,12,4,2.99,.90,2,.50,.30,0
        )
        self.calculate(
            "Örnek Ürün B",9.90,7,1.50,.80,.40,.50,.20,.20,0
        )

    def report(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT product_name,sale_price,total_cost,net_profit,
                       net_margin,status,calculated_at
                FROM product_profit
                ORDER BY calculated_at DESC
                LIMIT 100
            """).fetchall()

        if not rows:
            return "Henüz kârlılık hesabı yok."

        out=["=== BUZZARD v16 KÂRLILIK RAPORU ==="]
        for r in rows:
            out.append(
                f"- {r['product_name']} | satış=€{r['sale_price']:.2f} | "
                f"gider=€{r['total_cost']:.2f} | net=€{r['net_profit']:.2f} | "
                f"marj=%{r['net_margin']:.2f} | {r['status']}"
            )

        out += [
            "",
            f"BUZZARD MİNİMUM NET KÂR EŞİĞİ: €{MIN_NET_PROFIT:.2f}",
            "Bu motor verilen maliyetlerle matematiksel karar desteği üretir."
        ]
        return "\\n".join(out)
