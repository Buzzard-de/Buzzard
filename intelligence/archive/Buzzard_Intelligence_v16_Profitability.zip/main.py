import argparse
from buzzard_intelligence.profit import ProfitEngine

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v16")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    c=s.add_parser("calc")
    c.add_argument("--name",required=True)
    c.add_argument("--sale",type=float,required=True)
    c.add_argument("--cost",type=float,required=True)
    c.add_argument("--shipping",type=float,default=0)
    c.add_argument("--marketplace",type=float,default=0)
    c.add_argument("--payment",type=float,default=0)
    c.add_argument("--ads",type=float,default=0)
    c.add_argument("--packaging",type=float,default=0)
    c.add_argument("--other",type=float,default=0)
    c.add_argument("--tax",type=float,default=0,
                   help="Vergi/KDV etkisi için doğrudan EUR gideri")

    args=p.parse_args()
    app=ProfitEngine()

    if args.cmd=="init":
        app.init(); print("v16 kârlılık motoru hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo kârlılık kayıtları hazır.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="calc":
        app.init()
        print(app.calculate(
            args.name,args.sale,args.cost,args.shipping,args.marketplace,
            args.payment,args.ads,args.packaging,args.other,args.tax
        ))
    else:
        p.print_help()

if __name__=="__main__":
    main()
