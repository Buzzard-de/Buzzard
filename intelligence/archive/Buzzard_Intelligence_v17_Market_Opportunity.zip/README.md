# Buzzard Intelligence v17 — Country & Market Opportunity Engine

v17, ürün/kategori fırsatlarını ülke ve pazar bazında karşılaştırmak için karar-destek iskeletidir.

Kullanılan sinyaller:
- talep/popülerlik sinyali
- rekabet yoğunluğu
- fiyat seviyesi
- kaynak/veri kapsamı
- lojistik maliyeti
- mevzuat/risk puanı
- Buzzard'ın mevcut kategori varlığı

Önemli:
- Skor satış garantisi değildir.
- Girilmeyen veri sıfır olarak değil, veri eksikliği olarak işaretlenir.
- Hukuki/vergi/gümrük kuralları güncel resmi kaynaklarla ayrıca doğrulanmalıdır.
- Bu motor özellikle Almanya, AB, Türkiye ve Körfez gibi öncelikli pazarları karşılaştırabilecek şekilde tasarlanmıştır.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Pazar ekleme:
```bash
python main.py market --country DE --market "Germany" --demand 80 --competition 60 --logistics 85 --risk 20
```

Ürün fırsatı:
```bash
python main.py opportunity --country DE --category "Otomotiv" --product "5W-30 Motor Yağı" --demand 85 --competition 55 --margin 75 --logistics 80 --risk 20
```
