import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_market_v17.db")

class MarketEngine:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS markets(
                id INTEGER PRIMARY KEY,
                country_code TEXT NOT NULL,
                market_name TEXT NOT NULL,
                demand REAL,
                competition REAL,
                logistics REAL,
                risk REAL,
                data_completeness REAL NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(country_code,market_name)
            );

            CREATE TABLE IF NOT EXISTS opportunities(
                id INTEGER PRIMARY KEY,
                country_code TEXT NOT NULL,
                category TEXT NOT NULL,
                product TEXT NOT NULL,
                demand REAL,
                competition REAL,
                margin REAL,
                logistics REAL,
                risk REAL,
                score REAL,
                data_completeness REAL NOT NULL,
                created_at TEXT NOT NULL
            );
            """)

    def completeness(self, values):
        return round(sum(v is not None for v in values)/len(values)*100,1)

    def add_market(self,country,market,demand,competition,logistics,risk):
        comp=self.completeness([demand,competition,logistics,risk])
        now=self.now()
        with self.connect() as c:
            c.execute("""
            INSERT OR REPLACE INTO markets
            (country_code,market_name,demand,competition,logistics,risk,
             data_completeness,created_at)
            VALUES(?,?,?,?,?,?,?,?)
            """,(country,market,demand,competition,logistics,risk,comp,now))
        return f"Pazar kaydedildi: {market} ({country}) | veri kapsamı %{comp:.1f}"

    def score(self,demand,competition,margin,logistics,risk):
        vals=[demand,competition,margin,logistics,risk]
        if any(v is None for v in vals):
            return None
        # competition ve risk ters yönde; diğerleri pozitif.
        score=(demand*0.30 + (100-competition)*0.20 +
               margin*0.25 + logistics*0.15 + (100-risk)*0.10)
        return round(score,1)

    def add_opportunity(self,country,category,product,demand,
                        competition,margin,logistics,risk):
        comp=self.completeness([demand,competition,margin,logistics,risk])
        score=self.score(demand,competition,margin,logistics,risk)
        now=self.now()
        with self.connect() as c:
            c.execute("""
            INSERT INTO opportunities
            (country_code,category,product,demand,competition,margin,
             logistics,risk,score,data_completeness,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)
            """,(country,category,product,demand,competition,margin,
                 logistics,risk,score,comp,now))
        label=f"{score:.1f}" if score is not None else "VERİ YETERSİZ"
        return f"Fırsat kaydedildi: {product} | {country} | skor={label} | veri=%{comp:.1f}"

    def demo(self):
        self.add_market("DE","Germany",85,70,90,15)
        self.add_market("TR","Türkiye",78,65,70,30)
        self.add_market("AE","UAE",82,55,68,25)
        self.add_market("SA","Saudi Arabia",80,60,62,28)

        self.add_opportunity("DE","Otomotiv","5W-30 Motor Yağı",88,65,80,92,15)
        self.add_opportunity("TR","Otomotiv","5W-30 Motor Yağı",82,58,76,72,28)
        self.add_opportunity("AE","Otomotiv","5W-30 Motor Yağı",84,50,78,68,22)
        self.add_opportunity("SA","Otomotiv","5W-30 Motor Yağı",81,57,75,61,25)

    def report(self):
        with self.connect() as c:
            markets=c.execute("""
                SELECT country_code,market_name,demand,competition,
                       logistics,risk,data_completeness
                FROM markets ORDER BY data_completeness DESC,market_name
            """).fetchall()

            opp=c.execute("""
                SELECT country_code,category,product,score,data_completeness,
                       demand,competition,margin,logistics,risk
                FROM opportunities
                ORDER BY score DESC
            """).fetchall()

        out=["=== BUZZARD v17 PAZAR & ÜLKE FIRSAT RAPORU ===","",
             "PAZARLAR"]
        for r in markets:
            out.append(
                f"- {r['market_name']} [{r['country_code']}] | "
                f"talep={r['demand'] if r['demand'] is not None else '-'} | "
                f"rekabet={r['competition'] if r['competition'] is not None else '-'} | "
                f"lojistik={r['logistics'] if r['logistics'] is not None else '-'} | "
                f"risk={r['risk'] if r['risk'] is not None else '-'} | "
                f"veri=%{r['data_completeness']:.1f}"
            )

        out += ["","ÜRÜN FIRSATLARI"]
        for r in opp:
            score=f"{r['score']:.1f}" if r['score'] is not None else "VERİ YETERSİZ"
            out.append(
                f"- {r['product']} | {r['category']} | {r['country_code']} | "
                f"fırsat={score} | veri=%{r['data_completeness']:.1f}"
            )

        out += [
            "",
            "KURAL:",
            "Skor karşılaştırma aracıdır; satış veya kâr garantisi değildir.",
            "Eksik veri bulunan pazarlar kesin sıralamaya sokulmamalıdır."
        ]
        return "\\n".join(out)
