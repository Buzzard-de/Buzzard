import argparse
from buzzard_intelligence.market import MarketEngine

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v17")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    m=s.add_parser("market")
    m.add_argument("--country",required=True)
    m.add_argument("--market",required=True)
    m.add_argument("--demand",type=float,default=None)
    m.add_argument("--competition",type=float,default=None)
    m.add_argument("--logistics",type=float,default=None)
    m.add_argument("--risk",type=float,default=None)

    o=s.add_parser("opportunity")
    o.add_argument("--country",required=True)
    o.add_argument("--category",required=True)
    o.add_argument("--product",required=True)
    o.add_argument("--demand",type=float,default=None)
    o.add_argument("--competition",type=float,default=None)
    o.add_argument("--margin",type=float,default=None)
    o.add_argument("--logistics",type=float,default=None)
    o.add_argument("--risk",type=float,default=None)

    args=p.parse_args()
    app=MarketEngine()

    if args.cmd=="init":
        app.init(); print("v17 pazar fırsat motoru hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo pazar verileri hazır.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="market":
        app.init()
        print(app.add_market(args.country,args.market,args.demand,args.competition,args.logistics,args.risk))
    elif args.cmd=="opportunity":
        app.init()
        print(app.add_opportunity(
            args.country,args.category,args.product,args.demand,
            args.competition,args.margin,args.logistics,args.risk
        ))
    else:
        p.print_help()

if __name__=="__main__":
    main()
