# Buzzard Intelligence v18 — Supplier Intelligence

v18, tedarikçi araştırmasını ve entegrasyon uygunluğunu sistematik hale getirir.

Değerlendirilen alanlar:
- şirket / tedarikçi kimliği
- ülke
- B2B durumu
- dropshipping
- white-label / blind shipping
- API
- XML / JSON / CSV feed
- eBay / Amazon gibi kanal entegrasyonları
- TecDoc gibi özel katalog/veri desteği
- fatura / belge sinyali
- ürün orijinalliği ve kaynak güveni
- teslimat / lojistik
- iletişim ve kaynak URL'si
- güven ve entegrasyon skorları

Önemli:
- Tedarikçi otomatik olarak "güvenilir" ilan edilmez.
- Skor yalnızca araştırma önceliğidir.
- Gerçek entegrasyon kabiliyeti tedarikçinin resmi dokümanı veya doğrulanmış iletişimiyle ayrıca teyit edilmelidir.
- API'ler farklı kimlik doğrulama, limit ve feed kurallarına sahip olabilir. Örneğin Amazon ve Walmart resmi dokümanlarında kimlik doğrulama ve feed işleme kuralları tanımlıdır. citeturn0search0turn0search3

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Tedarikçi ekleme:
```bash
python main.py supplier --name "Example Supplier" --country DE --b2b yes --source "https://example.com"
```

Yetenek ekleme:
```bash
python main.py capability --supplier "Example Supplier" --name "API" --status yes --evidence "https://example.com/api-docs"
```
