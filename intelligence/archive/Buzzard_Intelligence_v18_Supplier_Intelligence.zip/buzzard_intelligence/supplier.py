import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_supplier_v18.db")

CAPABILITIES=[
    "API","XML","JSON","CSV","Dropshipping","White-label",
    "Blind shipping","eBay integration","Amazon integration",
    "TecDoc","B2B","Invoice","Manufacturer data","Tracking API"
]

class SupplierIntel:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS suppliers(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                country TEXT,
                b2b TEXT,
                source TEXT NOT NULL,
                trust_score REAL DEFAULT 0,
                integration_score REAL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS capabilities(
                id INTEGER PRIMARY KEY,
                supplier_id INTEGER NOT NULL,
                capability TEXT NOT NULL,
                status TEXT NOT NULL,
                evidence TEXT,
                observed_at TEXT NOT NULL,
                UNIQUE(supplier_id,capability)
            );

            CREATE TABLE IF NOT EXISTS supplier_events(
                id INTEGER PRIMARY KEY,
                supplier_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                details TEXT,
                source TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def add_supplier(self,name,country,b2b,source):
        now=self.now()
        with self.connect() as c:
            c.execute("""
            INSERT OR IGNORE INTO suppliers
            (name,country,b2b,source,created_at,updated_at)
            VALUES(?,?,?,?,?,?)
            """,(name,country,b2b,source,now,now))
            c.execute("UPDATE suppliers SET updated_at=? WHERE name=?",(now,name))
        return f"Tedarikçi kaydedildi: {name}"

    def add_capability(self,supplier,capability,status,evidence):
        if capability not in CAPABILITIES:
            # Yeni kabiliyetlere izin ver; standart liste sadece rehberdir.
            pass
        now=self.now()
        with self.connect() as c:
            s=c.execute("SELECT id FROM suppliers WHERE name=?",(supplier,)).fetchone()
            if not s:
                return "Tedarikçi bulunamadı."

            c.execute("""
            INSERT OR REPLACE INTO capabilities
            (supplier_id,capability,status,evidence,observed_at)
            VALUES(?,?,?,?,?)
            """,(s["id"],capability,status,evidence,now))

            c.execute("""
            UPDATE suppliers SET updated_at=? WHERE id=?
            """,(now,s["id"]))

        return f"{supplier}: {capability} -> {status}"

    def recalculate(self):
        with self.connect() as c:
            suppliers=c.execute("SELECT id,b2b FROM suppliers").fetchall()
            for s in suppliers:
                rows=c.execute("""
                    SELECT capability,status,evidence
                    FROM capabilities WHERE supplier_id=?
                """,(s["id"],)).fetchall()

                verified=[r for r in rows if str(r["status"]).lower() in
                          ("yes","verified","supported")]
                integration_names={"API","XML","JSON","CSV","Dropshipping",
                                   "White-label","Blind shipping",
                                   "eBay integration","Amazon integration",
                                   "TecDoc","Tracking API"}
                integration=sum(
                    r["capability"] in integration_names for r in verified
                )
                integration_score=min(100, round(integration/8*100,1))

                trust=0
                if str(s["b2b"]).lower() in ("yes","verified"):
                    trust+=25
                trust+=min(50,len(verified)*7)
                trust+=25 if any(r["evidence"] for r in verified) else 0
                trust=min(100,trust)

                c.execute("""
                UPDATE suppliers
                SET trust_score=?,integration_score=?,updated_at=?
                WHERE id=?
                """,(trust,integration_score,self.now(),s["id"]))

    def demo(self):
        self.add_supplier(
            "Example Automotive B2B","DE","yes",
            "https://example.com"
        )
        for cap in ["B2B","API","XML","Dropshipping","White-label",
                    "TecDoc","Invoice","Tracking API"]:
            self.add_capability(
                "Example Automotive B2B",cap,"verified",
                "https://example.com/docs"
            )

        self.add_supplier(
            "Example General Supplier","DE","unknown",
            "https://example.org"
        )
        self.add_capability(
            "Example General Supplier","API","unknown",""
        )
        self.recalculate()

    def report(self):
        self.recalculate()
        with self.connect() as c:
            suppliers=c.execute("""
                SELECT id,name,country,b2b,trust_score,integration_score,source
                FROM suppliers
                ORDER BY integration_score DESC,trust_score DESC,name
            """).fetchall()

            caps=c.execute("""
                SELECT s.name supplier,COUNT(c.id) capability_count
                FROM suppliers s
                LEFT JOIN capabilities c ON c.supplier_id=s.id
                GROUP BY s.id
                ORDER BY capability_count DESC
            """).fetchall()

        out=["=== BUZZARD v18 TEDARİKÇİ İSTİHBARAT RAPORU ===",
             "",
             "TEDARİKÇİLER"]
        for r in suppliers:
            out.append(
                f"- {r['name']} | {r['country'] or '-'} | B2B={r['b2b']} | "
                f"güven={r['trust_score']:.1f} | entegrasyon={r['integration_score']:.1f} | "
                f"{r['source']}"
            )

        out += ["","KABİLİYET KAPSAMI"]
        for r in caps:
            out.append(f"- {r['supplier']} | doğrulanmış/kayıtlı kabiliyet={r['capability_count']}")

        out += [
            "",
            "KURAL:",
            "Skor tedarikçi seçimini otomatik olarak kesinleştirmez.",
            "API/XML/feed desteği resmi doküman veya doğrulanmış tedarikçi bilgisiyle teyit edilmelidir.",
            "Entegrasyon tasarımında API kimlik doğrulaması, rate limit, pagination ve feed işleme kuralları dikkate alınmalıdır. citeturn0search0turn0search3turn0search6"
        ]
        return "\\n".join(out)
