import argparse
from buzzard_intelligence.supplier import SupplierIntel

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v18")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    a=s.add_parser("supplier")
    a.add_argument("--name",required=True)
    a.add_argument("--country",default="")
    a.add_argument("--b2b",default="unknown")
    a.add_argument("--source",required=True)

    c=s.add_parser("capability")
    c.add_argument("--supplier",required=True)
    c.add_argument("--name",required=True)
    c.add_argument("--status",required=True)
    c.add_argument("--evidence",default="")

    args=p.parse_args()
    app=SupplierIntel()

    if args.cmd=="init":
        app.init(); print("v18 tedarikçi istihbaratı hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo tedarikçi verileri hazır.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="supplier":
        app.init(); print(app.add_supplier(args.name,args.country,args.b2b,args.source))
    elif args.cmd=="capability":
        app.init(); print(app.add_capability(args.supplier,args.name,args.status,args.evidence))
    else:
        p.print_help()

if __name__=="__main__":
    main()
