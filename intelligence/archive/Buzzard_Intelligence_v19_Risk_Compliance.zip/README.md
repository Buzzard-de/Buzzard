# Buzzard Intelligence v19 — Risk & Compliance Engine

v19, ürün/tedarikçi/pazar araştırmasındaki risk sinyallerini tek yerde toplar.

Kontroller:
- ürün/marka doğrulama durumu
- tedarikçi doğrulama durumu
- kaynak/evidence eksikliği
- ülke/pazar risk alanları
- mevzuat doğrulama gereksinimi
- gümrük/ithalat doğrulama gereksinimi
- marka/IP inceleme gereksinimi
- ürün güvenliği inceleme gereksinimi
- veri gizliliği inceleme gereksinimi
- risk seviyesi ve öncelik

ÖNEMLİ:
Bu motor hukuki danışmanlık vermez ve bir ürünün hukuken uygun olduğunu otomatik olarak ilan etmez.
Risk sinyali = insan tarafından/resmî kaynaklardan ayrıca doğrulama gerektiren konu.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Risk olayı ekleme:
```bash
python main.py risk --entity "Örnek Ürün" --type PRODUCT_SAFETY --severity HIGH --source "official-source"
```
