import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB = Path("buzzard_risk_v19.db")

SEVERITIES = {"LOW", "MEDIUM", "HIGH", "CRITICAL"}
STATUSES = {"OPEN", "UNDER_REVIEW", "VERIFIED", "RESOLVED", "REJECTED"}

RISK_TYPES = {
    "AUTHENTICITY",
    "SUPPLIER",
    "PRODUCT_SAFETY",
    "MARKET_ACCESS",
    "CUSTOMS",
    "TAX",
    "IP_TRADEMARK",
    "DATA_PRIVACY",
    "DOCUMENTATION",
    "SOURCE_QUALITY",
    "OTHER"
}

class RiskEngine:
    def connect(self):
        c = sqlite3.connect(DB)
        c.row_factory = sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS risks(
                id INTEGER PRIMARY KEY,
                entity TEXT NOT NULL,
                risk_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                details TEXT,
                source TEXT,
                country TEXT,
                status TEXT NOT NULL DEFAULT 'OPEN',
                priority_score REAL NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS risk_reviews(
                id INTEGER PRIMARY KEY,
                risk_id INTEGER NOT NULL,
                reviewer TEXT NOT NULL,
                status TEXT NOT NULL,
                note TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS risk_rules(
                id INTEGER PRIMARY KEY,
                rule_name TEXT NOT NULL UNIQUE,
                description TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1
            );
            """)

            rules = [
                ("authenticity_check",
                 "Ürünün/markanın orijinalliği ve tedarik zinciri doğrulanmalı."),
                ("supplier_check",
                 "Tedarikçi kimliği, şirket bilgileri ve ticari belgeler doğrulanmalı."),
                ("product_safety_check",
                 "Ürünün ilgili güvenlik/uygunluk gereklilikleri resmî kaynaklardan doğrulanmalı."),
                ("market_access_check",
                 "Hedef pazarda satışa ilişkin gereklilikler doğrulanmalı."),
                ("customs_check",
                 "İthalat, gümrük ve ürün sınıflandırması ayrıca doğrulanmalı."),
                ("tax_check",
                 "Vergi/KDV uygulaması güncel ve yetkili kaynaklardan doğrulanmalı."),
                ("ip_check",
                 "Marka, tasarım ve diğer fikrî mülkiyet riskleri incelenmeli."),
                ("privacy_check",
                 "Kişisel veri işleme varsa ilgili gizlilik yükümlülükleri incelenmeli."),
                ("source_quality_check",
                 "Bilginin kaynağı ve güncelliği doğrulanmalı.")
            ]
            for name, desc in rules:
                c.execute("""
                    INSERT OR IGNORE INTO risk_rules
                    (rule_name,description)
                    VALUES(?,?)
                """, (name, desc))

    def priority(self, severity, source):
        base = {
            "LOW": 20,
            "MEDIUM": 45,
            "HIGH": 75,
            "CRITICAL": 100
        }.get(severity, 45)
        if not source:
            base = min(100, base + 10)
        return float(base)

    def add_risk(self, entity, risk_type, severity,
                 details, source, country):
        risk_type = risk_type.upper()
        severity = severity.upper()

        if risk_type not in RISK_TYPES:
            return "Geçersiz risk tipi: " + ", ".join(sorted(RISK_TYPES))
        if severity not in SEVERITIES:
            return "Geçersiz önem seviyesi: " + ", ".join(sorted(SEVERITIES))

        now = self.now()
        score = self.priority(severity, source)

        with self.connect() as c:
            cur = c.execute("""
                INSERT INTO risks
                (entity,risk_type,severity,details,source,country,status,
                 priority_score,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?, ?,?,?)
            """, (
                entity, risk_type, severity, details, source, country,
                "OPEN", score, now, now
            ))
            rid = cur.lastrowid

        return f"Risk #{rid} kaydedildi | öncelik={score:.0f}/100"

    def verify(self, risk_id, status, note):
        status = status.upper()
        if status not in STATUSES:
            return "Geçersiz durum: " + ", ".join(sorted(STATUSES))

        now = self.now()
        with self.connect() as c:
            r = c.execute(
                "SELECT id FROM risks WHERE id=?", (risk_id,)
            ).fetchone()
            if not r:
                return "Risk bulunamadı."

            c.execute("""
                UPDATE risks
                SET status=?,updated_at=?
                WHERE id=?
            """, (status, now, risk_id))

            c.execute("""
                INSERT INTO risk_reviews
                (risk_id,reviewer,status,note,created_at)
                VALUES(?,?,?,?,?)
            """, (risk_id, "Council Manager", status, note, now))

        return f"Risk #{risk_id} -> {status}"

    def demo(self):
        self.add_risk(
            "Örnek Motor Yağı",
            "AUTHENTICITY",
            "HIGH",
            "Marka/tedarik zinciri belgeleri doğrulanmalı.",
            "supplier-catalog",
            "DE"
        )
        self.add_risk(
            "Örnek Ürün",
            "PRODUCT_SAFETY",
            "MEDIUM",
            "Hedef pazardaki ürün güvenliği gereklilikleri incelenmeli.",
            "",
            "DE"
        )
        self.add_risk(
            "Example Supplier",
            "SUPPLIER",
            "LOW",
            "Şirket bilgilerinin doğrulanması gerekiyor.",
            "public-company-source",
            "DE"
        )

    def report(self):
        with self.connect() as c:
            rows = c.execute("""
                SELECT id,entity,risk_type,severity,details,source,
                       country,status,priority_score,created_at
                FROM risks
                WHERE status NOT IN ('RESOLVED','REJECTED')
                ORDER BY priority_score DESC,created_at DESC
            """).fetchall()

            counts = c.execute("""
                SELECT severity,COUNT(*) n
                FROM risks
                WHERE status NOT IN ('RESOLVED','REJECTED')
                GROUP BY severity
            """).fetchall()

        out = [
            "=== BUZZARD v19 RİSK & UYUM RAPORU ===",
            "",
            "AÇIK RİSKLER"
        ]

        if not rows:
            out.append("- Açık risk yok.")
        else:
            for r in rows:
                out.append(
                    f"- #{r['id']} [{r['severity']}] {r['risk_type']} | "
                    f"{r['entity']} | ülke={r['country'] or '-'} | "
                    f"öncelik={r['priority_score']:.0f} | "
                    f"durum={r['status']} | kaynak={r['source'] or '-'}"
                )
                if r["details"]:
                    out.append(f"  → {r['details']}")

        out += ["", "SEVİYE ÖZETİ"]
        for r in counts:
            out.append(f"- {r['severity']}: {r['n']}")

        out += [
            "",
            "KURAL:",
            "Risk sinyali hukuki ihlal veya sahtecilik hükmü değildir.",
            "Kesin uygunluk/uygunsuzluk, ilgili güncel resmî kaynaklar ve gerektiğinde uzman incelemesiyle doğrulanmalıdır.",
            "Kritik riskler çözülmeden otomatik ticari onay verilmemelidir."
        ]

        return "\\n".join(out)
