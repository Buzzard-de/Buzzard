import argparse
from buzzard_intelligence.risk import RiskEngine

def main():
    p = argparse.ArgumentParser(description="Buzzard Intelligence v19")
    s = p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    r = s.add_parser("risk")
    r.add_argument("--entity", required=True)
    r.add_argument("--type", required=True)
    r.add_argument("--severity", required=True)
    r.add_argument("--details", default="")
    r.add_argument("--source", default="")
    r.add_argument("--country", default="")

    v = s.add_parser("verify")
    v.add_argument("--risk-id", type=int, required=True)
    v.add_argument("--status", required=True)
    v.add_argument("--note", default="")

    args = p.parse_args()
    app = RiskEngine()

    if args.cmd == "init":
        app.init()
        print("v19 Risk & Compliance motoru hazır.")
    elif args.cmd == "demo":
        app.init()
        app.demo()
        print("Demo risk kayıtları oluşturuldu.")
    elif args.cmd == "report":
        app.init()
        print(app.report())
    elif args.cmd == "risk":
        app.init()
        print(app.add_risk(
            args.entity, args.type, args.severity,
            args.details, args.source, args.country
        ))
    elif args.cmd == "verify":
        app.init()
        print(app.verify(args.risk_id, args.status, args.note))
    else:
        p.print_help()

if __name__ == "__main__":
    main()
