# Buzzard Intelligence v20 — Council Orchestrator

v20, v10 Kurmay Heyeti katmanını gerçek bir görev/iş akışı yöneticisine dönüştüren çekirdektir.

Amaç:
- farklı uzman ajanlara görev dağıtmak
- görev durumlarını takip etmek
- bağımlılıkları yönetmek
- aynı konu için farklı uzman görüşlerini toplamak
- kanıtları görevlere bağlamak
- çelişkili görüşleri işaretlemek
- sentez/özet görevi oluşturmak
- nihai kararı otomatik vermemek

Örnek uzmanlar:
- Market Intelligence
- Category Intelligence
- Competitor Intelligence
- Supplier Intelligence
- Authenticity & Trust
- Profitability
- Risk & Compliance

Kurulum:
```bash
python main.py init
python main.py demo
python main.py board
python main.py create --title "5W-30 Motor Yağı araştırması" --priority 9
```

Görev atama:
```bash
python main.py assign --task-id 1 --agent "Supplier Intelligence"
```

Uzman görüşü:
```bash
python main.py opinion --task-id 1 --agent "Risk & Compliance" --decision "REVIEW" --confidence 0.90 --note "Belge kontrolü gerekli."
```

v20, orkestrasyon katmanıdır. Gerçek LLM/agent sağlayıcıları ve üretim API kimlik doğrulaması sonraki entegrasyonda bağlanabilir.
