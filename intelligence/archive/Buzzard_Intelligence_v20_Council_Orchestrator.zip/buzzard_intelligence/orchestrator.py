import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB = Path("buzzard_council_v20.db")

STATUSES = {
    "NEW", "ASSIGNED", "IN_PROGRESS",
    "WAITING", "REVIEW", "COMPLETED", "BLOCKED"
}

class CouncilOrchestrator:
    def connect(self):
        c = sqlite3.connect(DB)
        c.row_factory = sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS agents(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                role TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS tasks(
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                details TEXT,
                priority INTEGER NOT NULL,
                status TEXT NOT NULL,
                created_by TEXT NOT NULL,
                assigned_to TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS task_dependencies(
                id INTEGER PRIMARY KEY,
                task_id INTEGER NOT NULL,
                depends_on_task_id INTEGER NOT NULL,
                UNIQUE(task_id, depends_on_task_id)
            );

            CREATE TABLE IF NOT EXISTS opinions(
                id INTEGER PRIMARY KEY,
                task_id INTEGER NOT NULL,
                agent TEXT NOT NULL,
                decision TEXT NOT NULL,
                confidence REAL NOT NULL,
                note TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS evidence(
                id INTEGER PRIMARY KEY,
                task_id INTEGER NOT NULL,
                agent TEXT NOT NULL,
                source TEXT NOT NULL,
                claim TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS orchestration_log(
                id INTEGER PRIMARY KEY,
                task_id INTEGER,
                action TEXT NOT NULL,
                actor TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );
            """)

            default_agents = [
                ("Market Intelligence", "Pazar ve ülke araştırması"),
                ("Category Intelligence", "Kategori ve ürün keşfi"),
                ("Competitor Intelligence", "Açık kaynak rakip istihbaratı"),
                ("Supplier Intelligence", "Tedarikçi ve entegrasyon araştırması"),
                ("Authenticity & Trust", "Orijinallik ve güven"),
                ("Profitability", "Kârlılık analizi"),
                ("Risk & Compliance", "Risk ve uyum incelemesi"),
                ("Council Manager", "Kurmay orkestrasyonu")
            ]

            for name, role in default_agents:
                c.execute("""
                    INSERT OR IGNORE INTO agents
                    (name,role,created_at)
                    VALUES(?,?,?)
                """, (name, role, self.now()))

    def create_task(self, title, details="", priority=5,
                    created_by="Council Manager"):
        priority = max(1, min(10, priority))
        now = self.now()

        with self.connect() as c:
            cur = c.execute("""
                INSERT INTO tasks
                (title,details,priority,status,created_by,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?)
            """, (
                title, details, priority, "NEW",
                created_by, now, now
            ))
            task_id = cur.lastrowid

            c.execute("""
                INSERT INTO orchestration_log
                (task_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """, (
                task_id, "CREATED", created_by, title, now
            ))

        return f"Kurmay görevi #{task_id} oluşturuldu."

    def assign(self, task_id, agent):
        now = self.now()

        with self.connect() as c:
            a = c.execute(
                "SELECT id FROM agents WHERE name=? AND active=1",
                (agent,)
            ).fetchone()
            if not a:
                return "Aktif uzman bulunamadı."

            t = c.execute(
                "SELECT id FROM tasks WHERE id=?",
                (task_id,)
            ).fetchone()
            if not t:
                return "Görev bulunamadı."

            c.execute("""
                UPDATE tasks
                SET assigned_to=?,status='ASSIGNED',updated_at=?
                WHERE id=?
            """, (agent, now, task_id))

            c.execute("""
                INSERT INTO orchestration_log
                (task_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """, (
                task_id, "ASSIGNED", "Council Manager",
                agent, now
            ))

        return f"Görev #{task_id} -> {agent}"

    def add_opinion(self, task_id, agent, decision,
                    confidence=0.8, note=""):
        confidence = max(0.0, min(1.0, confidence))
        now = self.now()

        with self.connect() as c:
            t = c.execute(
                "SELECT id FROM tasks WHERE id=?",
                (task_id,)
            ).fetchone()
            if not t:
                return "Görev bulunamadı."

            c.execute("""
                INSERT INTO opinions
                (task_id,agent,decision,confidence,note,created_at)
                VALUES(?,?,?,?,?,?)
            """, (
                task_id, agent, decision,
                confidence, note, now
            ))

            c.execute("""
                UPDATE tasks
                SET status='REVIEW',updated_at=?
                WHERE id=?
            """, (now, task_id))

            c.execute("""
                INSERT INTO orchestration_log
                (task_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """, (
                task_id, "OPINION_ADDED", agent,
                decision, now
            ))

        return f"{agent} görüşü görev #{task_id} için kaydedildi."

    def demo(self):
        task = self.create_task(
            "5W-30 Motor Yağı pazar değerlendirmesi",
            "Talep, rakip, tedarikçi, kârlılık ve risk birlikte incelensin.",
            9
        )

        task_id = int(task.split("#")[1].split()[0])

        for agent in [
            "Market Intelligence",
            "Competitor Intelligence",
            "Supplier Intelligence",
            "Profitability",
            "Risk & Compliance"
        ]:
            self.assign(task_id, agent)

        self.add_opinion(
            task_id,
            "Market Intelligence",
            "POSITIVE",
            0.82,
            "Pazar talep sinyali olumlu."
        )
        self.add_opinion(
            task_id,
            "Risk & Compliance",
            "REVIEW",
            0.91,
            "Ürün ve belge uygunluğu ayrıca doğrulanmalı."
        )

    def board(self):
        with self.connect() as c:
            tasks = c.execute("""
                SELECT id,title,priority,status,assigned_to,
                       created_by,created_at,updated_at
                FROM tasks
                ORDER BY
                    CASE status
                      WHEN 'BLOCKED' THEN 1
                      WHEN 'REVIEW' THEN 2
                      WHEN 'IN_PROGRESS' THEN 3
                      WHEN 'ASSIGNED' THEN 4
                      ELSE 5
                    END,
                    priority DESC,created_at DESC
            """).fetchall()

            opinions = c.execute("""
                SELECT task_id,agent,decision,confidence,note,created_at
                FROM opinions
                ORDER BY created_at DESC
                LIMIT 50
            """).fetchall()

            agents = c.execute("""
                SELECT name,role,active FROM agents
                ORDER BY name
            """).fetchall()

        out = [
            "=== BUZZARD v20 KURMAY HEYETİ PANOSU ===",
            "",
            "GÖREVLER"
        ]

        if not tasks:
            out.append("- Görev yok.")
        else:
            for r in tasks:
                out.append(
                    f"#{r['id']} [{r['priority']}/10] {r['title']} | "
                    f"durum={r['status']} | uzman={r['assigned_to'] or '-'}"
                )

        out += ["", "SON UZMAN GÖRÜŞLERİ"]

        if not opinions:
            out.append("- Görüş yok.")
        else:
            for r in opinions:
                out.append(
                    f"- görev #{r['task_id']} | {r['agent']} | "
                    f"{r['decision']} | güven={r['confidence']:.2f} | "
                    f"{r['note'] or '-'}"
                )

        out += ["", "UZMANLAR"]
        for r in agents:
            out.append(
                f"- {r['name']} | {r['role']} | aktif={bool(r['active'])}"
            )

        out += [
            "",
            "ORKESTRASYON KURALI:",
            "Uzman ajanlar kendi alanlarında veri ve görüş üretir.",
            "Çelişen görüşler saklanır; sistem bunları silmez veya gizlemez.",
            "Sentez görevi oluşturulabilir, fakat nihai ticari karar otomatik verilmez.",
            "Yetkili insan/yönetici son kararı verir."
        ]

        return "\\n".join(out)
