import argparse
from buzzard_intelligence.orchestrator import CouncilOrchestrator

def main():
    p = argparse.ArgumentParser(description="Buzzard Intelligence v20")
    s = p.add_subparsers(dest="cmd")

    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("board")

    c = s.add_parser("create")
    c.add_argument("--title", required=True)
    c.add_argument("--details", default="")
    c.add_argument("--priority", type=int, default=5)
    c.add_argument("--created-by", default="Council Manager")

    a = s.add_parser("assign")
    a.add_argument("--task-id", type=int, required=True)
    a.add_argument("--agent", required=True)

    o = s.add_parser("opinion")
    o.add_argument("--task-id", type=int, required=True)
    o.add_argument("--agent", required=True)
    o.add_argument("--decision", required=True)
    o.add_argument("--confidence", type=float, default=0.8)
    o.add_argument("--note", default="")

    args = p.parse_args()
    app = CouncilOrchestrator()

    if args.cmd == "init":
        app.init()
        print("v20 Kurmay Heyeti Orchestrator hazır.")
    elif args.cmd == "demo":
        app.init()
        app.demo()
        print("Demo kurmay görevleri oluşturuldu.")
    elif args.cmd == "board":
        app.init()
        print(app.board())
    elif args.cmd == "create":
        app.init()
        print(app.create_task(args.title, args.details, args.priority, args.created_by))
    elif args.cmd == "assign":
        app.init()
        print(app.assign(args.task_id, args.agent))
    elif args.cmd == "opinion":
        app.init()
        print(app.add_opinion(
            args.task_id, args.agent, args.decision,
            args.confidence, args.note
        ))
    else:
        p.print_help()

if __name__ == "__main__":
    main()
