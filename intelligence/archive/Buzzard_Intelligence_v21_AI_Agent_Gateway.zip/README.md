# Buzzard Intelligence v21 — AI Agent Gateway

v21, Kurmay Heyeti'nin gerçek AI modellerine bağlanması için sağlayıcıdan bağımsız bir gateway katmanı kurar.

Amaç:
- farklı AI sağlayıcılarını tek arayüzden yönetmek
- model/ajan rolü tanımlamak
- prompt ve görev bağlamını ayırmak
- ortak hafızadan bağlam göndermek
- yapılandırılmış JSON çıktı beklemek
- timeout/retry yönetmek
- API anahtarlarını ortam değişkenlerinde tutmak
- sağlayıcı değiştiğinde Kurmay Heyeti kodunu değiştirmemek

Güvenlik:
- API anahtarları kaynak koduna yazılmaz.
- Sağlayıcı URL'leri ve anahtarları config/env üzerinden gelir.
- v21 otomatik ticari karar vermez.
- AI çıktısı "görüş/sinyal" olarak kaydedilmeli ve v20 Kurmay Heyeti tarafından değerlendirilmelidir.

Örnek ortam değişkenleri:
```powershell
$env:BUZZARD_AI_BASE_URL="https://api.example.com/v1"
$env:BUZZARD_AI_API_KEY="..."
$env:BUZZARD_AI_MODEL="..."
```

Çalıştırma:
```bash
python main.py init
python main.py providers
python main.py demo
```

Not:
Bu sürüm gerçek bir AI sağlayıcısına otomatik olarak bağlanmaz; gateway ve provider adapter sözleşmesini hazırlar. Gerçek sağlayıcı entegrasyonu, seçilen sağlayıcının güncel resmi API dokümantasyonuna göre ayrı adapter olarak eklenmelidir.
