import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
import requests

DB=Path("buzzard_ai_gateway_v21.db")

class AIGateway:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS providers(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                base_url TEXT NOT NULL,
                model TEXT NOT NULL,
                api_key_env TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS agent_profiles(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                role TEXT NOT NULL,
                system_instruction TEXT NOT NULL,
                preferred_provider TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS runs(
                id INTEGER PRIMARY KEY,
                agent TEXT NOT NULL,
                provider TEXT,
                model TEXT,
                prompt TEXT NOT NULL,
                response TEXT,
                status TEXT NOT NULL,
                error TEXT,
                created_at TEXT NOT NULL
            );
            """)

            agents=[
                ("Market Intelligence","Pazar araştırması",
                 "Açık kaynaklardan kanıtlı pazar sinyalleri topla. Satış verisi yoksa uydurma."),
                ("Category Intelligence","Kategori keşfi",
                 "Kategori ağacını ve ürün fırsatlarını kaynaklı şekilde incele."),
                ("Competitor Intelligence","Rakip istihbaratı",
                 "Yalnızca yasal ve kamuya açık rakip bilgilerini kullan."),
                ("Supplier Intelligence","Tedarikçi araştırması",
                 "Tedarikçi güveni ve entegrasyon kabiliyetini doğrulanabilir kaynaklarla incele."),
                ("Authenticity & Trust","Orijinallik",
                 "Ürün/marka orijinalliği için kanıt ve doğrulama ihtiyacını belirle."),
                ("Profitability","Kârlılık",
                 "Verilen maliyetlerle matematiksel net kâr ve marj analizi yap."),
                ("Risk & Compliance","Risk ve uyum",
                 "Risk sinyallerini belirle; hukuki hüküm uydurma."),
                ("Council Manager","Kurmay yöneticisi",
                 "Uzman görüşlerini karşılaştır, çelişkileri göster, nihai kararı otomatik verme.")
            ]
            for name,role,instruction in agents:
                c.execute("""
                    INSERT OR IGNORE INTO agent_profiles
                    (name,role,system_instruction,created_at)
                    VALUES(?,?,?,?)
                """,(name,role,instruction,self.now()))

    def add_provider(self,name,base_url,model,api_key_env):
        with self.connect() as c:
            c.execute("""
                INSERT OR REPLACE INTO providers
                (name,base_url,model,api_key_env,created_at)
                VALUES(?,?,?,?,?)
            """,(name,base_url,model,api_key_env,self.now()))
        return f"AI provider kaydedildi: {name}"

    def providers(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT name,base_url,model,api_key_env,enabled
                FROM providers ORDER BY name
            """).fetchall()
        if not rows:
            return "Henüz AI provider tanımlanmadı."
        out=["=== BUZZARD AI PROVIDERS ==="]
        for r in rows:
            out.append(
                f"- {r['name']} | model={r['model']} | "
                f"key_env={r['api_key_env']} | aktif={bool(r['enabled'])}"
            )
        return "\\n".join(out)

    def call_provider(self,provider_name,system_prompt,user_prompt):
        with self.connect() as c:
            p=c.execute("""
                SELECT * FROM providers
                WHERE name=? AND enabled=1
            """,(provider_name,)).fetchone()

        if not p:
            raise RuntimeError("Aktif provider bulunamadı.")

        api_key=os.getenv(p["api_key_env"])
        if not api_key:
            raise RuntimeError(
                f"API anahtarı ortam değişkeninde yok: {p['api_key_env']}"
            )

        # Provider-specific request formats must be implemented in adapters.
        # Do not assume every provider exposes the same endpoint/schema.
        payload={
            "model":p["model"],
            "messages":[
                {"role":"system","content":system_prompt},
                {"role":"user","content":user_prompt}
            ]
        }

        response=requests.post(
            p["base_url"],
            headers={
                "Authorization":f"Bearer {api_key}",
                "Content-Type":"application/json"
            },
            json=payload,
            timeout=45
        )
        response.raise_for_status()
        return response.json()

    def demo(self):
        self.add_provider(
            "example-provider",
            "https://api.example.com/v1/chat/completions",
            "example-model",
            "BUZZARD_AI_API_KEY"
        )
        return (
            "Gateway demo provider kaydedildi. "
            "Gerçek çağrı için sağlayıcının resmi API sözleşmesine uygun adapter gerekir."
        )
