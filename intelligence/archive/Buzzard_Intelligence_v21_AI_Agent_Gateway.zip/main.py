import argparse
from buzzard_intelligence.gateway import AIGateway

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v21 AI Gateway")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("providers")
    s.add_parser("demo")

    a=s.add_parser("add-provider")
    a.add_argument("--name",required=True)
    a.add_argument("--base-url",required=True)
    a.add_argument("--model",required=True)
    a.add_argument("--api-key-env",default="BUZZARD_AI_API_KEY")

    args=p.parse_args()
    app=AIGateway()

    if args.cmd=="init":
        app.init(); print("v21 AI Agent Gateway hazır.")
    elif args.cmd=="providers":
        app.init(); print(app.providers())
    elif args.cmd=="demo":
        app.init(); print(app.demo())
    elif args.cmd=="add-provider":
        app.init()
        print(app.add_provider(args.name,args.base_url,args.model,args.api_key_env))
    else:
        p.print_help()

if __name__=="__main__":
    main()
