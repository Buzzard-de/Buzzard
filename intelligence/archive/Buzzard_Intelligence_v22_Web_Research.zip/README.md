# Buzzard Intelligence v22 — Web Research Agent

v22, Kurmay Heyeti için yasal ve açık web araştırmasını yapılandırır.

Amaç:
- araştırma görevlerini tanımlamak
- arama sorgularını kaydetmek
- kaynak URL/title/domain bilgisini saklamak
- alınan bulguları claim + evidence olarak kaydetmek
- kaynak güvenini ve gözlem zamanını tutmak
- aynı araştırma içindeki kaynakları karşılaştırmak
- robots.txt, erişim koşulları ve rate-limit gibi kurallara saygılı bir araştırma katmanı oluşturmak

Önemli sınırlar:
- yalnızca kamuya açık ve yasal olarak erişilebilir kaynaklar
- giriş duvarı/CAPTCHA/erişim kontrolü aşma yok
- gizli veya özel veri yok
- robots.txt ve sitenin kullanım/erişim kuralları dikkate alınır
- kaynak bulunamazsa bilgi uydurulmaz
- tek bir kaynaktan gelen iddia otomatik olarak doğrulanmış gerçek kabul edilmez

v22 bir araştırma orkestrasyon iskeletidir. Gerçek arama motoru/web fetch adapter'ları seçilen sağlayıcının güncel şartlarına göre ayrıca bağlanmalıdır.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Araştırma:
```bash
python main.py research --query "Germany automotive aftermarket trends" --purpose "Market Intelligence"
```

Kaynak:
```bash
python main.py source --research-id 1 --url "https://example.com" --title "Example source" --domain "example.com"
```

Bulgu:
```bash
python main.py finding --research-id 1 --source-id 1 --claim "Example claim" --confidence 0.85
```
