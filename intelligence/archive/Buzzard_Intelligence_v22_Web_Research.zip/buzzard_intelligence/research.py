import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

DB=Path("buzzard_web_research_v22.db")

class WebResearch:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS research_jobs(
                id INTEGER PRIMARY KEY,
                query TEXT NOT NULL,
                purpose TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'OPEN',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS sources(
                id INTEGER PRIMARY KEY,
                research_id INTEGER NOT NULL,
                url TEXT NOT NULL,
                title TEXT,
                domain TEXT,
                source_type TEXT,
                accessibility TEXT NOT NULL DEFAULT 'PUBLIC',
                observed_at TEXT NOT NULL,
                UNIQUE(research_id,url)
            );

            CREATE TABLE IF NOT EXISTS findings(
                id INTEGER PRIMARY KEY,
                research_id INTEGER NOT NULL,
                source_id INTEGER NOT NULL,
                claim TEXT NOT NULL,
                confidence REAL NOT NULL,
                note TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS research_events(
                id INTEGER PRIMARY KEY,
                research_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def create_research(self,query,purpose):
        now=self.now()
        with self.connect() as c:
            cur=c.execute("""
                INSERT INTO research_jobs(query,purpose,status,created_at,updated_at)
                VALUES(?,?,?,?,?)
            """,(query,purpose,"OPEN",now,now))
            rid=cur.lastrowid
            c.execute("""
                INSERT INTO research_events
                (research_id,event_type,details,created_at)
                VALUES(?,?,?,?)
            """,(rid,"CREATED",query,now))
        return f"Araştırma görevi #{rid} oluşturuldu."

    def add_source(self,research_id,url,title,domain):
        parsed=urlparse(url)
        if parsed.scheme not in ("http","https"):
            return "Yalnızca http/https kaynakları kabul edilir."

        domain=domain or parsed.netloc
        now=self.now()

        with self.connect() as c:
            job=c.execute(
                "SELECT id FROM research_jobs WHERE id=?",(research_id,)
            ).fetchone()
            if not job:
                return "Araştırma görevi bulunamadı."

            c.execute("""
                INSERT OR IGNORE INTO sources
                (research_id,url,title,domain,source_type,accessibility,observed_at)
                VALUES(?,?,?,?,?,?,?)
            """,(research_id,url,title,domain,"WEB","PUBLIC",now))

        return f"Kaynak kaydedildi: {domain}"

    def add_finding(self,research_id,source_id,claim,confidence,note):
        confidence=max(0,min(1,confidence))
        now=self.now()

        with self.connect() as c:
            src=c.execute("""
                SELECT id FROM sources
                WHERE id=? AND research_id=?
            """,(source_id,research_id)).fetchone()

            if not src:
                return "Kaynak bu araştırmaya ait değil veya bulunamadı."

            c.execute("""
                INSERT INTO findings
                (research_id,source_id,claim,confidence,note,created_at)
                VALUES(?,?,?,?,?,?)
            """,(research_id,source_id,claim,confidence,note,now))

            c.execute("""
                UPDATE research_jobs
                SET updated_at=? WHERE id=?
            """,(now,research_id))

        return f"Bulgu kaydedildi. Güven={confidence:.2f}"

    def demo(self):
        self.create_research(
            "Germany automotive aftermarket trends",
            "Market Intelligence"
        )
        self.add_source(
            1,
            "https://example.com/market-report",
            "Example public market report",
            "example.com"
        )
        self.add_finding(
            1,1,
            "Örnek açık kaynak bulgusu; gerçek veri olarak kullanılmamalıdır.",
            .50,
            "Demo kaydı."
        )

    def report(self):
        with self.connect() as c:
            jobs=c.execute("""
                SELECT id,query,purpose,status,created_at,updated_at
                FROM research_jobs
                ORDER BY updated_at DESC
            """).fetchall()

            sources=c.execute("""
                SELECT research_id,COUNT(*) n
                FROM sources
                GROUP BY research_id
            """).fetchall()

            findings=c.execute("""
                SELECT research_id,COUNT(*) n
                FROM findings
                GROUP BY research_id
            """).fetchall()

        sm={r["research_id"]:r["n"] for r in sources}
        fm={r["research_id"]:r["n"] for r in findings}

        out=["=== BUZZARD v22 WEB RESEARCH RAPORU ==="]
        for r in jobs:
            out.append(
                f"- #{r['id']} | {r['purpose']} | {r['query']} | "
                f"durum={r['status']} | kaynak={sm.get(r['id'],0)} | "
                f"bulgu={fm.get(r['id'],0)}"
            )

        out += [
            "",
            "ARAŞTIRMA KURALLARI:",
            "Yalnızca kamuya açık ve yasal erişilebilir kaynaklar.",
            "CAPTCHA, giriş duvarı veya erişim kontrolü aşılmaz.",
            "Bulgu ile kaynak arasındaki bağ korunur.",
            "Tek kaynaklı iddia otomatik olarak doğrulanmış gerçek sayılmaz.",
            "Kaynak yoksa bilgi uydurulmaz."
        ]
        return "\\n".join(out)
