import argparse
from buzzard_intelligence.research import WebResearch

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v22 Web Research")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    r=s.add_parser("research")
    r.add_argument("--query",required=True)
    r.add_argument("--purpose",default="General Intelligence")

    so=s.add_parser("source")
    so.add_argument("--research-id",type=int,required=True)
    so.add_argument("--url",required=True)
    so.add_argument("--title",default="")
    so.add_argument("--domain",default="")

    f=s.add_parser("finding")
    f.add_argument("--research-id",type=int,required=True)
    f.add_argument("--source-id",type=int,required=True)
    f.add_argument("--claim",required=True)
    f.add_argument("--confidence",type=float,default=.8)
    f.add_argument("--note",default="")

    args=p.parse_args()
    app=WebResearch()

    if args.cmd=="init":
        app.init(); print("v22 Web Research Agent hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo araştırma kayıtları oluşturuldu.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="research":
        app.init(); print(app.create_research(args.query,args.purpose))
    elif args.cmd=="source":
        app.init(); print(app.add_source(args.research_id,args.url,args.title,args.domain))
    elif args.cmd=="finding":
        app.init()
        print(app.add_finding(
            args.research_id,args.source_id,args.claim,args.confidence,args.note
        ))
    else:
        p.print_help()

if __name__=="__main__":
    main()
