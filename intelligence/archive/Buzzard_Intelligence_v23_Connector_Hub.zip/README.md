# Buzzard Intelligence v23 — Connector Hub

v23, Buzzard Intelligence için resmi API/feed bağlantılarını tek bir connector katmanında toplar.

Amaç:
- connector kayıtlarını merkezi yönetmek
- provider/platform türünü kaydetmek
- endpoint ve kimlik doğrulama yöntemini saklamak
- API/feed yeteneklerini tanımlamak
- bağlantı sağlık kontrolü için temel durum tutmak
- son başarılı/başarısız bağlantı zamanlarını izlemek
- ürün, fiyat, stok, kategori ve sipariş gibi veri akışlarını standartlaştırmak

Önemli:
- Sadece yetkili ve resmi API/feed bağlantıları kullanılmalıdır.
- API anahtarları kod içine yazılmaz; environment variable adı tutulur.
- Kimlik doğrulama, rate limit, pagination, webhook ve veri sözleşmeleri provider'a göre değişebilir.
- Her provider için ayrı adapter uygulanmalıdır; tek bir API formatı varsayılmaz.
- Bu v23 çekirdeği gerçek platform kimlik bilgilerini içermez.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Connector ekleme:
```bash
python main.py add --name "Example Supplier API" --kind supplier --base-url "https://api.example.com" --key-env "BUZZARD_EXAMPLE_KEY"
```

Capability:
```bash
python main.py capability --connector "Example Supplier API" --name products --direction inbound
```

Sağlık durumu:
```bash
python main.py health --connector "Example Supplier API" --status healthy
```
