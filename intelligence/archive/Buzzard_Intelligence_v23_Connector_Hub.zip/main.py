import argparse
from buzzard_intelligence.connectors import ConnectorHub

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v23 Connector Hub")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    a=s.add_parser("add")
    a.add_argument("--name",required=True)
    a.add_argument("--kind",required=True)
    a.add_argument("--base-url",required=True)
    a.add_argument("--key-env",default="")

    c=s.add_parser("capability")
    c.add_argument("--connector",required=True)
    c.add_argument("--name",required=True)
    c.add_argument("--direction",default="inbound")

    h=s.add_parser("health")
    h.add_argument("--connector",required=True)
    h.add_argument("--status",required=True)
    h.add_argument("--note",default="")

    args=p.parse_args()
    app=ConnectorHub()

    if args.cmd=="init":
        app.init(); print("v23 Connector Hub hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo connector kayıtları hazır.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="add":
        app.init(); print(app.add_connector(args.name,args.kind,args.base_url,args.key_env))
    elif args.cmd=="capability":
        app.init(); print(app.add_capability(args.connector,args.name,args.direction))
    elif args.cmd=="health":
        app.init(); print(app.set_health(args.connector,args.status,args.note))
    else:
        p.print_help()

if __name__=="__main__":
    main()
