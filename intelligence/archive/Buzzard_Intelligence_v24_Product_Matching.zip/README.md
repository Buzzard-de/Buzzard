# Buzzard Intelligence v24 — Product Matching Engine

v24, farklı kaynaklarda aynı ürünü farklı isimlerle/kimliklerle listelenmiş olsa bile eşleştirmek için çekirdek bir ürün kimliği katmanıdır.

Eşleştirme sinyalleri:
- EAN / GTIN
- OEM / üretici parça numarası
- MPN
- marka
- normalize edilmiş ürün adı
- kategori
- model / varyant
- kaynak URL

Amaç:
- aynı ürünün farklı sitelerdeki kayıtlarını tek kanonik ürüne bağlamak
- yanlış eşleşme riskini azaltmak
- belirsiz eşleşmeleri "REVIEW" durumunda bırakmak
- eşleşme nedenlerini/açıklanabilir sinyalleri saklamak

ÖNEMLİ:
- Sadece ürün adı benzer diye otomatik olarak aynı ürün kabul edilmez.
- EAN/GTIN veya üretici parça numarası güçlü sinyaldir, ancak yine de kaynak bağlamı korunur.
- Çelişkili kimlik bilgileri varsa otomatik eşleşme yerine inceleme gerekir.
- Ürün eşleştirme satış, marka veya orijinallik doğrulaması değildir.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Kanonik ürün:
```bash
python main.py canonical --name "5W-30 Motor Yağı" --brand "Example" --category "Otomotiv"
```

Kaynak ürün:
```bash
python main.py listing --canonical-id 1 --source "Example Store" --name "Example 5W30" --ean "1234567890123" --mpn "ABC-5W30" --url "https://example.com/product"
```

Eşleşme önerisi:
```bash
python main.py match --listing-id 1 --candidate-id 2
```
