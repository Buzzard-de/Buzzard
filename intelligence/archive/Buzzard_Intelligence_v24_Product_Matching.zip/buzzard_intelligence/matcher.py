import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_product_matching_v24.db")

class ProductMatcher:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS canonical_products(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                brand TEXT,
                category TEXT,
                variant TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS listings(
                id INTEGER PRIMARY KEY,
                canonical_id INTEGER,
                source TEXT NOT NULL,
                name TEXT NOT NULL,
                brand TEXT,
                category TEXT,
                variant TEXT,
                ean TEXT,
                gtin TEXT,
                mpn TEXT,
                oem TEXT,
                url TEXT,
                match_status TEXT NOT NULL DEFAULT 'UNMATCHED',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS match_candidates(
                id INTEGER PRIMARY KEY,
                listing_id INTEGER NOT NULL,
                candidate_id INTEGER NOT NULL,
                score REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'REVIEW',
                reasons TEXT,
                created_at TEXT NOT NULL,
                UNIQUE(listing_id,candidate_id)
            );

            CREATE TABLE IF NOT EXISTS match_events(
                id INTEGER PRIMARY KEY,
                listing_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def norm(self,s):
        s=(s or "").lower()
        return re.sub(r"[^a-z0-9äöüßçğıİşñ]+","",s)

    def add_canonical(self,name,brand,category,variant):
        now=self.now()
        with self.connect() as c:
            cur=c.execute("""
                INSERT INTO canonical_products
                (name,brand,category,variant,created_at)
                VALUES(?,?,?,?,?)
            """,(name,brand,category,variant,now))
        return f"Kanonik ürün #{cur.lastrowid} oluşturuldu."

    def add_listing(self,canonical_id,source,name,brand,category,
                    variant,ean,gtin,mpn,oem,url):
        now=self.now()
        with self.connect() as c:
            if canonical_id:
                row=c.execute(
                    "SELECT id FROM canonical_products WHERE id=?",
                    (canonical_id,)
                ).fetchone()
                if not row:
                    return "Kanonik ürün bulunamadı."
                status="MATCHED"
            else:
                status="UNMATCHED"

            cur=c.execute("""
                INSERT INTO listings
                (canonical_id,source,name,brand,category,variant,ean,gtin,
                 mpn,oem,url,match_status,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,(canonical_id,source,name,brand,category,variant,ean,gtin,
                 mpn,oem,url,status,now))
        return f"Kaynak ürün #{cur.lastrowid} kaydedildi | durum={status}"

    def score(self,a,b):
        reasons=[]
        score=0

        for field,weight,label in [
            ("ean",60,"EAN eşleşmesi"),
            ("gtin",60,"GTIN eşleşmesi"),
            ("mpn",50,"MPN eşleşmesi"),
            ("oem",50,"OEM parça numarası eşleşmesi"),
            ("brand",15,"Marka eşleşmesi"),
            ("category",10,"Kategori eşleşmesi"),
            ("variant",10,"Varyant eşleşmesi"),
            ("name",15,"Ürün adı benzerliği")
        ]:
            av=a[field] or ""
            bv=b[field] or ""
            if field=="name":
                na,nb=self.norm(av),self.norm(bv)
                if na and nb and (na==nb or na in nb or nb in na):
                    score+=weight
                    reasons.append(label)
            elif av and bv and self.norm(av)==self.norm(bv):
                score+=weight
                reasons.append(label)

        # Ürün kimlik numaraları çelişiyorsa güçlü negatif sinyal.
        for field in ("ean","gtin","mpn","oem"):
            av=a[field] or ""
            bv=b[field] or ""
            if av and bv and self.norm(av)!=self.norm(bv):
                score-=35
                reasons.append(f"{field.upper()} çelişkisi")

        score=max(0,min(100,score))
        return score,reasons

    def match(self,listing_id,candidate_id):
        with self.connect() as c:
            a=c.execute(
                "SELECT * FROM listings WHERE id=?",(listing_id,)
            ).fetchone()
            b=c.execute(
                "SELECT * FROM listings WHERE id=?",(candidate_id,)
            ).fetchone()

            if not a or not b:
                return "Kaynak ürün bulunamadı."

            score,reasons=self.score(a,b)

            if score>=85:
                status="HIGH_CONFIDENCE"
            elif score>=60:
                status="REVIEW"
            else:
                status="LOW_CONFIDENCE"

            c.execute("""
                INSERT OR REPLACE INTO match_candidates
                (listing_id,candidate_id,score,status,reasons,created_at)
                VALUES(?,?,?,?,?,?)
            """,(listing_id,candidate_id,score,status,"; ".join(reasons),self.now()))

        return (
            f"Eşleşme analizi: {score}/100 | {status}\\n"
            f"Nedenler: {', '.join(reasons) if reasons else 'yeterli ortak sinyal yok'}"
        )

    def demo(self):
        self.add_canonical(
            "5W-30 Motor Yağı","Example","Otomotiv","5L"
        )
        self.add_listing(
            1,"Store A","Example 5W-30 Engine Oil 5L",
            "Example","Otomotiv","5L","1234567890123","","ABC-5W30",
            "ABC-5W30","https://example.com/a"
        )
        self.add_listing(
            None,"Store B","Motoröl 5W-30 5L",
            "Example","Otomotiv","5L","1234567890123","","ABC-5W30",
            "ABC-5W30","https://example.com/b"
        )
        self.match(1,2)

    def report(self):
        with self.connect() as c:
            cp=c.execute("""
                SELECT id,name,brand,category,variant
                FROM canonical_products ORDER BY id
            """).fetchall()

            ls=c.execute("""
                SELECT id,canonical_id,source,name,brand,ean,gtin,mpn,oem,
                       match_status
                FROM listings ORDER BY id
            """).fetchall()

            mc=c.execute("""
                SELECT listing_id,candidate_id,score,status,reasons
                FROM match_candidates ORDER BY score DESC
            """).fetchall()

        out=["=== BUZZARD v24 PRODUCT MATCHING RAPORU ===",
             "","KANONİK ÜRÜNLER"]
        for r in cp:
            out.append(
                f"- #{r['id']} {r['name']} | marka={r['brand'] or '-'} | "
                f"kategori={r['category'] or '-'} | varyant={r['variant'] or '-'}"
            )

        out += ["","KAYNAK LİSTELERİ"]
        for r in ls:
            out.append(
                f"- #{r['id']} {r['source']} | {r['name']} | "
                f"durum={r['match_status']} | EAN={r['ean'] or '-'} | "
                f"MPN={r['mpn'] or '-'} | OEM={r['oem'] or '-'}"
            )

        out += ["","EŞLEŞME ADAYLARI"]
        for r in mc:
            out.append(
                f"- {r['listing_id']} <-> {r['candidate_id']} | "
                f"skor={r['score']:.0f} | {r['status']} | {r['reasons'] or '-'}"
            )

        out += [
            "",
            "KURAL:",
            "Benzer isim tek başına ürün eşleşmesi değildir.",
            "Kimlik numarası çelişkileri güçlü negatif sinyaldir.",
            "Belirsiz eşleşmeler insan/uzman incelemesine bırakılır.",
            "Eşleştirme sonucu orijinallik veya hukuki uygunluk kanıtı değildir."
        ]
        return "\\n".join(out)
