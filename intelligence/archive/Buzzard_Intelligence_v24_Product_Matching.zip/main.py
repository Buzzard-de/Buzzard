import argparse
from buzzard_intelligence.matcher import ProductMatcher

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v24 Product Matching")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    c=s.add_parser("canonical")
    c.add_argument("--name",required=True)
    c.add_argument("--brand",default="")
    c.add_argument("--category",default="")
    c.add_argument("--variant",default="")

    l=s.add_parser("listing")
    l.add_argument("--canonical-id",type=int)
    l.add_argument("--source",required=True)
    l.add_argument("--name",required=True)
    l.add_argument("--brand",default="")
    l.add_argument("--category",default="")
    l.add_argument("--variant",default="")
    l.add_argument("--ean",default="")
    l.add_argument("--gtin",default="")
    l.add_argument("--mpn",default="")
    l.add_argument("--oem",default="")
    l.add_argument("--url",default="")

    m=s.add_parser("match")
    m.add_argument("--listing-id",type=int,required=True)
    m.add_argument("--candidate-id",type=int,required=True)

    args=p.parse_args()
    app=ProductMatcher()

    if args.cmd=="init":
        app.init(); print("v24 Product Matching Engine hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo ürün eşleştirme kayıtları oluşturuldu.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="canonical":
        app.init()
        print(app.add_canonical(args.name,args.brand,args.category,args.variant))
    elif args.cmd=="listing":
        app.init()
        print(app.add_listing(
            args.canonical_id,args.source,args.name,args.brand,args.category,
            args.variant,args.ean,args.gtin,args.mpn,args.oem,args.url
        ))
    elif args.cmd=="match":
        app.init()
        print(app.match(args.listing_id,args.candidate_id))
    else:
        p.print_help()

if __name__=="__main__":
    main()
