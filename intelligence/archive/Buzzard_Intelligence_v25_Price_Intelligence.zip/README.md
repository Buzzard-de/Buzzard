# Buzzard Intelligence v25 — Price Intelligence Engine

v25, açık kaynaklardan elde edilen ürün fiyat gözlemlerini zaman içinde takip eden fiyat istihbaratı katmanıdır.

Amaç:
- ürün bazında fiyat gözlemleri kaydetmek
- satıcı/kaynak bazında fiyatları karşılaştırmak
- fiyat değişimini tespit etmek
- ilk/son fiyatı ve değişim oranını hesaplamak
- minimum/maksimum/ortalama/medyan fiyatı görmek
- fiyat düşüş/yükseliş sinyali üretmek
- kaynak ve gözlem zamanını korumak

Önemli:
- Fiyat gözlemi satış garantisi değildir.
- KDV, kargo, kupon, üyelik indirimi, varyant ve stok koşulları ayrıca tutulmalıdır.
- Fiyat karşılaştırması yalnızca aynı ürün kimliği/uygun eşleşme güveni bulunduğunda anlamlıdır.
- Yetkisiz erişim veya erişim kısıtlarını aşma yoktur.
- Açık kaynak fiyatları otomatik olarak "güncel" kabul edilmez; gözlem zamanı saklanır.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Fiyat kaydı:
```bash
python main.py price --product-id "EAN-123" --seller "Example Store" --price 49.90 --currency EUR --source "https://example.com/product"
```

Değişim raporu:
```bash
python main.py changes --product-id "EAN-123"
```
