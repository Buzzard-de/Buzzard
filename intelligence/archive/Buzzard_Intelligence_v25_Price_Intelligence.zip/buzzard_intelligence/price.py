import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from statistics import median

DB=Path("buzzard_price_v25.db")

class PriceIntel:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS price_observations(
                id INTEGER PRIMARY KEY,
                product_id TEXT NOT NULL,
                seller TEXT NOT NULL,
                price REAL NOT NULL,
                currency TEXT NOT NULL,
                shipping REAL NOT NULL DEFAULT 0,
                vat_included TEXT,
                source TEXT NOT NULL,
                observed_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS price_signals(
                id INTEGER PRIMARY KEY,
                product_id TEXT NOT NULL,
                seller TEXT,
                signal_type TEXT NOT NULL,
                old_price REAL,
                new_price REAL,
                change_pct REAL,
                details TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def add_price(self,product_id,seller,price,currency,source,
                  shipping,vat_included):
        if price < 0 or shipping < 0:
            return "Fiyat/kargo negatif olamaz."

        now=self.now()

        with self.connect() as c:
            prev=c.execute("""
                SELECT price FROM price_observations
                WHERE product_id=? AND seller=?
                ORDER BY id DESC LIMIT 1
            """,(product_id,seller)).fetchone()

            c.execute("""
                INSERT INTO price_observations
                (product_id,seller,price,currency,shipping,vat_included,source,observed_at)
                VALUES(?,?,?,?,?,?,?,?)
            """,(product_id,seller,price,currency,shipping,vat_included,source,now))

            if prev and prev["price"] != 0:
                old=prev["price"]
                pct=(price-old)/old*100

                if abs(pct)>=1:
                    signal="PRICE_DOWN" if pct<0 else "PRICE_UP"
                    c.execute("""
                        INSERT INTO price_signals
                        (product_id,seller,signal_type,old_price,new_price,
                         change_pct,details,created_at)
                        VALUES(?,?,?,?,?,?,?,?)
                    """,(
                        product_id,seller,signal,old,price,pct,
                        f"Fiyat değişimi {pct:.2f}%",now
                    ))

        return f"Fiyat kaydedildi: {product_id} / {seller} = {price:.2f} {currency}"

    def changes(self,product_id):
        with self.connect() as c:
            rows=c.execute("""
                SELECT seller,old_price,new_price,change_pct,signal_type,created_at
                FROM price_signals
                WHERE product_id=?
                ORDER BY created_at DESC
            """,(product_id,)).fetchall()

        if not rows:
            return "Bu ürün için fiyat değişimi sinyali yok."

        out=[f"=== FİYAT DEĞİŞİMLERİ: {product_id} ==="]
        for r in rows:
            out.append(
                f"- {r['seller']} | {r['signal_type']} | "
                f"{r['old_price']:.2f} -> {r['new_price']:.2f} | "
                f"{r['change_pct']:.2f}% | {r['created_at']}"
            )
        return "\\n".join(out)

    def demo(self):
        self.add_price(
            "EAN-123","Store A",54.90,"EUR",
            "https://example.com/a",4.99,"yes"
        )
        self.add_price(
            "EAN-123","Store A",49.90,"EUR",
            "https://example.com/a",4.99,"yes"
        )
        self.add_price(
            "EAN-123","Store B",57.90,"EUR",
            "https://example.com/b",0,"yes"
        )
        self.add_price(
            "EAN-123","Store B",61.90,"EUR",
            "https://example.com/b",0,"yes"
        )

    def report(self):
        with self.connect() as c:
            products=c.execute("""
                SELECT product_id,currency,
                       MIN(price) min_price,
                       MAX(price) max_price,
                       AVG(price) avg_price,
                       COUNT(*) observations
                FROM price_observations
                GROUP BY product_id,currency
                ORDER BY product_id
            """).fetchall()

            signals=c.execute("""
                SELECT product_id,seller,signal_type,old_price,new_price,
                       change_pct,created_at
                FROM price_signals
                ORDER BY created_at DESC
                LIMIT 100
            """).fetchall()

        out=["=== BUZZARD v25 PRICE INTELLIGENCE RAPORU ===",
             "","ÜRÜN FİYAT ÖZETİ"]

        for r in products:
            out.append(
                f"- {r['product_id']} | {r['observations']} gözlem | "
                f"min={r['min_price']:.2f} {r['currency']} | "
                f"max={r['max_price']:.2f} {r['currency']} | "
                f"ortalama={r['avg_price']:.2f} {r['currency']}"
            )

        out += ["","SON FİYAT SİNYALLERİ"]
        for r in signals:
            out.append(
                f"- {r['product_id']} | {r['seller']} | {r['signal_type']} | "
                f"{r['old_price']:.2f}->{r['new_price']:.2f} | "
                f"{r['change_pct']:.2f}%"
            )

        out += [
            "",
            "KURAL:",
            "Fiyat gözleminin zamanı ve kaynağı her zaman saklanır.",
            "Kargo, KDV, kupon ve varyant farkları fiyat karşılaştırmasında dikkate alınmalıdır.",
            "Fiyat istihbaratı satış veya kârlılık garantisi değildir."
        ]
        return "\\n".join(out)
