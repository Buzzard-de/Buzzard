import argparse
from buzzard_intelligence.price import PriceIntel

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v25 Price Intelligence")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    a=s.add_parser("price")
    a.add_argument("--product-id",required=True)
    a.add_argument("--seller",required=True)
    a.add_argument("--price",type=float,required=True)
    a.add_argument("--currency",default="EUR")
    a.add_argument("--source",required=True)
    a.add_argument("--shipping",type=float,default=0)
    a.add_argument("--vat-included",default="unknown")

    c=s.add_parser("changes")
    c.add_argument("--product-id",required=True)

    args=p.parse_args()
    app=PriceIntel()

    if args.cmd=="init":
        app.init(); print("v25 Price Intelligence hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo fiyat gözlemleri oluşturuldu.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="price":
        app.init()
        print(app.add_price(
            args.product_id,args.seller,args.price,args.currency,
            args.source,args.shipping,args.vat_included
        ))
    elif args.cmd=="changes":
        app.init(); print(app.changes(args.product_id))
    else:
        p.print_help()

if __name__=="__main__":
    main()
