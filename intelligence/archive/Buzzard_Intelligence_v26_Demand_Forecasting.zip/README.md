# Buzzard Intelligence v26 — Demand Forecasting Engine

v26, ürün/kategori için zaman serisi talep sinyallerinden açıklanabilir bir tahmin çekirdeği oluşturur.

Amaç:
- günlük/haftalık gözlemleri saklamak
- talep sinyalindeki trendi ölçmek
- hareketli ortalama hesaplamak
- son dönem ile önceki dönemi karşılaştırmak
- artış/düşüş yönü üretmek
- basit ileri dönem tahmini oluşturmak
- veri yetersizliğini açıkça belirtmek
- tahmin güvenini veri miktarına göre sınırlamak

ÖNEMLİ:
Bu model satış adedini kendiliğinden bilemez. Girilen talep gözlemlerini analiz eder.
Tahmin = karar desteğidir; satış garantisi değildir.
Mevsimsellik, kampanya, stok yokluğu, fiyat değişimi ve dış şoklar ayrıca modele eklenmelidir.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Gözlem:
```bash
python main.py observation --product-id "EAN-123" --value 120 --period "2026-08-01"
```

Tahmin:
```bash
python main.py forecast --product-id "EAN-123"
```
