import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean

DB=Path("buzzard_demand_v26.db")

class DemandForecast:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS observations(
                id INTEGER PRIMARY KEY,
                product_id TEXT NOT NULL,
                period TEXT NOT NULL,
                value REAL NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(product_id,period)
            );

            CREATE TABLE IF NOT EXISTS forecasts(
                id INTEGER PRIMARY KEY,
                product_id TEXT NOT NULL,
                window_size INTEGER NOT NULL,
                baseline REAL,
                recent_average REAL,
                trend_pct REAL,
                forecast_value REAL,
                confidence REAL,
                direction TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def add_observation(self,product_id,value,period):
        if value < 0:
            return "Talep değeri negatif olamaz."
        now=self.now()
        with self.connect() as c:
            c.execute("""
                INSERT OR REPLACE INTO observations
                (product_id,period,value,created_at)
                VALUES(?,?,?,?)
            """,(product_id,period,value,now))
        return f"Talep gözlemi kaydedildi: {product_id} / {period} = {value}"

    def forecast(self,product_id,window=7):
        window=max(2,min(90,window))
        with self.connect() as c:
            rows=c.execute("""
                SELECT period,value
                FROM observations
                WHERE product_id=?
                ORDER BY period
            """,(product_id,)).fetchall()

        values=[float(r["value"]) for r in rows]

        if len(values)<3:
            return (
                f"{product_id}: VERİ YETERSİZ. "
                f"Tahmin için en az 3 gözlem gerekli."
            )

        baseline=mean(values[:-min(window,len(values))]) \
            if len(values)>window else mean(values[:-1])
        recent=mean(values[-min(window,len(values)):])

        if baseline==0:
            trend=None
            forecast_value=recent
        else:
            trend=(recent-baseline)/baseline*100
            # Basit trend extrapolation; aşırı büyümeyi sınırlıyoruz.
            capped=max(-50,min(100,trend))
            forecast_value=recent*(1+capped/100)

        if baseline and abs(trend if trend is not None else 0)<3:
            direction="STABLE"
        elif trend is not None and trend>0:
            direction="RISING"
        elif trend is not None:
            direction="FALLING"
        else:
            direction="STABLE"

        # Basit veri-temelli güven; dış faktörleri kapsamaz.
        confidence=min(0.95,0.35+len(values)*0.03)

        now=self.now()
        with self.connect() as c:
            c.execute("""
                INSERT INTO forecasts
                (product_id,window_size,baseline,recent_average,trend_pct,
                 forecast_value,confidence,direction,created_at)
                VALUES(?,?,?,?,?,?,?,?,?)
            """,(product_id,window,baseline,recent,trend,forecast_value,
                 confidence,direction,now))

        trend_text=f"{trend:.2f}%" if trend is not None else "N/A"
        return (
            f"=== TALEP TAHMİNİ: {product_id} ===\\n"
            f"gözlem sayısı={len(values)}\\n"
            f"son dönem ortalaması={recent:.2f}\\n"
            f"trend={trend_text}\\n"
            f"yön={direction}\\n"
            f"ileri tahmin={forecast_value:.2f}\\n"
            f"model güveni={confidence:.2f}\\n"
            f"NOT: Tahmin yalnızca girilen talep sinyallerine dayanır."
        )

    def demo(self):
        vals=[82,88,91,96,103,108,115,121,126,134,140,147,153,160]
        for i,v in enumerate(vals,1):
            self.add_observation("DEMO-EAN-001",v,f"2026-07-{i:02d}")
        self.forecast("DEMO-EAN-001",7)

    def report(self):
        with self.connect() as c:
            products=c.execute("""
                SELECT product_id,COUNT(*) n,MIN(period) first_period,
                       MAX(period) last_period
                FROM observations
                GROUP BY product_id
                ORDER BY product_id
            """).fetchall()

            forecasts=c.execute("""
                SELECT product_id,forecast_value,trend_pct,confidence,
                       direction,created_at
                FROM forecasts
                ORDER BY created_at DESC
                LIMIT 100
            """).fetchall()

        out=["=== BUZZARD v26 DEMAND FORECASTING RAPORU ===",
             "","VERİ KAPSAMI"]
        for r in products:
            out.append(
                f"- {r['product_id']} | gözlem={r['n']} | "
                f"{r['first_period']} -> {r['last_period']}"
            )

        out += ["","SON TAHMİNLER"]
        for r in forecasts:
            trend=f"{r['trend_pct']:.2f}%" if r['trend_pct'] is not None else "N/A"
            out.append(
                f"- {r['product_id']} | yön={r['direction']} | "
                f"tahmin={r['forecast_value']:.2f} | trend={trend} | "
                f"güven={r['confidence']:.2f}"
            )

        out += [
            "",
            "KURAL:",
            "Tahminler karar desteğidir, satış garantisi değildir.",
            "Stok yokluğu, fiyat, kampanya ve mevsimsellik gibi faktörler ayrıca modele eklenmelidir.",
            "Veri azsa sistem yüksek güven iddiasında bulunmaz."
        ]
        return "\\n".join(out)
