import argparse
from buzzard_intelligence.forecast import DemandForecast

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v26 Demand Forecasting")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    o=s.add_parser("observation")
    o.add_argument("--product-id",required=True)
    o.add_argument("--value",type=float,required=True)
    o.add_argument("--period",required=True)

    f=s.add_parser("forecast")
    f.add_argument("--product-id",required=True)
    f.add_argument("--window",type=int,default=7)

    args=p.parse_args()
    app=DemandForecast()

    if args.cmd=="init":
        app.init(); print("v26 Demand Forecasting Engine hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo talep verileri oluşturuldu.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="observation":
        app.init(); print(app.add_observation(args.product_id,args.value,args.period))
    elif args.cmd=="forecast":
        app.init(); print(app.forecast(args.product_id,args.window))
    else:
        p.print_help()

if __name__=="__main__":
    main()
