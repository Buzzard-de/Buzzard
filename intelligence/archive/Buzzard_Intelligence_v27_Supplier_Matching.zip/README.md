# Buzzard Intelligence v27 — Supplier Matching Engine

v27, belirli bir ürün/kategori için kayıtlı tedarikçileri karşılaştırır ve araştırma önceliği oluşturur.

Değerlendirilen sinyaller:
- ürün/kategori uyumu
- tedarikçi güven skoru
- entegrasyon skoru
- dropshipping
- white-label / blind shipping
- API/XML/JSON/CSV
- TecDoc
- lojistik uygunluğu
- belge/evidence kapsamı
- risk durumu
- veri yeterliliği

Amaç:
"Bu ürün için hangi tedarikçi önce incelenmeli?" sorusuna açıklanabilir bir sıralama vermek.

ÖNEMLİ:
- Sistem tedarikçiyi otomatik olarak onaylamaz.
- Eksik bilgi yüksek güven olarak değerlendirilmez.
- Riskli veya doğrulanmamış tedarikçiler insan incelemesine kalır.
- Gerçek fiyat, stok, teslimat ve entegrasyon koşulları güncel kaynaklarla doğrulanmalıdır.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Tedarikçi:
```bash
python main.py supplier --name "Example Supplier" --category "Otomotiv" --trust 85 --integration 90 --logistics 80 --risk 15
```

Ürün için eşleştirme:
```bash
python main.py match --product "5W-30 Motor Yağı" --category "Otomotiv"
```
