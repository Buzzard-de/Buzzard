import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_supplier_match_v27.db")

class SupplierMatcher:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS suppliers(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                category TEXT NOT NULL,
                trust REAL,
                integration REAL,
                logistics REAL,
                risk REAL,
                dropshipping REAL,
                whitelabel REAL,
                evidence REAL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS matches(
                id INTEGER PRIMARY KEY,
                product TEXT NOT NULL,
                category TEXT NOT NULL,
                supplier_id INTEGER NOT NULL,
                score REAL,
                data_completeness REAL NOT NULL,
                status TEXT NOT NULL,
                reasons TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def completeness(self,values):
        return round(sum(v is not None for v in values)/len(values)*100,1)

    def add_supplier(self,name,category,trust,integration,logistics,risk,
                     dropshipping,whitelabel,evidence):
        vals=[trust,integration,logistics,risk,dropshipping,whitelabel,evidence]
        for v in vals:
            if v is not None and not 0<=v<=100:
                return "Puanlar 0-100 arasında olmalı."

        with self.connect() as c:
            c.execute("""
                INSERT OR REPLACE INTO suppliers
                (name,category,trust,integration,logistics,risk,dropshipping,
                 whitelabel,evidence,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
            """,(
                name,category,trust,integration,logistics,risk,
                dropshipping,whitelabel,evidence,self.now()
            ))
        return f"Tedarikçi kaydedildi: {name}"

    def score(self,row,category):
        if row["category"].strip().lower()!=category.strip().lower():
            return None,["kategori uyumsuzluğu"]

        vals=[
            row["trust"],row["integration"],row["logistics"],row["risk"],
            row["dropshipping"],row["whitelabel"],row["evidence"]
        ]
        if any(v is None for v in vals):
            return None,["veri eksik"]

        score=(
            row["trust"]*0.25 +
            row["integration"]*0.20 +
            row["logistics"]*0.15 +
            (100-row["risk"])*0.15 +
            row["dropshipping"]*0.10 +
            row["whitelabel"]*0.05 +
            row["evidence"]*0.10
        )

        reasons=[
            f"güven={row['trust']:.0f}",
            f"entegrasyon={row['integration']:.0f}",
            f"lojistik={row['logistics']:.0f}",
            f"risk={row['risk']:.0f}",
            f"dropshipping={row['dropshipping']:.0f}",
            f"white-label={row['whitelabel']:.0f}",
            f"kanıt={row['evidence']:.0f}"
        ]
        return round(score,1),reasons

    def match(self,product,category):
        with self.connect() as c:
            suppliers=c.execute("""
                SELECT * FROM suppliers
                WHERE lower(category)=lower(?)
                ORDER BY name
            """,(category,)).fetchall()

            c.execute("DELETE FROM matches WHERE product=? AND category=?",
                      (product,category))

            results=[]
            for s in suppliers:
                score,reasons=self.score(s,category)
                completeness=self.completeness([
                    s["trust"],s["integration"],s["logistics"],s["risk"],
                    s["dropshipping"],s["whitelabel"],s["evidence"]
                ])

                if score is None:
                    status="REVIEW"
                elif score>=80:
                    status="TOP_PRIORITY"
                elif score>=65:
                    status="GOOD_CANDIDATE"
                else:
                    status="LOW_PRIORITY"

                c.execute("""
                    INSERT INTO matches
                    (product,category,supplier_id,score,data_completeness,
                     status,reasons,created_at)
                    VALUES(?,?,?,?,?,?,?,?)
                """,(product,category,s["id"],score,completeness,status,
                     "; ".join(reasons),self.now()))

                results.append((s["name"],score,status,completeness,reasons))

        results.sort(key=lambda x:(x[1] is not None,x[1] or -1),reverse=True)

        if not results:
            return f"{category} için kayıtlı tedarikçi bulunamadı."

        out=[f"=== TEDARİKÇİ EŞLEŞTİRME: {product} ==="]
        for name,score,status,comp,reasons in results:
            score_text=f"{score:.1f}" if score is not None else "VERİ YETERSİZ"
            out.append(
                f"- {name} | skor={score_text} | {status} | veri=%{comp:.1f}"
            )
            out.append(f"  → {', '.join(reasons)}")
        return "\\n".join(out)

    def demo(self):
        self.add_supplier(
            "Supplier A","Otomotiv",92,94,88,10,95,90,92
        )
        self.add_supplier(
            "Supplier B","Otomotiv",82,76,80,20,90,70,84
        )
        self.add_supplier(
            "Supplier C","Otomotiv",70,65,68,35,80,50,65
        )
        self.match("5W-30 Motor Yağı","Otomotiv")

    def report(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT m.product,m.category,s.name,m.score,m.status,
                       m.data_completeness,m.reasons
                FROM matches m
                JOIN suppliers s ON s.id=m.supplier_id
                ORDER BY m.product,m.score DESC
            """).fetchall()

        out=["=== BUZZARD v27 SUPPLIER MATCHING RAPORU ==="]
        if not rows:
            out.append("- Henüz eşleştirme yok.")
        for r in rows:
            score=f"{r['score']:.1f}" if r['score'] is not None else "VERİ YETERSİZ"
            out.append(
                f"- {r['product']} | {r['category']} | {r['name']} | "
                f"skor={score} | {r['status']} | veri=%{r['data_completeness']:.1f}"
            )

        out += [
            "",
            "KURAL:",
            "Bu skor seçim önceliğidir; tedarikçi onayı değildir.",
            "Eksik veri bulunan tedarikçi yüksek güvenle sıralanmaz.",
            "Risk ve orijinallik kontrolleri ayrıca tamamlanmalıdır."
        ]
        return "\\n".join(out)
