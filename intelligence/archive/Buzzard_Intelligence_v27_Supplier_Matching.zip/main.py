import argparse
from buzzard_intelligence.supplier_match import SupplierMatcher

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v27 Supplier Matching")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    a=s.add_parser("supplier")
    a.add_argument("--name",required=True)
    a.add_argument("--category",required=True)
    a.add_argument("--trust",type=float,default=None)
    a.add_argument("--integration",type=float,default=None)
    a.add_argument("--logistics",type=float,default=None)
    a.add_argument("--risk",type=float,default=None)
    a.add_argument("--dropshipping",type=float,default=None)
    a.add_argument("--whitelabel",type=float,default=None)
    a.add_argument("--evidence",type=float,default=None)

    m=s.add_parser("match")
    m.add_argument("--product",required=True)
    m.add_argument("--category",required=True)

    args=p.parse_args()
    app=SupplierMatcher()

    if args.cmd=="init":
        app.init(); print("v27 Supplier Matching Engine hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo tedarikçi eşleştirmeleri hazır.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="supplier":
        app.init()
        print(app.add_supplier(
            args.name,args.category,args.trust,args.integration,
            args.logistics,args.risk,args.dropshipping,args.whitelabel,
            args.evidence
        ))
    elif args.cmd=="match":
        app.init(); print(app.match(args.product,args.category))
    else:
        p.print_help()

if __name__=="__main__":
    main()
