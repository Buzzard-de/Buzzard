# Buzzard Intelligence v28 — Automated Product Selection Engine

v28, istihbarat verilerini bir araya getirerek ürün adaylarına açıklanabilir bir ticari öncelik sinyali üretir.

Bir ürün için kullanılabilen sinyaller:
- kârlılık
- talep trendi
- fiyat fırsatı
- pazar fırsatı
- tedarikçi uygunluğu
- risk
- orijinallik/güven
- veri yeterliliği

Çıktılar:
- PRIORITY
- REVIEW
- HOLD
- REJECT

ÖNEMLİ:
- v28 otomatik satın alma veya satış kararı vermez.
- REJECT burada "araştırma kriterlerine göre uygun değil" anlamındadır; hukuki suçlama değildir.
- Eksik kritik veri bulunan ürünler REVIEW/HOLD'a düşer.
- Ürün güvenliği, orijinallik, hukuki uygunluk ve tedarikçi doğrulaması ayrı kontroller olarak korunur.
- Minimum Buzzard net kâr eşiği €0,50 olarak varsayılan kuraldır.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
```

Aday ürün:
```bash
python main.py product --name "5W-30 Motor Yağı" --category "Otomotiv" --profit 2.40 --demand 85 --price 80 --market 82 --supplier 90 --risk 15 --trust 92
```
