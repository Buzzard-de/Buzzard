import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_product_selection_v28.db")
MIN_NET_PROFIT=0.50

class ProductSelector:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.execute("""
            CREATE TABLE IF NOT EXISTS product_candidates(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                net_profit REAL,
                demand REAL,
                price_opportunity REAL,
                market_opportunity REAL,
                supplier_score REAL,
                risk REAL,
                trust REAL,
                data_completeness REAL NOT NULL,
                decision TEXT NOT NULL,
                score REAL,
                reasons TEXT,
                created_at TEXT NOT NULL
            )
            """)

    def completeness(self,values):
        return round(sum(v is not None for v in values)/len(values)*100,1)

    def evaluate(self,name,category,profit,demand,price,market,supplier,risk,trust):
        vals=[profit,demand,price,market,supplier,risk,trust]
        comp=self.completeness(vals)
        reasons=[]

        # Critical information gates.
        if profit is not None and profit < MIN_NET_PROFIT:
            return "REJECT",0,comp,["net kâr €0,50 altında"]

        if risk is not None and risk >= 80:
            return "HOLD",0,comp,["risk çok yüksek"]

        if trust is not None and trust < 40:
            return "HOLD",0,comp,["güven skoru düşük"]

        if comp < 70:
            return "REVIEW",None,comp,["kritik veri eksik"]

        # Normalize positive and inverse risk signals.
        score=(
            demand*0.22 +
            price*0.12 +
            market*0.18 +
            supplier*0.18 +
            (100-risk)*0.12 +
            trust*0.10 +
            min(100,(profit/5)*100)*0.08
        )
        score=round(max(0,min(100,score)),1)

        if score>=80:
            decision="PRIORITY"
        elif score>=65:
            decision="REVIEW"
        else:
            decision="HOLD"

        if demand>=80: reasons.append("talep güçlü")
        if market>=80: reasons.append("pazar fırsatı güçlü")
        if supplier>=80: reasons.append("tedarikçi uygunluğu güçlü")
        if trust>=80: reasons.append("güven sinyali güçlü")
        if risk<=20: reasons.append("risk düşük")
        if profit>=1: reasons.append("net kâr yeterli")

        return decision,score,comp,reasons

    def add_product(self,name,category,profit,demand,price,market,supplier,risk,trust):
        decision,score,comp,reasons=self.evaluate(
            name,category,profit,demand,price,market,supplier,risk,trust
        )

        with self.connect() as c:
            c.execute("""
            INSERT INTO product_candidates
            (name,category,net_profit,demand,price_opportunity,market_opportunity,
             supplier_score,risk,trust,data_completeness,decision,score,reasons,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,(name,category,profit,demand,price,market,supplier,risk,trust,
                 comp,decision,score,"; ".join(reasons),self.now()))

        score_text=f"{score:.1f}" if score is not None else "N/A"
        return (
            f"{name} | karar={decision} | skor={score_text} | "
            f"veri=%{comp:.1f} | neden={'; '.join(reasons) or 'inceleme gerekli'}"
        )

    def demo(self):
        self.add_product(
            "5W-30 Motor Yağı","Otomotiv",
            2.40,88,84,86,91,12,94
        )
        self.add_product(
            "Örnek Ürün B","Otomotiv",
            .20,82,75,80,85,18,88
        )
        self.add_product(
            "Örnek Ürün C","Otomotiv",
            1.10,None,70,78,76,20,80
        )
        self.add_product(
            "Örnek Ürün D","Otomotiv",
            1.20,55,60,50,65,88,72
        )

    def report(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT name,category,net_profit,demand,price_opportunity,
                       market_opportunity,supplier_score,risk,trust,
                       data_completeness,decision,score,reasons
                FROM product_candidates
                ORDER BY
                    CASE decision
                      WHEN 'PRIORITY' THEN 1
                      WHEN 'REVIEW' THEN 2
                      WHEN 'HOLD' THEN 3
                      WHEN 'REJECT' THEN 4
                      ELSE 5 END,
                    score DESC
            """).fetchall()

        out=["=== BUZZARD v28 PRODUCT SELECTION RAPORU ==="]
        if not rows:
            out.append("- Ürün adayı yok.")

        for r in rows:
            score=f"{r['score']:.1f}" if r['score'] is not None else "N/A"
            out.append(
                f"- {r['name']} | {r['category']} | karar={r['decision']} | "
                f"skor={score} | net={r['net_profit'] if r['net_profit'] is not None else '-'} | "
                f"veri=%{r['data_completeness']:.1f}"
            )
            out.append(f"  → {r['reasons'] or 'inceleme gerekli'}")

        out += [
            "",
            "KARAR MANTIĞI:",
            "PRIORITY = araştırma/satış adayı olarak önceliklendir.",
            "REVIEW = uzman incelemesi gerekli.",
            "HOLD = kritik belirsizlik/risk nedeniyle beklet.",
            "REJECT = bu ticari değerlendirme kriterlerine göre uygun değil.",
            f"Minimum net kâr eşiği: €{MIN_NET_PROFIT:.2f}",
            "Bu motor otomatik satın alma veya hukuki uygunluk kararı vermez."
        ]
        return "\\n".join(out)
