import argparse
from buzzard_intelligence.selection import ProductSelector

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v28 Product Selection")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    a=s.add_parser("product")
    a.add_argument("--name",required=True)
    a.add_argument("--category",required=True)
    a.add_argument("--profit",type=float,default=None)
    a.add_argument("--demand",type=float,default=None)
    a.add_argument("--price",type=float,default=None)
    a.add_argument("--market",type=float,default=None)
    a.add_argument("--supplier",type=float,default=None)
    a.add_argument("--risk",type=float,default=None)
    a.add_argument("--trust",type=float,default=None)

    args=p.parse_args()
    app=ProductSelector()

    if args.cmd=="init":
        app.init(); print("v28 Automated Product Selection Engine hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo ürün seçim kayıtları hazır.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="product":
        app.init()
        print(app.add_product(
            args.name,args.category,args.profit,args.demand,args.price,
            args.market,args.supplier,args.risk,args.trust
        ))
    else:
        p.print_help()

if __name__=="__main__":
    main()
