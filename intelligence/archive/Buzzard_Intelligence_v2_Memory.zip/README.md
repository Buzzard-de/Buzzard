# Buzzard Intelligence v2 — Memory & Learning Engine

v2, v1'in hafıza katmanını geliştirir.

Özellikler:
- Kalıcı kategori, ürün, kaynak ve gözlem hafızası
- Aynı ürünün yeni gözlemlerini geçmişle karşılaştırma
- Fiyat değişimi tespiti
- Popülerlik değişimi tespiti
- Yeni ürün/kategori keşfi
- Kaynak ve gözlem tarihçesi
- Basit güven skoru
- Değişiklik raporu
- JSON dışa aktarma

Kurulum:
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py init
python main.py seed
```

Örnek:
```bash
python main.py add-observation --category "Otomotiv" --subcategory "Fren Sistemi" --product "Örnek Fren Balatası" --platform "Example" --country "DE" --price 49.90 --currency EUR --popularity 82 --source-url "https://example.com/product"
```

Karşılaştırma:
```bash
python main.py changes
python main.py memory "fren balatası"
python main.py export-memory
```

Not:
Bu sürümün "öğrenmesi", doğrulanmış gözlemleri zaman içinde saklayıp karşılaştırmasıdır. Kendi başına gerçek dünyada karar vermez veya doğrulanmamış bilgiyi gerçek kabul etmez. Gerçek web/API bağlayıcıları sonraki modülde eklenmelidir.
