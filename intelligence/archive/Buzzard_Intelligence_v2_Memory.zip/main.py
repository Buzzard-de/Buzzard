import argparse
from buzzard_intelligence.memory import MemoryEngine

def main():
    p = argparse.ArgumentParser(description="Buzzard Intelligence v2")
    s = p.add_subparsers(dest="cmd")

    s.add_parser("init")
    s.add_parser("seed")
    s.add_parser("changes")
    s.add_parser("export-memory")

    m = s.add_parser("memory")
    m.add_argument("query")

    a = s.add_parser("add-observation")
    a.add_argument("--category", required=True)
    a.add_argument("--subcategory", default="")
    a.add_argument("--subsubcategory", default="")
    a.add_argument("--product", required=True)
    a.add_argument("--brand", default="")
    a.add_argument("--platform", default="")
    a.add_argument("--country", default="")
    a.add_argument("--price", type=float)
    a.add_argument("--currency", default="EUR")
    a.add_argument("--popularity", type=float)
    a.add_argument("--source-url", required=True)
    a.add_argument("--source-name", default="")
    a.add_argument("--confidence", type=float, default=0.70)

    args = p.parse_args()
    db = MemoryEngine()

    if args.cmd == "init":
        db.init()
        print("v2 hafıza motoru hazır.")
    elif args.cmd == "seed":
        db.init()
        count = db.seed_categories()
        print(f"{count} ana kategori hafızaya alındı.")
    elif args.cmd == "add-observation":
        db.init()
        result = db.observe(
            args.category, args.subcategory, args.subsubcategory,
            args.product, args.brand, args.platform, args.country,
            args.price, args.currency, args.popularity,
            args.source_url, args.source_name, args.confidence
        )
        print(result)
    elif args.cmd == "changes":
        db.init()
        print(db.changes())
    elif args.cmd == "memory":
        db.init()
        print(db.search_memory(args.query))
    elif args.cmd == "export-memory":
        db.init()
        path = db.export_json()
        print(f"Hafıza dışa aktarıldı: {path}")
    else:
        p.print_help()

if __name__ == "__main__":
    main()
