# Buzzard Intelligence v30 — Autonomous Intelligence Mission System

v30, v20 Kurmay Heyeti + v21 AI Gateway + v22 araştırma + v23 connector + v24-v29 analiz katmanlarını tek bir görev akışında birleştiren mission orchestrator çekirdeğidir.

Amaç:
Kullanıcı tek bir üst düzey hedef verdiğinde sistem görevi alt görevlere bölebilsin:

1. Market Intelligence
2. Category Intelligence
3. Competitor Intelligence
4. Supplier Intelligence
5. Product Matching
6. Price Intelligence
7. Demand Forecasting
8. Profitability
9. Authenticity & Trust
10. Risk & Compliance
11. Official Verification
12. Council Manager / Synthesis

v30 özellikleri:
- Mission oluşturma
- Görevi otomatik alt görevlere bölme
- Öncelik ve bağımlılık tanımlama
- Uzman ajanlara görev dağıtma
- Her görevin çıktısını kaydetme
- Kanıt/kaynak bağlama
- Çelişkileri saklama
- Sentez aşaması
- İnsan onayı kapısı
- Mission durum takibi
- Audit log

ÖNEMLİ:
v30 "tamamen otonom ticari karar" sistemi değildir.
AI araştırabilir, analiz edebilir ve öneri oluşturabilir; ancak satın alma, hukuki onay, ödeme veya geri döndürülemez ticari işlem için insan onayı gerekir.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py board
```

Mission:
```bash
python main.py mission --title "Almanya'da yeni otomotiv ürün fırsatlarını araştır"
```

Görev çıktısı:
```bash
python main.py result --task-id 1 --agent "Market Intelligence" --result "Talep sinyali olumlu" --confidence 0.85
```

İnsan onayı:
```bash
python main.py approve --mission-id 1 --decision "APPROVED" --note "İnceleme tamamlandı."
```
