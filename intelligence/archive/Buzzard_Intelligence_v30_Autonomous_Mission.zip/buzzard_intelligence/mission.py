import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_mission_v30.db")

MISSION_STATUSES={
    "PLANNED","RUNNING","REVIEW","WAITING_HUMAN",
    "APPROVED","REJECTED","COMPLETED","BLOCKED"
}

TASK_STATUSES={
    "NEW","ASSIGNED","IN_PROGRESS","WAITING",
    "REVIEW","COMPLETED","BLOCKED"
}

class MissionEngine:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS missions(
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                details TEXT,
                priority INTEGER NOT NULL,
                status TEXT NOT NULL,
                human_decision TEXT,
                human_note TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS mission_tasks(
                id INTEGER PRIMARY KEY,
                mission_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                agent TEXT NOT NULL,
                purpose TEXT,
                priority INTEGER NOT NULL,
                status TEXT NOT NULL,
                depends_on TEXT,
                result TEXT,
                confidence REAL,
                evidence TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS mission_conflicts(
                id INTEGER PRIMARY KEY,
                mission_id INTEGER NOT NULL,
                task_a INTEGER NOT NULL,
                task_b INTEGER NOT NULL,
                description TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'OPEN',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS mission_log(
                id INTEGER PRIMARY KEY,
                mission_id INTEGER NOT NULL,
                task_id INTEGER,
                action TEXT NOT NULL,
                actor TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def create_mission(self,title,details="",priority=10):
        priority=max(1,min(10,priority))
        now=self.now()

        with self.connect() as c:
            cur=c.execute("""
                INSERT INTO missions
                (title,details,priority,status,created_at,updated_at)
                VALUES(?,?,?,?,?,?)
            """,(title,details,priority,"PLANNED",now,now))
            mid=cur.lastrowid

            plan=[
                ("Market Intelligence","Market Intelligence",
                 "Ülke/pazar talep ve fırsat sinyallerini araştır.",10,""),
                ("Category Intelligence","Category Intelligence",
                 "Kategori ve ürün fırsatlarını keşfet.",9,""),
                ("Competitor Intelligence","Competitor Intelligence",
                 "Yasal açık kaynaklardan rakip/kategori yapısını incele.",8,"1,2"),
                ("Supplier Intelligence","Supplier Intelligence",
                 "Uygun tedarikçileri ve entegrasyonları araştır.",8,"1,2"),
                ("Product Matching","Product Matching",
                 "Kaynaklardaki aynı ürünleri kimlik sinyalleriyle eşleştir.",7,"2,3,4"),
                ("Price Intelligence","Price Intelligence",
                 "Karşılaştırılabilir ürünlerde fiyat sinyallerini incele.",7,"5"),
                ("Demand Forecasting","Demand Forecasting",
                 "Mevcut talep sinyallerinden trend/tahmin üret.",7,"1,2"),
                ("Profitability","Profitability",
                 "Tüm bilinen maliyetlerle net kârı hesapla.",9,"4,6"),
                ("Authenticity & Trust","Authenticity & Trust",
                 "Ürün/marka/tedarik zinciri güvenini kontrol et.",9,"4,5"),
                ("Risk & Compliance","Risk & Compliance",
                 "Pazar, ürün, gümrük, vergi ve güvenlik risklerini incele.",10,"1,4,5"),
                ("Official Verification","Official Verification",
                 "Kritik iddiaları resmî kaynaklarla doğrula.",10,"3,4,9,10"),
                ("Council Manager","Council Manager",
                 "Tüm uzman çıktılarını sentezle; çelişkileri göster.",10,"6,7,8,9,10,11")
            ]

            task_ids=[]
            for title_,agent,purpose,p,depends in plan:
                cur2=c.execute("""
                    INSERT INTO mission_tasks
                    (mission_id,title,agent,purpose,priority,status,depends_on,
                     created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?)
                """,(mid,title_,agent,p,"NEW",depends,now,now))
                task_ids.append(cur2.lastrowid)

            c.execute("""
                INSERT INTO mission_log
                (mission_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """,(mid,"MISSION_CREATED","Council Manager",
                 f"{len(task_ids)} uzman görevi planlandı.",now))

            c.execute("""
                UPDATE missions SET status='RUNNING',updated_at=? WHERE id=?
            """,(now,mid))

        return f"Mission #{mid} oluşturuldu ve {len(task_ids)} uzman göreve ayrıldı."

    def add_result(self,task_id,agent,result,confidence,evidence):
        confidence=max(0,min(1,confidence))
        now=self.now()

        with self.connect() as c:
            task=c.execute("""
                SELECT id,mission_id FROM mission_tasks WHERE id=?
            """,(task_id,)).fetchone()

            if not task:
                return "Görev bulunamadı."

            c.execute("""
                UPDATE mission_tasks
                SET result=?,confidence=?,evidence=?,status='COMPLETED',
                    updated_at=?
                WHERE id=?
            """,(result,confidence,evidence,now,task_id))

            c.execute("""
                INSERT INTO mission_log
                (mission_id,task_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?,?)
            """,(task["mission_id"],task_id,"TASK_RESULT",agent,result,now))

            # Tüm görevler tamamlandıysa insan onayı kapısına geç.
            open_tasks=c.execute("""
                SELECT COUNT(*) n FROM mission_tasks
                WHERE mission_id=? AND status NOT IN ('COMPLETED')
            """,(task["mission_id"],)).fetchone()["n"]

            if open_tasks==0:
                c.execute("""
                    UPDATE missions
                    SET status='WAITING_HUMAN',updated_at=?
                    WHERE id=?
                """,(now,task["mission_id"]))

        return f"Görev #{task_id} sonucu kaydedildi."

    def approve(self,mission_id,decision,note):
        decision=decision.upper()
        if decision not in ("APPROVED","REJECTED"):
            return "Decision APPROVED veya REJECTED olmalı."

        now=self.now()
        with self.connect() as c:
            m=c.execute(
                "SELECT id FROM missions WHERE id=?",(mission_id,)
            ).fetchone()
            if not m:
                return "Mission bulunamadı."

            c.execute("""
                UPDATE missions
                SET status=?,human_decision=?,human_note=?,updated_at=?
                WHERE id=?
            """,(decision,decision,note,now,mission_id))

            c.execute("""
                INSERT INTO mission_log
                (mission_id,action,actor,details,created_at)
                VALUES(?,?,?,?,?)
            """,(mission_id,"HUMAN_DECISION","Human Approver",note,now))

        return f"Mission #{mission_id} -> {decision}"

    def demo(self):
        self.create_mission(
            "Almanya'da yeni otomotiv ürün fırsatlarını araştır",
            "Demo: pazar, ürün, rakip, tedarikçi, fiyat, talep, kâr ve risk.",
            10
        )

    def board(self):
        with self.connect() as c:
            missions=c.execute("""
                SELECT id,title,priority,status,human_decision,
                       created_at,updated_at
                FROM missions
                ORDER BY priority DESC,updated_at DESC
            """).fetchall()

            tasks=c.execute("""
                SELECT id,mission_id,title,agent,priority,status,
                       result,confidence,depends_on
                FROM mission_tasks
                ORDER BY mission_id,priority DESC,id
            """).fetchall()

            conflicts=c.execute("""
                SELECT mission_id,task_a,task_b,description,status
                FROM mission_conflicts
                WHERE status='OPEN'
            """).fetchall()

        out=["=== BUZZARD v30 AUTONOMOUS MISSION BOARD ===","",
             "MISSIONS"]

        for m in missions:
            out.append(
                f"- Mission #{m['id']} | {m['title']} | "
                f"durum={m['status']} | insan kararı={m['human_decision'] or '-'}"
            )

            for t in [x for x in tasks if x["mission_id"]==m["id"]]:
                conf=f"{t['confidence']:.2f}" if t["confidence"] is not None else "-"
                out.append(
                    f"  #{t['id']} [{t['priority']}/10] {t['agent']} | "
                    f"{t['title']} | {t['status']} | güven={conf}"
                )

        out += ["","AÇIK ÇELİŞKİLER"]
        if conflicts:
            for c in conflicts:
                out.append(
                    f"- mission #{c['mission_id']} | görev {c['task_a']} "
                    f"<-> {c['task_b']} | {c['description']}"
                )
        else:
            out.append("- Açık çelişki kaydı yok.")

        out += [
            "",
            "v30 KURALI:",
            "Sistem araştırma ve analiz işlerini otonom olarak orkestre edebilir.",
            "Nihai satın alma, ödeme, hukuki onay veya geri döndürülemez ticari işlem için insan onayı gerekir.",
            "Kaynak ve kanıtlar görev çıktılarıyla birlikte saklanır."
        ]
        return "\\n".join(out)
