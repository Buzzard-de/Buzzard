import argparse
from buzzard_intelligence.mission import MissionEngine

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v30 Autonomous Mission")
    s=p.add_subparsers(dest="cmd")

    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("board")

    m=s.add_parser("mission")
    m.add_argument("--title",required=True)
    m.add_argument("--details",default="")
    m.add_argument("--priority",type=int,default=10)

    r=s.add_parser("result")
    r.add_argument("--task-id",type=int,required=True)
    r.add_argument("--agent",required=True)
    r.add_argument("--result",required=True)
    r.add_argument("--confidence",type=float,default=.8)
    r.add_argument("--evidence",default="")

    a=s.add_parser("approve")
    a.add_argument("--mission-id",type=int,required=True)
    a.add_argument("--decision",required=True)
    a.add_argument("--note",default="")

    args=p.parse_args()
    app=MissionEngine()

    if args.cmd=="init":
        app.init(); print("v30 Autonomous Intelligence Mission System hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo mission oluşturuldu.")
    elif args.cmd=="board":
        app.init(); print(app.board())
    elif args.cmd=="mission":
        app.init(); print(app.create_mission(args.title,args.details,args.priority))
    elif args.cmd=="result":
        app.init()
        print(app.add_result(
            args.task_id,args.agent,args.result,args.confidence,args.evidence
        ))
    elif args.cmd=="approve":
        app.init()
        print(app.approve(args.mission_id,args.decision,args.note))
    else:
        p.print_help()

if __name__=="__main__":
    main()
