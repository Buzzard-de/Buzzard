# Buzzard Intelligence v31 — Learning & Memory Engine

v31, istihbarat sisteminin araştırmalardan kalıcı, açıklanabilir ve geri çağrılabilir bilgi üretmesini sağlar.

Amaç:
- gözlem, bulgu, karar ve sonuçları kalıcı hafızada saklamak
- aynı konuyla ilgili yeni araştırmada eski bilgileri geri çağırmak
- bilgiye kaynak, zaman, güven ve durum bağlamak
- yeni kanıt geldiğinde eski bilginin güncellenebilmesini sağlamak
- öğrenme geçmişini/audit trail'i korumak
- çelişkili bilgileri silmeden ayrı durumlarda tutmak
- unutma/eskime (staleness) sinyali oluşturmak

Bellek türleri:
- FACT — kaynaklı bilgi
- SIGNAL — pazar/fiyat/talep sinyali
- DECISION — insan veya kurmay kararı
- LESSON — geçmiş sonuçtan çıkarılan ders
- PREFERENCE — sistem/business rule

Durumlar:
- ACTIVE
- NEEDS_REVIEW
- OUTDATED
- CONFLICT
- ARCHIVED

ÖNEMLİ:
v31 kendi kendine "gerçek" icat etmez. Öğrenme, kaydedilmiş gözlem ve kanıtlardan oluşur.
Bir bilgiye yeni kanıt gelirse geçmiş kayıt silinmez; yeni sürüm/kanıt bağlantısı oluşturulur.
Kritik ticari kararlar insan onayından bağımsız otomatik olarak değiştirilemez.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py recall --query "5W-30 motor yağı"
python main.py report
```

Bilgi ekleme:
```bash
python main.py remember --kind FACT --topic "Otomotiv" --text "Örnek bulgu" --confidence 0.85 --source "https://example.com"
```

Ders ekleme:
```bash
python main.py lesson --topic "Tedarikçi" --text "Belgeleri doğrulanmayan tedarikçiyi önceliklendirme."
```
