import sqlite3
import re
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_learning_memory_v31.db")

KINDS={"FACT","SIGNAL","DECISION","LESSON","PREFERENCE"}
STATUSES={"ACTIVE","NEEDS_REVIEW","OUTDATED","CONFLICT","ARCHIVED"}

class MemoryEngine:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS memories(
                id INTEGER PRIMARY KEY,
                kind TEXT NOT NULL,
                topic TEXT NOT NULL,
                text TEXT NOT NULL,
                confidence REAL NOT NULL,
                status TEXT NOT NULL,
                source TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS memory_links(
                id INTEGER PRIMARY KEY,
                memory_id INTEGER NOT NULL,
                related_memory_id INTEGER NOT NULL,
                relation TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS memory_events(
                id INTEGER PRIMARY KEY,
                memory_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def normalize(self,s):
        return re.sub(r"\s+"," ",(s or "").strip().lower())

    def remember(self,kind,topic,text,confidence=.8,source=""):
        kind=kind.upper()
        if kind not in KINDS:
            return "Geçersiz memory türü: "+", ".join(sorted(KINDS))
        confidence=max(0,min(1,float(confidence)))
        now=self.now()

        with self.connect() as c:
            cur=c.execute("""
                INSERT INTO memories
                (kind,topic,text,confidence,status,source,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?)
            """,(kind,topic,text,confidence,"ACTIVE",source,now,now))
            mid=cur.lastrowid

            c.execute("""
                INSERT INTO memory_events
                (memory_id,action,details,created_at)
                VALUES(?,?,?,?)
            """,(mid,"CREATED",source,now))

        return f"Hafıza #{mid} kaydedildi."

    def lesson(self,topic,text):
        return self.remember("LESSON",topic,text,.95,"INTERNAL_LESSON")

    def recall(self,query,limit=20):
        terms=[x for x in self.normalize(query).split(" ") if len(x)>=2]
        limit=max(1,min(100,limit))

        with self.connect() as c:
            rows=c.execute("""
                SELECT id,kind,topic,text,confidence,status,source,updated_at
                FROM memories
                WHERE status IN ('ACTIVE','NEEDS_REVIEW','CONFLICT')
                ORDER BY confidence DESC,updated_at DESC
            """).fetchall()

        scored=[]
        q=self.normalize(query)
        for r in rows:
            hay=self.normalize(r["topic"]+" "+r["text"])
            score=sum(1 for t in terms if t in hay)
            if q and q in hay:
                score+=3
            if score:
                scored.append((score,r))

        scored.sort(key=lambda x:(x[0],x[1]["confidence"]),reverse=True)

        if not scored:
            return "Eşleşen hafıza bulunamadı."

        out=[f"=== BUZZARD MEMORY RECALL: {query} ==="]
        for score,r in scored[:limit]:
            out.append(
                f"- #{r['id']} [{r['kind']}] {r['topic']} | "
                f"güven={r['confidence']:.2f} | durum={r['status']}"
            )
            out.append(f"  {r['text']}")
            if r["source"]:
                out.append(f"  kaynak: {r['source']}")
        return "\\n".join(out)

    def set_status(self,memory_id,status):
        status=status.upper()
        if status not in STATUSES:
            return "Geçersiz durum: "+", ".join(sorted(STATUSES))
        now=self.now()

        with self.connect() as c:
            row=c.execute(
                "SELECT id FROM memories WHERE id=?",(memory_id,)
            ).fetchone()
            if not row:
                return "Hafıza kaydı bulunamadı."

            c.execute("""
                UPDATE memories SET status=?,updated_at=? WHERE id=?
            """,(status,now,memory_id))

            c.execute("""
                INSERT INTO memory_events
                (memory_id,action,details,created_at)
                VALUES(?,?,?,?)
            """,(memory_id,"STATUS_CHANGE",status,now))

        return f"Hafıza #{memory_id} -> {status}"

    def demo(self):
        self.remember(
            "FACT","Otomotiv",
            "Örnek üretici kaynağında ürün listeleniyor.",
            .96,"https://example.com/manufacturer"
        )
        self.remember(
            "SIGNAL","Fiyat",
            "Örnek ürün için fiyat düşüş sinyali gözlendi.",
            .82,"https://example.com/price"
        )
        self.lesson(
            "Tedarikçi",
            "Güvenilirliği ve belgeleri doğrulanmayan tedarikçi önceliklendirilmemeli."
        )
        self.remember(
            "PREFERENCE","Buzzard",
            "Kritik ticari kararlarda insan onayı korunmalı.",
            1.0,"INTERNAL_RULE"
        )

    def report(self):
        with self.connect() as c:
            counts=c.execute("""
                SELECT kind,status,COUNT(*) n
                FROM memories
                GROUP BY kind,status
                ORDER BY kind,status
            """).fetchall()

            recent=c.execute("""
                SELECT id,kind,topic,confidence,status,updated_at
                FROM memories
                ORDER BY updated_at DESC
                LIMIT 20
            """).fetchall()

        out=["=== BUZZARD v31 LEARNING & MEMORY RAPORU ===","",
             "HAFIZA DURUMU"]
        for r in counts:
            out.append(
                f"- {r['kind']} | {r['status']} | {r['n']} kayıt"
            )

        out += ["","SON KAYITLAR"]
        for r in recent:
            out.append(
                f"- #{r['id']} [{r['kind']}] {r['topic']} | "
                f"güven={r['confidence']:.2f} | {r['status']}"
            )

        out += [
            "",
            "KURAL:",
            "Yeni bilgi eski kaydı sessizce silmez.",
            "Kaynak, güven, durum ve zaman korunur.",
            "Çelişkiler CONFLICT olarak tutulabilir.",
            "Kritik ticari kurallar insan onayı olmadan değiştirilmemelidir."
        ]
        return "\\n".join(out)
