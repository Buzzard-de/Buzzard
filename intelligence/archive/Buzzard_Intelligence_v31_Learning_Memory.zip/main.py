import argparse
from buzzard_intelligence.memory import MemoryEngine

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v31 Learning & Memory")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    r=s.add_parser("remember")
    r.add_argument("--kind",required=True)
    r.add_argument("--topic",required=True)
    r.add_argument("--text",required=True)
    r.add_argument("--confidence",type=float,default=.8)
    r.add_argument("--source",default="")

    l=s.add_parser("lesson")
    l.add_argument("--topic",required=True)
    l.add_argument("--text",required=True)

    q=s.add_parser("recall")
    q.add_argument("--query",required=True)
    q.add_argument("--limit",type=int,default=20)

    a=s.add_parser("status")
    a.add_argument("--memory-id",type=int,required=True)
    a.add_argument("--status",required=True)

    args=p.parse_args()
    app=MemoryEngine()

    if args.cmd=="init":
        app.init(); print("v31 Learning & Memory Engine hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo hafıza kayıtları oluşturuldu.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="remember":
        app.init()
        print(app.remember(args.kind,args.topic,args.text,args.confidence,args.source))
    elif args.cmd=="lesson":
        app.init(); print(app.lesson(args.topic,args.text))
    elif args.cmd=="recall":
        app.init(); print(app.recall(args.query,args.limit))
    elif args.cmd=="status":
        app.init(); print(app.set_status(args.memory_id,args.status))
    else:
        p.print_help()

if __name__=="__main__":
    main()
