# Buzzard Intelligence v32 — Category Intelligence Engine

v32, Buzzard'ın hedeflediği geniş ürün evrenini merkezi bir kategori istihbarat kataloğuna dönüştürür.

Temel amaç:
- 100+ kategori ve alt kategori adayını merkezi olarak tutmak
- kategori önceliği vermek
- pazar/talep/rakip/tedarikçi/veri sinyallerini kategori seviyesinde toplamak
- hangi kategorilerin Buzzard'da bulunduğunu ve hangilerinin eksik olduğunu görmek
- yeni ürün keşfi için kategori araştırma kuyruğu oluşturmak
- kategori araştırmalarını v31 hafızasına bağlanabilecek şekilde yapılandırmak

v32 otomatik olarak ürün eklemez. Kategori fırsatını araştırma önceliğine dönüştürür.

Kurulum:
```bash
python main.py init
python main.py seed
python main.py report
python main.py queue
```

Kategori sinyali:
```bash
python main.py signal --category "Automotive" --demand 90 --competition 70 --supplier 85 --margin 80 --risk 20
```

Buzzard'da mevcut kategori:
```bash
python main.py owned --category "Automotive"
```
