import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_category_intelligence_v32.db")

CATEGORIES = ['Automotive', 'Agricultural Machinery', 'Tools', 'Garden', 'Home & Living', 'Cleaning', 'Personal Care', 'Cosmetics', 'Electronics', 'Computers', 'Mobile Accessories', 'Appliances', 'Kitchen', 'Furniture', 'Lighting', 'DIY & Hardware', 'Construction', 'Industrial Supplies', 'Workwear', 'Safety Equipment', 'Sports', 'Outdoor', 'Camping', 'Bicycles', 'Baby Products', 'Toys', 'Pet Supplies', 'Office Supplies', 'School Supplies', 'Books & Media', 'Hobby & Crafts', 'Fashion', 'Shoes', 'Bags & Luggage', 'Jewelry & Accessories', 'Watches', 'Beauty Accessories', 'Health & Wellness', 'Food', 'Beverages', 'Household Consumables', 'Paper Products', 'Packaging', 'Storage & Organization', 'Home Improvement', 'Bathroom', 'Bedroom', 'Living Room', 'Laundry', 'Heating & Cooling', 'Smart Home', 'Security', 'Networking', 'Audio', 'TV & Video', 'Photography', 'Gaming', 'Computer Components', 'Printers & Supplies', 'Cables & Adapters', 'Power Tools', 'Hand Tools', 'Workshop Equipment', 'Fasteners', 'Electrical Supplies', 'Plumbing', 'Paint & Decorating', 'Automotive Fluids & Lubricants', 'Automotive Tires', 'Automotive Batteries', 'Automotive Brakes', 'Automotive Filters', 'Automotive Lighting', 'Automotive Body Parts', 'Automotive Interior', 'Automotive Cleaning', 'Tractor Parts', 'Harvester Parts', 'Trailer Parts', 'Agricultural Tires', 'Agricultural Equipment', 'Irrigation', 'Plant Care', 'Seeds & Gardening Supplies', 'Greenhouse Supplies', 'Outdoor Furniture', 'Barbecue & Grilling', 'Travel Accessories', 'Seasonal Products', 'Christmas', 'School Season', 'Gifts', 'Pet Food', 'Pet Care', 'Office Furniture', 'Restaurant Supplies', 'Hotel Supplies', 'Industrial Safety', 'Warehouse Equipment', 'Logistics Supplies', 'Renewable Energy', 'Solar Accessories', 'EV Charging', 'E-Mobility', 'Caravan & Camping', 'Marine Accessories', 'Motorcycle', 'Motorcycle Parts', 'Vehicle Accessories', 'Car Electronics', 'Car Care', 'Tools & Workshop', 'Lubricants & Chemicals', 'B2B Supplies']

class CategoryIntel:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS categories(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                parent TEXT,
                owned INTEGER NOT NULL DEFAULT 0,
                priority REAL NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS category_signals(
                id INTEGER PRIMARY KEY,
                category_id INTEGER NOT NULL,
                demand REAL,
                competition REAL,
                supplier REAL,
                margin REAL,
                risk REAL,
                opportunity REAL,
                created_at TEXT NOT NULL
            );
            """)

    def seed(self):
        now=self.now()
        with self.connect() as c:
            for name in CATEGORIES:
                c.execute("""
                    INSERT OR IGNORE INTO categories
                    (name,owned,priority,created_at,updated_at)
                    VALUES(?,?,?,?,?)
                """,(name,0,0,now,now))
        return f"{len(CATEGORIES)} kategori kataloğa işlendi."

    def set_owned(self,category):
        now=self.now()
        with self.connect() as c:
            row=c.execute(
                "SELECT id FROM categories WHERE lower(name)=lower(?)",
                (category,)
            ).fetchone()
            if not row:
                c.execute("""
                    INSERT INTO categories
                    (name,owned,priority,created_at,updated_at)
                    VALUES(?,?,?,?,?)
                """,(category,1,0,now,now))
                return f"Yeni kategori oluşturuldu ve mevcut olarak işaretlendi: {category}"
            c.execute("""
                UPDATE categories SET owned=1,updated_at=? WHERE id=?
            """,(now,row["id"]))
        return f"Kategori mevcut olarak işaretlendi: {category}"

    def add_signal(self,category,demand,competition,supplier,margin,risk):
        vals=[demand,competition,supplier,margin,risk]
        for v in vals:
            if v is not None and not 0<=v<=100:
                return "Tüm sinyaller 0-100 arasında olmalı."

        now=self.now()
        with self.connect() as c:
            row=c.execute(
                "SELECT id FROM categories WHERE lower(name)=lower(?)",
                (category,)
            ).fetchone()
            if not row:
                c.execute("""
                    INSERT INTO categories
                    (name,owned,priority,created_at,updated_at)
                    VALUES(?,?,?,?,?)
                """,(category,0,0,now,now))
                cid=c.execute("SELECT last_insert_rowid()").fetchone()[0]
            else:
                cid=row["id"]

            if any(v is None for v in vals):
                opportunity=None
            else:
                opportunity=round(
                    demand*.28 +
                    (100-competition)*.15 +
                    supplier*.20 +
                    margin*.25 +
                    (100-risk)*.12,1
                )

            c.execute("""
                INSERT INTO category_signals
                (category_id,demand,competition,supplier,margin,risk,opportunity,created_at)
                VALUES(?,?,?,?,?,?,?,?)
            """,(cid,demand,competition,supplier,margin,risk,opportunity,now))

            if opportunity is not None:
                c.execute("""
                    UPDATE categories SET priority=?,updated_at=? WHERE id=?
                """,(opportunity,now,cid))

        score=f"{opportunity:.1f}" if opportunity is not None else "N/A"
        return f"{category} | fırsat skoru={score}"

    def queue(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT c.name,c.owned,c.priority,
                       s.demand,s.competition,s.supplier,s.margin,s.risk
                FROM categories c
                LEFT JOIN category_signals s ON s.id=(
                    SELECT id FROM category_signals
                    WHERE category_id=c.id ORDER BY id DESC LIMIT 1
                )
                ORDER BY c.priority DESC,c.name
            """).fetchall()

        out=["=== BUZZARD v32 CATEGORY RESEARCH QUEUE ==="]
        for r in rows:
            status="MEVCUT" if r["owned"] else "EKSİK"
            score=f"{r['priority']:.1f}" if r["priority"] else "0.0"
            out.append(
                f"- {r['name']} | {status} | öncelik={score}"
            )
        return "\\n".join(out)

    def report(self):
        with self.connect() as c:
            total=c.execute("SELECT COUNT(*) n FROM categories").fetchone()["n"]
            owned=c.execute("SELECT COUNT(*) n FROM categories WHERE owned=1").fetchone()["n"]
            signals=c.execute("SELECT COUNT(*) n FROM category_signals").fetchone()["n"]
            top=c.execute("""
                SELECT name,priority,owned
                FROM categories
                ORDER BY priority DESC,name
                LIMIT 20
            """).fetchall()

        out=[
            "=== BUZZARD v32 CATEGORY INTELLIGENCE RAPORU ===",
            f"Kategori sayısı: {total}",
            f"Buzzard'da mevcut işaretlenen: {owned}",
            f"Kategori sinyali: {signals}",
            "",
            "ÖNCELİKLİ KATEGORİLER"
        ]
        for r in top:
            status="MEVCUT" if r["owned"] else "EKSİK"
            out.append(
                f"- {r['name']} | öncelik={r['priority']:.1f} | {status}"
            )
        out += [
            "",
            "KURAL:",
            "Kategori listesi keşif/araştırma evrenidir; otomatik ürün alımı değildir.",
            "Eksik kategori önce araştırma kuyruğuna girer.",
            "Gerçek pazar sinyali olmadan kategori fırsatı kesin kabul edilmez."
        ]
        return "\\n".join(out)
