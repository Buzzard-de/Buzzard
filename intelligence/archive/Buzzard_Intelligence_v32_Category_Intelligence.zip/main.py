import argparse
from buzzard_intelligence.categories import CategoryIntel

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v32 Category Intelligence")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("seed")
    s.add_parser("report")
    s.add_parser("queue")

    a=s.add_parser("signal")
    a.add_argument("--category",required=True)
    a.add_argument("--demand",type=float,default=None)
    a.add_argument("--competition",type=float,default=None)
    a.add_argument("--supplier",type=float,default=None)
    a.add_argument("--margin",type=float,default=None)
    a.add_argument("--risk",type=float,default=None)

    o=s.add_parser("owned")
    o.add_argument("--category",required=True)

    args=p.parse_args()
    app=CategoryIntel()

    if args.cmd=="init":
        app.init(); print("v32 Category Intelligence Engine hazır.")
    elif args.cmd=="seed":
        app.init(); print(app.seed())
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="queue":
        app.init(); print(app.queue())
    elif args.cmd=="signal":
        app.init()
        print(app.add_signal(args.category,args.demand,args.competition,args.supplier,args.margin,args.risk))
    elif args.cmd=="owned":
        app.init(); print(app.set_owned(args.category))
    else:
        p.print_help()

if __name__=="__main__":
    main()
