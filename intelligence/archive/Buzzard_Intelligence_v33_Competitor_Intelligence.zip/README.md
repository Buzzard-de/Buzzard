# Buzzard Intelligence v33 — Competitor Intelligence Engine

v33, rakipleri yalnızca isim olarak değil; kamuya açık kategori, ürün, fiyat ve görünür ticari sinyaller üzerinden yapılandırılmış şekilde takip eder.

Amaç:
- rakip şirket/site kayıtlarını tutmak
- kamuya açık kategori ve alt kategori yapılarını kaydetmek
- listelenen ürünleri ve ürün sayısını izlemek
- fiyat gözlemlerini bağlamak
- görünür "çok satan / öne çıkan / popüler" sinyallerini kaydetmek
- rakiplerin hangi pazarlarda aktif olduğunu takip etmek
- zaman içindeki değişiklikleri karşılaştırmak
- Buzzard için fırsat ve tehdit sinyalleri üretmek

Yasal sınırlar:
- yalnızca açık ve kamuya erişilebilir bilgiler
- gizli hesaplara, özel panellere veya yetkisiz API'lere erişim yok
- CAPTCHA, giriş duvarı veya teknik erişim kısıtlamaları aşılmaz
- kişisel veri hedeflenmez
- rakibin gizli ticari bilgileri aranmaz
- "tahmin" ile "kaynaklı gözlem" birbirinden ayrılır

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
python main.py changes --competitor "Example Marketplace"
```

Rakip:
```bash
python main.py competitor --name "Example Marketplace" --url "https://example.com" --market "Germany"
```

Kategori:
```bash
python main.py category --competitor "Example Marketplace" --category "Automotive" --count 120
```

Ürün:
```bash
python main.py product --competitor "Example Marketplace" --category "Automotive" --name "Example 5W-30" --price 49.90 --currency EUR --signal "featured"
```
