import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

DB=Path("buzzard_competitor_v33.db")

class CompetitorIntel:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS competitors(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                url TEXT NOT NULL,
                market TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'ACTIVE',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS competitor_categories(
                id INTEGER PRIMARY KEY,
                competitor_id INTEGER NOT NULL,
                category TEXT NOT NULL,
                product_count INTEGER,
                url TEXT,
                observed_at TEXT NOT NULL,
                UNIQUE(competitor_id,category)
            );

            CREATE TABLE IF NOT EXISTS competitor_products(
                id INTEGER PRIMARY KEY,
                competitor_id INTEGER NOT NULL,
                category TEXT NOT NULL,
                name TEXT NOT NULL,
                price REAL,
                currency TEXT,
                visibility_signal TEXT,
                url TEXT,
                observed_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS competitor_events(
                id INTEGER PRIMARY KEY,
                competitor_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                details TEXT NOT NULL,
                observed_at TEXT NOT NULL
            );
            """)

    def add_competitor(self,name,url,market):
        parsed=urlparse(url)
        if parsed.scheme not in ("http","https"):
            return "Yalnızca http/https URL kabul edilir."
        now=self.now()
        with self.connect() as c:
            c.execute("""
                INSERT OR REPLACE INTO competitors
                (name,url,market,status,created_at,updated_at)
                VALUES(?,?,?,?,?,?)
            """,(name,url,market,"ACTIVE",now,now))
        return f"Rakip kaydedildi: {name}"

    def get_competitor(self,name):
        with self.connect() as c:
            return c.execute(
                "SELECT * FROM competitors WHERE lower(name)=lower(?)",
                (name,)
            ).fetchone()

    def add_category(self,competitor,category,count,url):
        row=self.get_competitor(competitor)
        if not row:
            return "Rakip bulunamadı."
        if count < 0:
            return "Ürün sayısı negatif olamaz."
        now=self.now()
        with self.connect() as c:
            c.execute("""
                INSERT OR REPLACE INTO competitor_categories
                (competitor_id,category,product_count,url,observed_at)
                VALUES(?,?,?,?,?)
            """,(row["id"],category,count,url,now))
            c.execute("""
                INSERT INTO competitor_events
                (competitor_id,event_type,details,observed_at)
                VALUES(?,?,?,?)
            """,(row["id"],"CATEGORY_OBSERVED",
                 f"{category} | ürün={count}",now))
        return f"{competitor}: kategori kaydedildi -> {category}"

    def add_product(self,competitor,category,name,price,currency,signal,url):
        row=self.get_competitor(competitor)
        if not row:
            return "Rakip bulunamadı."
        if price is not None and price < 0:
            return "Fiyat negatif olamaz."
        now=self.now()
        with self.connect() as c:
            c.execute("""
                INSERT INTO competitor_products
                (competitor_id,category,name,price,currency,visibility_signal,url,observed_at)
                VALUES(?,?,?,?,?,?,?,?)
            """,(row["id"],category,name,price,currency,signal,url,now))
            c.execute("""
                INSERT INTO competitor_events
                (competitor_id,event_type,details,observed_at)
                VALUES(?,?,?,?)
            """,(row["id"],"PRODUCT_OBSERVED",
                 f"{category} | {name} | signal={signal}",now))
        return f"Rakip ürünü kaydedildi: {name}"

    def changes(self,competitor):
        row=self.get_competitor(competitor)
        if not row:
            return "Rakip bulunamadı."
        with self.connect() as c:
            cats=c.execute("""
                SELECT category,product_count,observed_at
                FROM competitor_categories
                WHERE competitor_id=?
                ORDER BY observed_at DESC
            """,(row["id"],)).fetchall()
            events=c.execute("""
                SELECT event_type,details,observed_at
                FROM competitor_events
                WHERE competitor_id=?
                ORDER BY observed_at DESC
                LIMIT 30
            """,(row["id"],)).fetchall()

        out=[f"=== RAKİP DEĞİŞİM RAPORU: {competitor} ===","",
             "SON KATEGORİ GÖZLEMLERİ"]
        for r in cats:
            out.append(
                f"- {r['category']} | ürün={r['product_count']} | {r['observed_at']}"
            )
        out += ["","SON OLAYLAR"]
        for r in events:
            out.append(
                f"- {r['event_type']} | {r['details']} | {r['observed_at']}"
            )
        return "\\n".join(out)

    def demo(self):
        self.add_competitor(
            "Example Marketplace","https://example.com","Germany"
        )
        self.add_category("Example Marketplace","Automotive",120,"https://example.com/auto")
        self.add_category("Example Marketplace","Garden",85,"https://example.com/garden")
        self.add_product(
            "Example Marketplace","Automotive","Example 5W-30",
            49.90,"EUR","featured","https://example.com/5w30"
        )
        self.add_product(
            "Example Marketplace","Automotive","Example Brake Pad",
            79.90,"EUR","popular","https://example.com/brake"
        )

    def report(self):
        with self.connect() as c:
            comps=c.execute("""
                SELECT c.name,c.market,c.url,c.status,
                       COUNT(DISTINCT cc.id) category_count,
                       COUNT(DISTINCT cp.id) product_observations
                FROM competitors c
                LEFT JOIN competitor_categories cc ON cc.competitor_id=c.id
                LEFT JOIN competitor_products cp ON cp.competitor_id=c.id
                GROUP BY c.id
                ORDER BY c.name
            """).fetchall()

            cats=c.execute("""
                SELECT c.name competitor,cc.category,cc.product_count
                FROM competitor_categories cc
                JOIN competitors c ON c.id=cc.competitor_id
                ORDER BY c.name,cc.product_count DESC
            """).fetchall()

            products=c.execute("""
                SELECT c.name competitor,cp.category,cp.name product,
                       cp.price,cp.currency,cp.visibility_signal
                FROM competitor_products cp
                JOIN competitors c ON c.id=cp.competitor_id
                ORDER BY c.name,cp.category,cp.name
            """).fetchall()

        out=["=== BUZZARD v33 COMPETITOR INTELLIGENCE RAPORU ===",
             "","RAKİPLER"]
        for r in comps:
            out.append(
                f"- {r['name']} | pazar={r['market']} | durum={r['status']} | "
                f"kategori gözlemi={r['category_count']} | "
                f"ürün gözlemi={r['product_observations']}"
            )

        out += ["","KATEGORİ GÖZLEMLERİ"]
        for r in cats:
            out.append(
                f"- {r['competitor']} | {r['category']} | ürün={r['product_count']}"
            )

        out += ["","ÜRÜN GÖZLEMLERİ"]
        for r in products:
            price=f"{r['price']:.2f} {r['currency']}" if r['price'] is not None else "-"
            out.append(
                f"- {r['competitor']} | {r['category']} | {r['product']} | "
                f"fiyat={price} | sinyal={r['visibility_signal'] or '-'}"
            )

        out += [
            "",
            "YASAL İSTİHBARAT KURALI:",
            "Yalnızca kamuya açık ve yasal olarak erişilebilir bilgiler kullanılır.",
            "Gizli/özel verilere erişim, CAPTCHA veya erişim kontrolü aşma yoktur.",
            "Öne çıkan/çok satan sinyali yalnızca kaynağın açıkça gösterdiği bir gözlemdir.",
            "Gözlem ile tahmin birbirinden ayrılır."
        ]
        return "\\n".join(out)
