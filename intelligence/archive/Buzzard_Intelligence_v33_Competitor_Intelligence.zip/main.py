import argparse
from buzzard_intelligence.competitor import CompetitorIntel

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v33 Competitor Intelligence")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")

    c=s.add_parser("competitor")
    c.add_argument("--name",required=True)
    c.add_argument("--url",required=True)
    c.add_argument("--market",required=True)

    ca=s.add_parser("category")
    ca.add_argument("--competitor",required=True)
    ca.add_argument("--category",required=True)
    ca.add_argument("--count",type=int,default=0)
    ca.add_argument("--url",default="")

    pr=s.add_parser("product")
    pr.add_argument("--competitor",required=True)
    pr.add_argument("--category",required=True)
    pr.add_argument("--name",required=True)
    pr.add_argument("--price",type=float)
    pr.add_argument("--currency",default="EUR")
    pr.add_argument("--signal",default="")
    pr.add_argument("--url",default="")

    ch=s.add_parser("changes")
    ch.add_argument("--competitor",required=True)

    args=p.parse_args()
    app=CompetitorIntel()

    if args.cmd=="init":
        app.init(); print("v33 Competitor Intelligence Engine hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo rakip istihbarat kayıtları hazır.")
    elif args.cmd=="report":
        app.init(); print(app.report())
    elif args.cmd=="competitor":
        app.init(); print(app.add_competitor(args.name,args.url,args.market))
    elif args.cmd=="category":
        app.init(); print(app.add_category(args.competitor,args.category,args.count,args.url))
    elif args.cmd=="product":
        app.init()
        print(app.add_product(
            args.competitor,args.category,args.name,args.price,
            args.currency,args.signal,args.url
        ))
    elif args.cmd=="changes":
        app.init(); print(app.changes(args.competitor))
    else:
        p.print_help()

if __name__=="__main__":
    main()
