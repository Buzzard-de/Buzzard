BUZZARD INTELLIGENCE v33-V40 BUNDLE

Bu klasörde v33 ile v40 arasındaki tüm sürümler ayrı ZIP olarak bulunur.
v33 mevcut önceki paketten dahil edilmiştir.
v34-v40 bu paketin içinde oluşturulmuştur.

Sıra:
v33 Competitor Intelligence
v34 Alerts & Anomaly Detection
v35 Deep Category Taxonomy
v36 Market Geography
v37 Risk & Compliance
v38 Profitability & Scenario
v39 Intelligence Dashboard
v40 Master Intelligence Core
