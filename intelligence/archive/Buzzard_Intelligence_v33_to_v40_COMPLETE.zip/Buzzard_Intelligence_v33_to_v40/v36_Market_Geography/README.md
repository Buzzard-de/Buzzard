# Buzzard Intelligence v36 — Market Geography Intelligence Engine

v36 tracks countries/markets, launch status, market signals, currency and research priority.
It supports Buzzard's staged expansion planning and keeps market-level observations separate from assumptions.

## Run
```bash
python main.py init
python main.py demo
python main.py report
```

This package is a modular foundation. Real external data connections must use authorized/public APIs, feeds or compliant web research adapters.
