# Buzzard Intelligence v37 — Risk & Compliance Intelligence Engine

v37 creates structured risk records for products, suppliers and markets.
Risk types include regulatory, product safety, authenticity, tax/customs, logistics, platform and data-quality.
It is a decision-support layer, not legal advice.

## Run
```bash
python main.py init
python main.py demo
python main.py report
```

This package is a modular foundation. Real external data connections must use authorized/public APIs, feeds or compliant web research adapters.
