# Buzzard Intelligence v34 — Alert & Anomaly Detection Engine

v34 monitors saved intelligence signals and creates alerts for meaningful changes.
Supports price, demand, competitor, supplier, category and risk signals.
Alerts are evidence-linked and can be NEW, ACKNOWLEDGED, RESOLVED or IGNORED.
No alert is treated as a fact without the underlying observation.

## Run
```bash
python main.py init
python main.py demo
python main.py report
```

This package is a modular foundation. Real external data connections must use authorized/public APIs, feeds or compliant web research adapters.
