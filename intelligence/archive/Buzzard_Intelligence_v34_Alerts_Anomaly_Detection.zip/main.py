import argparse, json
from datetime import datetime, timezone
from pathlib import Path

DB = Path("buzzard_v34.json")

def now():
    return datetime.now(timezone.utc).isoformat()

def load():
    if DB.exists():
        return json.loads(DB.read_text(encoding="utf-8"))
    return {"version": 34, "created_at": now(), "records": [], "events": []}

def save(data):
    DB.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def init():
    data=load()
    data.setdefault("version",34)
    data.setdefault("records",[])
    data.setdefault("events",[])
    save(data)
    print("v34 hazır.")

def demo():
    data=load()
    data["records"].append({"type":"DEMO","title":"Alert & Anomaly Detection Engine","status":"ACTIVE","created_at":now()})
    data["events"].append({"event":"DEMO_CREATED","created_at":now()})
    save(data)
    print("Demo kaydı oluşturuldu.")

def report():
    data=load()
    print("=== BUZZARD v34 — ALERT & ANOMALY DETECTION ENGINE ===")
    print("Kayıt:", len(data.get("records",[])))
    print("Audit olayları:", len(data.get("events",[])))
    for r in data.get("records",[])[:20]:
        print("-", r)

def main():
    p=argparse.ArgumentParser(description="Alert & Anomaly Detection Engine")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init"); s.add_parser("demo"); s.add_parser("report")
    a=p.parse_args()
    if a.cmd=="init": init()
    elif a.cmd=="demo": demo()
    elif a.cmd=="report": report()
    else: p.print_help()

if __name__=="__main__":
    main()
