# Buzzard Intelligence v35 — Deep Category Taxonomy Engine

v35 expands the category intelligence layer into a hierarchy:
category -> subcategory -> sub-subcategory -> product family.
It stores ownership, research priority and parent-child relationships.
The included starter taxonomy is intentionally editable and does not claim that every market uses identical category structures.

## Run
```bash
python main.py init
python main.py demo
python main.py report
```

This package is a modular foundation. Real external data connections must use authorized/public APIs, feeds or compliant web research adapters.
