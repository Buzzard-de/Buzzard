# Buzzard Intelligence v38 — Profitability & Scenario Engine

v38 combines selling price, product cost, shipping, marketplace/payment fees, advertising and tax effects into scenario calculations.
It keeps the Buzzard minimum net-profit threshold of EUR 0.50 as a configurable gate.
Scenarios are estimates and require current cost inputs.

## Run
```bash
python main.py init
python main.py demo
python main.py report
```

This package is a modular foundation. Real external data connections must use authorized/public APIs, feeds or compliant web research adapters.
