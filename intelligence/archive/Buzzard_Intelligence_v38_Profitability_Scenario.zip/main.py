import argparse, json
from datetime import datetime, timezone
from pathlib import Path

DB = Path("buzzard_v38.json")

def now():
    return datetime.now(timezone.utc).isoformat()

def load():
    if DB.exists():
        return json.loads(DB.read_text(encoding="utf-8"))
    return {"version": 38, "created_at": now(), "records": [], "events": []}

def save(data):
    DB.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def init():
    data=load()
    data.setdefault("version",38)
    data.setdefault("records",[])
    data.setdefault("events",[])
    save(data)
    print("v38 hazır.")

def demo():
    data=load()
    data["records"].append({"type":"DEMO","title":"Profitability & Scenario Engine","status":"ACTIVE","created_at":now()})
    data["events"].append({"event":"DEMO_CREATED","created_at":now()})
    save(data)
    print("Demo kaydı oluşturuldu.")

def report():
    data=load()
    print("=== BUZZARD v38 — PROFITABILITY & SCENARIO ENGINE ===")
    print("Kayıt:", len(data.get("records",[])))
    print("Audit olayları:", len(data.get("events",[])))
    for r in data.get("records",[])[:20]:
        print("-", r)

def main():
    p=argparse.ArgumentParser(description="Profitability & Scenario Engine")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init"); s.add_parser("demo"); s.add_parser("report")
    a=p.parse_args()
    if a.cmd=="init": init()
    elif a.cmd=="demo": demo()
    elif a.cmd=="report": report()
    else: p.print_help()

if __name__=="__main__":
    main()
