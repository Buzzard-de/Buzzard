# Buzzard Intelligence v39 — Intelligence Dashboard Engine

v39 provides a central read-only dashboard over the intelligence layers.
It summarizes missions, categories, competitors, suppliers, alerts, product candidates and memory.
The dashboard is designed as an operational control panel rather than a source of truth by itself.

## Run
```bash
python main.py init
python main.py demo
python main.py report
```

This package is a modular foundation. Real external data connections must use authorized/public APIs, feeds or compliant web research adapters.
