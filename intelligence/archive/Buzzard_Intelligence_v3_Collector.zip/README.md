# Buzzard Intelligence v3 — Legal Public-Source Collector

v3, v2 hafıza motoruna veri toplama katmanı ekler.

## Tasarım

Collector:
1. İzin verilen açık URL/API kaynağını alır.
2. robots.txt kontrolü yapar.
3. Sayfayı düşük hızla ve kullanıcı aracısı bilgisiyle ister.
4. Ürün adı, fiyat, marka, kategori gibi açık ürün sinyallerini JSON-LD/Product verisinden çıkarmayı dener.
5. Kaynak URL + tarih ile ham gözlemi hafızaya aktarır.
6. v2 MemoryEngine fiyat/popülerlik değişimlerini karşılaştırır.

## Önemli sınır

Bu araç CAPTCHA, giriş duvarı, bot koruması, paywall veya erişim kısıtını aşmaya çalışmaz.
Kimlik doğrulaması gerektiren kaynaklar için ileride resmi API connector kullanılmalıdır.
"En çok satan" bilgisi yalnızca kaynak bunu açıkça yayımlıyorsa kaydedilir; ürün sıralaması/featured/on-sale gibi sinyaller satış adediyle karıştırılmaz.

## Kurulum

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py init
python main.py seed
```

## Tek kaynak tarama

```bash
python main.py collect --url "https://example.com/product-page" --category "Otomotiv"
```

## Çoklu kaynak

```bash
python main.py collect-list sources.txt --category "Otomotiv"
```

sources.txt her satırda bir açık URL içermelidir.

## Sonraki aşama

Resmi API adapter'ları, zamanlayıcı, görev kuyruğu, hata/limit yönetimi ve daha güçlü ürün şeması eklenmelidir.
