import argparse
from buzzard_intelligence.collector import Collector

def main():
    p = argparse.ArgumentParser(description="Buzzard Intelligence v3 Collector")
    s = p.add_subparsers(dest="cmd")

    s.add_parser("init")
    s.add_parser("seed")

    c = s.add_parser("collect")
    c.add_argument("--url", required=True)
    c.add_argument("--category", required=True)
    c.add_argument("--subcategory", default="")
    c.add_argument("--country", default="")
    c.add_argument("--platform", default="public_web")

    cl = s.add_parser("collect-list")
    cl.add_argument("file")
    cl.add_argument("--category", required=True)
    cl.add_argument("--subcategory", default="")
    cl.add_argument("--country", default="")
    cl.add_argument("--platform", default="public_web")

    args = p.parse_args()
    collector = Collector()

    if args.cmd == "init":
        collector.init()
        print("v3 collector + hafıza hazır.")
    elif args.cmd == "seed":
        collector.init()
        print(f"{collector.seed()} kategori hazır.")
    elif args.cmd == "collect":
        collector.init()
        print(collector.collect(
            args.url, args.category, args.subcategory,
            args.country, args.platform
        ))
    elif args.cmd == "collect-list":
        collector.init()
        urls = [
            x.strip() for x in open(args.file, encoding="utf-8")
            if x.strip() and not x.lstrip().startswith("#")
        ]
        for url in urls:
            try:
                print(collector.collect(
                    url, args.category, args.subcategory,
                    args.country, args.platform
                ))
            except Exception as exc:
                print(f"HATA | {url} | {exc}")
    else:
        p.print_help()

if __name__ == "__main__":
    main()
