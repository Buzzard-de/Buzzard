BUZZARD INTELLIGENCE v41-V70

30 ileri seviye modül tek klasörde.
v41-v70, v40 sonrası genişleme bloğudur. Her modül bağımsız paketlenmiştir.
Gerçek veri toplama için yetkili/public connector bağlantıları ayrıca yapılmalıdır.
