import json
from pathlib import Path
from datetime import datetime, timezone

DB=Path("buzzard_v61.json")

def now(): return datetime.now(timezone.utc).isoformat()

def load():
    if DB.exists():
        return json.loads(DB.read_text(encoding="utf-8"))
    return {"version":61,"module":"Customer Review Intelligence","records":[],"events":[]}

def save(x): DB.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding="utf-8")

def init():
    x=load(); save(x); print("v61 Customer Review Intelligence hazır.")

def demo():
    x=load()
    x["records"].append({"type":"DEMO","module":"Customer Review Intelligence","status":"ACTIVE","created_at":now()})
    x["events"].append({"event":"DEMO_CREATED","created_at":now()})
    save(x); print("Demo kaydı oluşturuldu.")

def report():
    x=load()
    print("=== BUZZARD v61 — CUSTOMER REVIEW INTELLIGENCE ===")
    print("Kayıt:",len(x["records"]))
    print("Olay:",len(x["events"]))
    for r in x["records"][-20:]: print("-",r)

if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument("cmd",choices=["init","demo","report"])
    a=p.parse_args()
    {"init":init,"demo":demo,"report":report}[a.cmd]()
