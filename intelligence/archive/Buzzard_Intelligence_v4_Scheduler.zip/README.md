# Buzzard Intelligence v4 — Scheduler & Source Registry

v4, collector'ın görev yönetimini ekler.

## Özellikler
- 100+ kategori için tarama görevleri
- Kaynak kayıt sistemi
- Öncelik
- Tekrarlama aralığı
- Son çalışma / sonraki çalışma zamanı
- Başarılı/başarısız görev durumu
- Hata mesajı kaydı
- Güvenli varsayılan: aynı kaynağa kısa sürede tekrar yüklenmez
- v3 collector ile uyumlu görev kuyruğu

Bu sürüm bir orkestrasyon iskeletidir. Gerçek üretim ortamında PostgreSQL/Redis/Celery gibi daha güçlü bileşenlere geçilebilir.

Kurulum:
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py init
python main.py seed
python main.py tasks
```

Görev ekleme:
```bash
python main.py add-task --category "Otomotiv" --url "https://example.com/product" --interval 1440 --priority 10
```

Hazır görevleri çalıştırma:
```bash
python main.py run
```

1440 dakika = 24 saat.
