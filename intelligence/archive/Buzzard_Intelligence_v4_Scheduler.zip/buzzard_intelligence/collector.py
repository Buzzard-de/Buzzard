import json
import time
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser
import requests
from bs4 import BeautifulSoup
from .memory import MemoryEngine

class Collector:
    USER_AGENT = "BuzzardIntelligenceResearchBot/0.1 (+research; respect robots.txt)"

    def __init__(self):
        self.memory = MemoryEngine()
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": self.USER_AGENT})

    def init(self):
        self.memory.init()

    def allowed_by_robots(self, url):
        p = urlparse(url)
        robots_url = f"{p.scheme}://{p.netloc}/robots.txt"
        rp = RobotFileParser()
        rp.set_url(robots_url)
        try:
            rp.read()
            return rp.can_fetch(self.USER_AGENT, url)
        except Exception:
            return False

    def fetch(self, url):
        if not self.allowed_by_robots(url):
            raise RuntimeError("robots.txt izin vermiyor veya doğrulanamadı.")
        r = self.session.get(url, timeout=20)
        r.raise_for_status()
        if "text/html" not in r.headers.get("content-type", ""):
            raise RuntimeError("HTML değil; uygun resmi API/feed adapter'ı gerekir.")
        return r.text

    def parse(self, html, url):
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup.find_all("script", attrs={"type":"application/ld+json"}):
            try:
                data = json.loads(tag.string or tag.get_text())
            except Exception:
                continue
            items = data if isinstance(data, list) else [data]
            for item in items:
                if not isinstance(item, dict):
                    continue
                typ = item.get("@type")
                types = typ if isinstance(typ, list) else [typ]
                if "Product" not in types:
                    continue
                brand = item.get("brand","")
                if isinstance(brand, dict):
                    brand = brand.get("name","")
                offers = item.get("offers", {})
                if isinstance(offers, list):
                    offers = offers[0] if offers else {}
                price = offers.get("price") if isinstance(offers, dict) else None
                currency = offers.get("priceCurrency","") if isinstance(offers, dict) else ""
                try:
                    price = float(str(price).replace(",", ".")) if price is not None else None
                except Exception:
                    price = None
                return item.get("name"), brand, price, currency
        h1 = soup.find("h1")
        if h1:
            return h1.get_text(" ", strip=True), "", None, ""
        return None, "", None, ""

    def collect(self, url, category, subcategory="", country="", platform="public_web"):
        html = self.fetch(url)
        name, brand, price, currency = self.parse(html, url)
        if not name:
            return f"SKIP | ürün sinyali bulunamadı | {url}"

        self.memory.observe(
            category, subcategory, "", name, brand, platform, country,
            price, currency, None, url, urlparse(url).netloc, 0.80
        )
        time.sleep(1.5)
        return f"OK | {name} | {price or '-'} {currency} | {url}"
