import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path("buzzard_intelligence_v4_memory.db")

SEED_CATEGORIES = [
    "Otomotiv","Tarım Makineleri ve Ekipmanları","Lastik ve Jant","Elektronik",
    "Bilgisayar","Telefon ve Aksesuarları","Ev Aletleri","Beyaz Eşya",
    "Ev ve Yaşam","Mobilya","Mutfak","Bahçe","Hırdavat","El Aletleri",
    "İnşaat","Temizlik","Kozmetik","Kişisel Bakım","Giyim","Ayakkabı",
    "Çanta ve Aksesuar","Tekstil","Bebek Ürünleri","Çocuk Ürünleri",
    "Oyuncak","Hobi","Spor","Kamp ve Outdoor","Bisiklet","Evcil Hayvan",
    "Kırtasiye","Ofis","Kitap","Müzik","Fotoğraf","Video","Oyun",
    "Oyun Konsolları","Bilgisayar Parçaları","Güvenlik Sistemleri",
    "Aydınlatma","Elektrik Malzemeleri","Güneş Enerjisi","Enerji ve Batarya",
    "Yedek Parça","Motosiklet","Tekne ve Denizcilik","Karavan","Seyahat",
    "Valiz ve Seyahat Aksesuarları","Takı","Saat","Gözlük","Hediyelik",
    "Dekorasyon","Ev Tekstili","Yatak ve Uyku","Banyo",
    "Depolama ve Organizasyon","Bebek Bakım","Anne Ürünleri","Gıda",
    "İçecek","Kahve ve Çay","Endüstriyel Ürünler","İş Güvenliği",
    "İş Kıyafetleri","Restoran Ekipmanları","Otel Ekipmanları","Tarım Ürünleri",
    "Sulama","Seracılık","Bahçe Makineleri","Orman ve Ağaç Ekipmanları",
    "Yapıştırıcılar","Boya","Yapı Malzemeleri","Isıtma","Klima","Havalandırma",
    "Su Tesisatı","Banyo Tesisatı","Akıllı Ev","IoT","Bebek Elektroniği",
    "Optik","Laboratuvar Ürünleri","Endüstriyel Otomasyon","Robotik",
    "3D Yazıcı ve Filament","Drone","Koleksiyon","Sanat ve El İşi",
    "Parti ve Organizasyon","Mevsimsel Ürünler","Okul Ürünleri","Ambalaj",
    "Lojistik Ekipmanları","Depo Ekipmanları","Profesyonel Temizlik",
    "İşletme Teknolojileri","Medya ve İçerik Ekipmanları"
]

class MemoryEngine:
    def __init__(self, path=DB_PATH):
        self.path = Path(path)

    def connect(self):
        c = sqlite3.connect(self.path)
        c.row_factory = sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS categories(
                id INTEGER PRIMARY KEY,name TEXT NOT NULL,parent_id INTEGER,
                level INTEGER NOT NULL,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL,
                UNIQUE(name,parent_id));
            CREATE TABLE IF NOT EXISTS sources(
                id INTEGER PRIMARY KEY,url TEXT UNIQUE NOT NULL,name TEXT,
                first_seen TEXT NOT NULL,last_seen TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS products(
                id INTEGER PRIMARY KEY,name TEXT NOT NULL,brand TEXT,
                category_id INTEGER,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL,
                UNIQUE(name,brand,category_id));
            CREATE TABLE IF NOT EXISTS observations(
                id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL,platform TEXT,
                country TEXT,price REAL,currency TEXT,popularity REAL,
                confidence REAL NOT NULL,source_id INTEGER NOT NULL,observed_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events(
                id INTEGER PRIMARY KEY,product_id INTEGER,event_type TEXT,
                old_value TEXT,new_value TEXT,detected_at TEXT NOT NULL);
            """)

    def category(self,name,parent=None,level=1):
        now=self.now()
        with self.connect() as c:
            r=c.execute("SELECT id FROM categories WHERE name=? AND parent_id IS ?",
                        (name.strip(),parent)).fetchone()
            if r:
                c.execute("UPDATE categories SET last_seen=? WHERE id=?",(now,r["id"]))
                return r["id"]
            return c.execute(
                "INSERT INTO categories(name,parent_id,level,first_seen,last_seen) VALUES(?,?,?,?,?)",
                (name.strip(),parent,level,now,now)).lastrowid

    def seed_categories(self):
        for x in SEED_CATEGORIES: self.category(x)
        return len(SEED_CATEGORIES)

    def source(self,url,name):
        now=self.now()
        with self.connect() as c:
            r=c.execute("SELECT id FROM sources WHERE url=?",(url,)).fetchone()
            if r:
                c.execute("UPDATE sources SET last_seen=? WHERE id=?",(now,r["id"]))
                return r["id"]
            return c.execute(
                "INSERT INTO sources(url,name,first_seen,last_seen) VALUES(?,?,?,?)",
                (url,name,now,now)).lastrowid

    def observe(self,category,sub,subsub,product,brand,platform,country,
                price,currency,popularity,url,source_name,confidence):
        parent=self.category(category)
        if sub: parent=self.category(sub,parent,2)
        if subsub: parent=self.category(subsub,parent,3)
        sid=self.source(url,source_name)
        now=self.now()

        with self.connect() as c:
            r=c.execute(
                "SELECT id FROM products WHERE name=? AND brand=? AND category_id=?",
                (product.strip(),brand.strip(),parent)).fetchone()
            if r:
                pid=r["id"]
                prev=c.execute(
                    "SELECT price FROM observations WHERE product_id=? ORDER BY observed_at DESC LIMIT 1",
                    (pid,)).fetchone()
                if prev and price is not None and prev["price"] is not None and price != prev["price"]:
                    c.execute("""INSERT INTO events
                    (product_id,event_type,old_value,new_value,detected_at)
                    VALUES(?,?,?,?,?)""",
                    (pid,"PRICE_CHANGE",str(prev["price"]),str(price),now))
                c.execute("UPDATE products SET last_seen=? WHERE id=?",(now,pid))
            else:
                pid=c.execute(
                    """INSERT INTO products(name,brand,category_id,first_seen,last_seen)
                    VALUES(?,?,?,?,?)""",(product.strip(),brand.strip(),parent,now,now)).lastrowid
                c.execute("""INSERT INTO events
                    (product_id,event_type,old_value,new_value,detected_at)
                    VALUES(?,?,?,?,?)""",(pid,"NEW_DISCOVERY","",product,now))

            c.execute("""INSERT INTO observations
            (product_id,platform,country,price,currency,popularity,confidence,source_id,observed_at)
            VALUES(?,?,?,?,?,?,?,?,?)""",
            (pid,platform,country,price,currency,popularity,max(0,min(1,confidence)),sid,now))
