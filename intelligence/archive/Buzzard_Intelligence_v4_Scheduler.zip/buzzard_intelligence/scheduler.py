import sqlite3
from datetime import datetime, timezone, timedelta
from pathlib import Path
from .collector import Collector
from .memory import SEED_CATEGORIES

DB = Path("buzzard_intelligence_v4.db")

class Scheduler:
    def __init__(self):
        self.collector = Collector()

    def connect(self):
        c = sqlite3.connect(DB)
        c.row_factory = sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc)

    def init(self):
        self.collector.init()
        with self.connect() as c:
            c.execute("""
            CREATE TABLE IF NOT EXISTS scan_tasks(
                id INTEGER PRIMARY KEY,
                category TEXT NOT NULL,
                subcategory TEXT,
                url TEXT NOT NULL,
                country TEXT,
                platform TEXT,
                interval_minutes INTEGER NOT NULL,
                priority INTEGER NOT NULL DEFAULT 5,
                enabled INTEGER NOT NULL DEFAULT 1,
                last_run TEXT,
                next_run TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'PENDING',
                last_error TEXT
            )
            """)

    def seed_tasks(self):
        # Kaynak URL'leri olmadan otomatik web taraması başlatılmaz.
        # Her kategori için "kaynak bekleniyor" görevi oluşturulur.
        count = 0
        now = self.now().isoformat()
        with self.connect() as c:
            for cat in SEED_CATEGORIES:
                exists = c.execute(
                    "SELECT 1 FROM scan_tasks WHERE category=? LIMIT 1",
                    (cat,)
                ).fetchone()
                if exists:
                    continue
                c.execute("""
                    INSERT INTO scan_tasks
                    (category,subcategory,url,country,platform,interval_minutes,
                     priority,enabled,next_run,status)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                """, (
                    cat, "", "SOURCE_NOT_CONFIGURED", "", "public_web",
                    1440, 5, 0, now, "WAITING_SOURCE"
                ))
                count += 1
        return count

    def add_task(self, category, subcategory, url, country,
                 platform, interval_minutes, priority):
        if interval_minutes < 60:
            raise ValueError("Minimum tarama aralığı 60 dakikadır.")
        now = self.now()
        next_run = now.isoformat()
        with self.connect() as c:
            cur = c.execute("""
                INSERT INTO scan_tasks
                (category,subcategory,url,country,platform,interval_minutes,
                 priority,enabled,next_run,status)
                VALUES(?,?,?,?,?,?,?,?,?,?)
            """, (
                category, subcategory, url, country, platform,
                interval_minutes, priority, 1, next_run, "PENDING"
            ))
            return f"Görev #{cur.lastrowid} oluşturuldu."

    def list_tasks(self):
        with self.connect() as c:
            rows = c.execute("""
                SELECT id,category,subcategory,url,interval_minutes,
                       priority,enabled,last_run,next_run,status
                FROM scan_tasks
                ORDER BY priority DESC, id
            """).fetchall()

        if not rows:
            return "Henüz görev yok."

        out = ["=== BUZZARD TARAMA GÖREVLERİ ==="]
        for r in rows:
            out.append(
                f"#{r['id']} | {r['category']} | {r['status']} | "
                f"öncelik={r['priority']} | aralık={r['interval_minutes']} dk | "
                f"aktif={bool(r['enabled'])} | {r['url']}"
            )
        return "\n".join(out)

    def run_due(self):
        now = self.now()
        with self.connect() as c:
            rows = c.execute("""
                SELECT * FROM scan_tasks
                WHERE enabled=1 AND next_run<=?
                ORDER BY priority DESC, id
            """, (now.isoformat(),)).fetchall()

        if not rows:
            return "Şu anda çalıştırılacak görev yok."

        output = []
        for task in rows:
            try:
                result = self.collector.collect(
                    task["url"],
                    task["category"],
                    task["subcategory"] or "",
                    task["country"] or "",
                    task["platform"] or "public_web"
                )
                status = "SUCCESS"
                error = ""
                output.append(f"#{task['id']} {status} | {result}")
            except Exception as exc:
                status = "ERROR"
                error = str(exc)
                output.append(f"#{task['id']} {status} | {error}")

            next_run = now + timedelta(minutes=task["interval_minutes"])
            with self.connect() as c:
                c.execute("""
                    UPDATE scan_tasks
                    SET last_run=?, next_run=?, status=?, last_error=?
                    WHERE id=?
                """, (
                    now.isoformat(), next_run.isoformat(),
                    status, error, task["id"]
                ))

        return "\n".join(output)
