import argparse
from buzzard_intelligence.scheduler import Scheduler

def main():
    p = argparse.ArgumentParser(description="Buzzard Intelligence v4 Scheduler")
    s = p.add_subparsers(dest="cmd")

    s.add_parser("init")
    s.add_parser("seed")
    s.add_parser("tasks")
    s.add_parser("run")

    a = s.add_parser("add-task")
    a.add_argument("--category", required=True)
    a.add_argument("--subcategory", default="")
    a.add_argument("--url", required=True)
    a.add_argument("--country", default="")
    a.add_argument("--platform", default="public_web")
    a.add_argument("--interval", type=int, default=1440)
    a.add_argument("--priority", type=int, default=5)

    args = p.parse_args()
    app = Scheduler()

    if args.cmd == "init":
        app.init()
        print("v4 scheduler hazır.")
    elif args.cmd == "seed":
        app.init()
        print(f"{app.seed_tasks()} tarama görevi oluşturuldu.")
    elif args.cmd == "tasks":
        app.init()
        print(app.list_tasks())
    elif args.cmd == "add-task":
        app.init()
        print(app.add_task(
            args.category, args.subcategory, args.url,
            args.country, args.platform, args.interval, args.priority
        ))
    elif args.cmd == "run":
        app.init()
        print(app.run_due())
    else:
        p.print_help()

if __name__ == "__main__":
    main()
