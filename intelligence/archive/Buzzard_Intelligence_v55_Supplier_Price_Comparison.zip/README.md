# Buzzard Intelligence v55 — Supplier Price Comparison

Bu sürüm, Buzzard AI Intelligence / Kurmay Heyeti sisteminin Supplier Price Comparison katmanıdır.

Temel prensipler:
- yalnızca yetkili, kamuya açık veya izinli veri kaynakları
- kaynak + zaman damgası + güven seviyesi
- geçmiş veriyi sessizce silmeme
- belirsizliği açıkça işaretleme
- kritik ticari işlemlerde insan onayı
- kişisel/gizli verilere yetkisiz erişim yok
- otomatik karar yerine açıklanabilir karar desteği

Bu paket bir modül iskeletidir. Gerçek web/API bağlantıları ilgili yetkili connector'lar eklendiğinde çalıştırılmalıdır.

Çalıştırma:
```bash
python main.py init
python main.py demo
python main.py report
```
