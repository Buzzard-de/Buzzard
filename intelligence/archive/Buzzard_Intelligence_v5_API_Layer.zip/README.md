# Buzzard Intelligence v5 — API & Source Connector Layer

v5, v4 Scheduler'ın üstüne sürdürülebilir veri kaynağı bağlantı katmanı ekler.

## Amaç

İstihbarat sistemi artık her siteyi HTML ile kazımaya çalışmak yerine mümkün olduğunda:
- resmi API
- resmi ürün/katalog feed'i
- XML/JSON/CSV feed
- izin verilen açık veri kaynağı

kullanır.

## Güvenlik

API anahtarları kodun içine yazılmaz.
Ortam değişkenleri kullanılır.

Örnek:
```powershell
$env:BUZZARD_API_KEY="..."
```

Kod hiçbir kaynağın erişim kısıtlamasını aşmaya çalışmaz. CAPTCHA, login duvarı, rate-limit veya bot koruması atlatılmaz.

## Çalıştırma

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py init
python main.py sources
```

JSON API kaynağı ekleme:
```bash
python main.py add-api --name "Example Catalog API" --base-url "https://example.com/api/products" --category "Otomotiv"
```

Kaynakları test etme:
```bash
python main.py test-apis
```

Not:
Bu sürüm genel amaçlı bir connector framework'üdür. Belirli pazaryerlerinin resmi API'leri için ayrı adapter dosyaları ve ilgili platformların kendi kimlik doğrulama/uygulama şartları sonraki entegrasyonlarda doldurulmalıdır.
