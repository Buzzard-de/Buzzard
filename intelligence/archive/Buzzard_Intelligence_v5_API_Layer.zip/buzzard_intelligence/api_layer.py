import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

import requests

DB = Path("buzzard_intelligence_v5.db")

class APILayer:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "BuzzardIntelligenceResearch/0.1"
        })

    def connect(self):
        c = sqlite3.connect(DB)
        c.row_factory = sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.execute("""
            CREATE TABLE IF NOT EXISTS api_sources(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                base_url TEXT NOT NULL UNIQUE,
                category TEXT NOT NULL,
                country TEXT,
                platform TEXT,
                interval_minutes INTEGER NOT NULL,
                priority INTEGER NOT NULL DEFAULT 5,
                enabled INTEGER NOT NULL DEFAULT 1,
                auth_env TEXT,
                created_at TEXT NOT NULL,
                last_test TEXT,
                status TEXT DEFAULT 'NOT_TESTED',
                last_error TEXT
            )
            """)

    def add_source(self, name, base_url, category, country,
                   platform, interval, priority):
        parsed = urlparse(base_url)
        if parsed.scheme not in ("http", "https"):
            raise ValueError("Yalnızca HTTP/HTTPS kaynakları kabul edilir.")

        with self.connect() as c:
            c.execute("""
            INSERT OR IGNORE INTO api_sources
            (name,base_url,category,country,platform,interval_minutes,
             priority,created_at)
            VALUES(?,?,?,?,?,?,?,?)
            """, (
                name, base_url, category, country, platform,
                max(60, interval), priority, self.now()
            ))
        return f"API kaynağı kaydedildi: {name}"

    def list_sources(self):
        with self.connect() as c:
            rows = c.execute("""
                SELECT id,name,base_url,category,country,platform,
                       interval_minutes,priority,enabled,status
                FROM api_sources
                ORDER BY priority DESC,id
            """).fetchall()

        if not rows:
            return "Henüz API kaynağı tanımlanmadı."

        out = ["=== BUZZARD API KAYNAKLARI ==="]
        for r in rows:
            out.append(
                f"#{r['id']} | {r['name']} | {r['category']} | "
                f"{r['platform']} | {r['status']} | aktif={bool(r['enabled'])} | "
                f"{r['base_url']}"
            )
        return "\n".join(out)

    def _headers(self):
        headers = {}
        key = os.getenv("BUZZARD_API_KEY")
        if key:
            headers["Authorization"] = f"Bearer {key}"
        return headers

    def test_one(self, source):
        try:
            response = self.session.get(
                source["base_url"],
                headers=self._headers(),
                timeout=20
            )
            response.raise_for_status()

            content_type = response.headers.get("content-type", "")
            if not any(x in content_type for x in
                       ("json", "xml", "csv", "text")):
                raise RuntimeError(
                    f"Beklenmeyen Content-Type: {content_type}"
                )

            status = "OK"
            error = ""
        except Exception as exc:
            status = "ERROR"
            error = str(exc)

        with self.connect() as c:
            c.execute("""
                UPDATE api_sources
                SET last_test=?,status=?,last_error=?
                WHERE id=?
            """, (self.now(), status, error, source["id"]))

        return f"{source['name']}: {status}" + (f" | {error}" if error else "")

    def test_all(self):
        with self.connect() as c:
            rows = c.execute("""
                SELECT * FROM api_sources
                WHERE enabled=1
                ORDER BY priority DESC,id
            """).fetchall()

        if not rows:
            return "Test edilecek API kaynağı yok."

        return "\n".join(self.test_one(r) for r in rows)
