import argparse
from buzzard_intelligence.api_layer import APILayer

def main():
    p = argparse.ArgumentParser(description="Buzzard Intelligence v5 API Layer")
    s = p.add_subparsers(dest="cmd")

    s.add_parser("init")
    s.add_parser("sources")
    s.add_parser("test-apis")

    a = s.add_parser("add-api")
    a.add_argument("--name", required=True)
    a.add_argument("--base-url", required=True)
    a.add_argument("--category", required=True)
    a.add_argument("--country", default="")
    a.add_argument("--platform", default="official_api")
    a.add_argument("--interval", type=int, default=1440)
    a.add_argument("--priority", type=int, default=8)

    args = p.parse_args()
    app = APILayer()

    if args.cmd == "init":
        app.init()
        print("Buzzard Intelligence v5 API katmanı hazır.")
    elif args.cmd == "sources":
        app.init()
        print(app.list_sources())
    elif args.cmd == "add-api":
        app.init()
        print(app.add_source(
            args.name, args.base_url, args.category,
            args.country, args.platform, args.interval, args.priority
        ))
    elif args.cmd == "test-apis":
        app.init()
        print(app.test_all())
    else:
        p.print_help()

if __name__ == "__main__":
    main()
