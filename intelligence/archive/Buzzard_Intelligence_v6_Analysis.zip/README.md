# Buzzard Intelligence v6 — Market & Category Analysis Engine

v6, hafızaya alınmış gözlemlerden karar destek sinyalleri üretir.

Üretir:
- en çok gözlenen ürünler
- yükselen/düşen fiyat sinyalleri
- popülerlik değişimleri
- kategori yoğunluğu
- yeni keşifler
- kaynak çeşitliliği
- ülke bazlı ürün görünürlüğü
- "veri yetersiz" uyarısı

ÖNEMLİ:
Bu motor satış adedi yoksa "en çok satan" iddiasında bulunmaz.
Gözlem sayısı, kaynak sayısı ve yayımlanmış popülerlik sinyalleri birbirinden ayrılır.

Kurulum:
```bash
python main.py init
python main.py seed
python main.py demo
python main.py analyze
```
