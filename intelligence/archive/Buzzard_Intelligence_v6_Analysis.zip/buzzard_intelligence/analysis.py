import sqlite3
from datetime import datetime, timezone, timedelta
from pathlib import Path

DB = Path("buzzard_intelligence_v6.db")

CATEGORIES = [
    "Otomotiv","Tarım Makineleri ve Ekipmanları","Lastik ve Jant","Elektronik",
    "Bilgisayar","Telefon ve Aksesuarları","Ev Aletleri","Beyaz Eşya",
    "Ev ve Yaşam","Mobilya","Mutfak","Bahçe","Hırdavat","El Aletleri",
    "İnşaat","Temizlik","Kozmetik","Kişisel Bakım","Giyim","Ayakkabı",
    "Çanta ve Aksesuar","Tekstil","Bebek Ürünleri","Çocuk Ürünleri",
    "Oyuncak","Hobi","Spor","Kamp ve Outdoor","Bisiklet","Evcil Hayvan",
    "Kırtasiye","Ofis","Kitap","Müzik","Fotoğraf","Video","Oyun",
    "Oyun Konsolları","Bilgisayar Parçaları","Güvenlik Sistemleri",
    "Aydınlatma","Elektrik Malzemeleri","Güneş Enerjisi","Enerji ve Batarya",
    "Yedek Parça","Motosiklet","Tekne ve Denizcilik","Karavan","Seyahat",
    "Takı","Saat","Gözlük","Hediyelik","Dekorasyon","Ev Tekstili",
    "Banyo","Gıda","İçecek","Kahve ve Çay","İş Güvenliği",
    "İş Kıyafetleri","Restoran Ekipmanları","Tarım Ürünleri","Sulama",
    "Seracılık","Bahçe Makineleri","Yapı Malzemeleri","Isıtma","Klima",
    "Havalandırma","Su Tesisatı","Akıllı Ev","IoT","Robotik","Drone",
    "3D Yazıcı ve Filament","Sanat ve El İşi","Parti ve Organizasyon",
    "Mevsimsel Ürünler","Okul Ürünleri","Ambalaj","Lojistik Ekipmanları",
    "Depo Ekipmanları","Profesyonel Temizlik","Medya ve İçerik Ekipmanları"
]

class Analyzer:
    def connect(self):
        c = sqlite3.connect(DB)
        c.row_factory = sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS categories(
                id INTEGER PRIMARY KEY,
                name TEXT UNIQUE NOT NULL,
                first_seen TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS products(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                brand TEXT,
                category_id INTEGER NOT NULL,
                first_seen TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS observations(
                id INTEGER PRIMARY KEY,
                product_id INTEGER NOT NULL,
                platform TEXT,
                country TEXT,
                price REAL,
                currency TEXT,
                popularity REAL,
                source TEXT,
                observed_at TEXT NOT NULL
            );
            """)

    def seed(self):
        now = self.now()
        with self.connect() as c:
            for name in CATEGORIES:
                c.execute(
                    "INSERT OR IGNORE INTO categories(name,first_seen) VALUES(?,?)",
                    (name,now)
                )
        return len(CATEGORIES)

    def demo(self):
        now = self.now()
        with self.connect() as c:
            cat = c.execute(
                "SELECT id FROM categories WHERE name='Otomotiv'"
            ).fetchone()
            if not cat:
                self.seed()
                cat = c.execute(
                    "SELECT id FROM categories WHERE name='Otomotiv'"
                ).fetchone()

            products = [
                ("Örnek Fren Balatası","Brand A",49.90,82),
                ("Örnek Motor Yağı 5W-30","Brand B",54.90,91),
                ("Örnek Silecek","Brand C",19.90,74),
                ("Örnek Akü","Brand D",129.90,66)
            ]

            for name,brand,price,pop in products:
                c.execute(
                    "INSERT INTO products(name,brand,category_id,first_seen) VALUES(?,?,?,?)",
                    (name,brand,cat["id"],now)
                )
                pid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                c.execute("""INSERT INTO observations
                (product_id,platform,country,price,currency,popularity,source,observed_at)
                VALUES(?,?,?,?,?,?,?,?)""",
                (pid,"demo","DE",price,"EUR",pop,"demo",now))

    def top_observed_products(self, limit=20):
        with self.connect() as c:
            return c.execute("""
                SELECT p.name,p.brand,c.name category,
                       COUNT(o.id) observations,
                       AVG(o.popularity) avg_popularity,
                       COUNT(DISTINCT o.source) sources
                FROM products p
                JOIN categories c ON c.id=p.category_id
                LEFT JOIN observations o ON o.product_id=p.id
                GROUP BY p.id
                ORDER BY observations DESC, avg_popularity DESC
                LIMIT ?
            """,(limit,)).fetchall()

    def category_density(self):
        with self.connect() as c:
            return c.execute("""
                SELECT c.name,COUNT(DISTINCT p.id) products,
                       COUNT(o.id) observations
                FROM categories c
                LEFT JOIN products p ON p.category_id=c.id
                LEFT JOIN observations o ON o.product_id=p.id
                GROUP BY c.id
                ORDER BY observations DESC
            """).fetchall()

    def popularity_leaders(self, limit=20):
        with self.connect() as c:
            return c.execute("""
                SELECT p.name,p.brand,c.name category,
                       AVG(o.popularity) popularity,
                       COUNT(o.id) observations
                FROM products p
                JOIN categories c ON c.id=p.category_id
                JOIN observations o ON o.product_id=p.id
                WHERE o.popularity IS NOT NULL
                GROUP BY p.id
                HAVING COUNT(o.id) >= 1
                ORDER BY popularity DESC
                LIMIT ?
            """,(limit,)).fetchall()

    def source_coverage(self):
        with self.connect() as c:
            return c.execute("""
                SELECT COUNT(DISTINCT source) sources,
                       COUNT(DISTINCT platform) platforms,
                       COUNT(DISTINCT country) countries
                FROM observations
            """).fetchone()

    def full_report(self):
        top = self.top_observed_products()
        leaders = self.popularity_leaders()
        density = self.category_density()
        coverage = self.source_coverage()

        out = ["=== BUZZARD INTELLIGENCE v6 ANALİZ RAPORU ===",
               "",
               "VERİ KAPSAMI",
               f"Kaynak: {coverage['sources']}",
               f"Platform: {coverage['platforms']}",
               f"Ülke: {coverage['countries']}",
               "",
               "EN ÇOK GÖZLEMLENEN ÜRÜNLER",
               "(Bu liste satış adedi değildir; gözlem yoğunluğudur.)"]

        for r in top:
            out.append(
                f"- {r['name']} | {r['category']} | "
                f"gözlem={r['observations']} | "
                f"ortalama popülerlik={round(r['avg_popularity'],1) if r['avg_popularity'] is not None else '-'} | "
                f"kaynak={r['sources']}"
            )

        out += ["","POPÜLERLİK SİNYALİ YÜKSEK ÜRÜNLER"]
        for r in leaders:
            out.append(
                f"- {r['name']} | {r['category']} | "
                f"popülerlik={round(r['popularity'],1)} | gözlem={r['observations']}"
            )

        out += ["","KATEGORİ YOĞUNLUĞU"]
        for r in density[:30]:
            if r["observations"] or r["products"]:
                out.append(
                    f"- {r['name']} | ürün={r['products']} | gözlem={r['observations']}"
                )

        out += [
            "",
            "KARAR KURALI",
            "Bu motor karar vermez. Veriyi ve sinyalleri kurmay takımına sunar.",
            "Satış adedi açıkça doğrulanmadıkça 'en çok satan' ifadesi kullanılmaz."
        ]
        return "\n".join(out)
