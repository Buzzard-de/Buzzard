import argparse
from buzzard_intelligence.analysis import Analyzer

def main():
    p = argparse.ArgumentParser(description="Buzzard Intelligence v6 Analysis")
    s = p.add_subparsers(dest="cmd")

    s.add_parser("init")
    s.add_parser("seed")
    s.add_parser("demo")
    s.add_parser("analyze")

    args = p.parse_args()
    app = Analyzer()

    if args.cmd == "init":
        app.init()
        print("v6 analiz motoru hazır.")
    elif args.cmd == "seed":
        app.init()
        print(f"{app.seed()} kategori hazır.")
    elif args.cmd == "demo":
        app.init()
        app.demo()
        print("Demo gözlemleri eklendi.")
    elif args.cmd == "analyze":
        app.init()
        print(app.full_report())
    else:
        p.print_help()

if __name__ == "__main__":
    main()
