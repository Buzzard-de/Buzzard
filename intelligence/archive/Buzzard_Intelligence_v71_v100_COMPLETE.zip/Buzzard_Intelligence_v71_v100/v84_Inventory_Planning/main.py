import argparse, json
from pathlib import Path
from datetime import datetime, timezone

DB=Path("buzzard_v84.json")

def now(): return datetime.now(timezone.utc).isoformat()

def load():
    if DB.exists():
        return json.loads(DB.read_text(encoding="utf-8"))
    return {"version":84,"module":'Inventory Planning',"records":[],"events":[]}

def save(x):
    DB.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding="utf-8")

def init():
    save(load())
    print("v84 Inventory Planning bereit.")

def demo():
    x=load()
    x["records"].append({"type":"DEMO","module":'Inventory Planning',"status":"ACTIVE","created_at":now()})
    x["events"].append({"event":"DEMO_CREATED","created_at":now()})
    save(x)
    print("Demo-Datensatz erstellt.")

def report():
    x=load()
    print("=== BUZZARD v84 — INVENTORY PLANNING ===")
    print("Records:",len(x["records"]))
    print("Events:",len(x["events"]))
    for r in x["records"][-20:]:
        print("-",r)

p=argparse.ArgumentParser()
p.add_argument("cmd",choices=["init","demo","report"])
a=p.parse_args()
{"init":init,"demo":demo,"report":report}[a.cmd]()
