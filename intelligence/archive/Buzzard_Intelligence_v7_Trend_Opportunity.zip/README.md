# Buzzard Intelligence v7 — Trend & Opportunity Engine

v7, zaman serisi verilerinden trend ve fırsat sinyalleri üretir.

Sinyaller:
- yükselen popülerlik
- düşen popülerlik
- fiyat düşüş/yükselişleri
- yeni ürünler
- yeni kategoriler
- gözlem ivmesi
- veri açığı / düşük kapsama
- fırsat puanı

Önemli:
- Fırsat puanı karar değildir.
- Satış adedi yoksa satış adedi uydurulmaz.
- Az veriden kesin trend sonucu çıkarılmaz; "veri yetersiz" işareti verilir.
- Her sinyal kaynak ve zaman bilgisiyle ilişkilidir.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py analyze
```
