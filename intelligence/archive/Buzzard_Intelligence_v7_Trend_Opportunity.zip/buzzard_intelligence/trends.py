import sqlite3
from datetime import datetime, timezone, timedelta
from pathlib import Path

DB = Path("buzzard_intelligence_v7.db")

class TrendEngine:
    def connect(self):
        c = sqlite3.connect(DB)
        c.row_factory = sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc)

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS categories(
                id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL
            );
            CREATE TABLE IF NOT EXISTS products(
                id INTEGER PRIMARY KEY, name TEXT NOT NULL, brand TEXT,
                category_id INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS observations(
                id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL,
                country TEXT, platform TEXT, price REAL, currency TEXT,
                popularity REAL, source TEXT, observed_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS signals(
                id INTEGER PRIMARY KEY, product_id INTEGER,
                category_id INTEGER, signal_type TEXT NOT NULL,
                score REAL NOT NULL, explanation TEXT,
                created_at TEXT NOT NULL
            );
            """)

    def demo(self):
        now = self.now()
        with self.connect() as c:
            c.execute("INSERT OR IGNORE INTO categories(id,name) VALUES(1,'Otomotiv')")
            c.execute("INSERT OR IGNORE INTO categories(id,name) VALUES(2,'Bahçe')")
            c.execute("INSERT OR IGNORE INTO products(id,name,brand,category_id) VALUES(1,'Örnek Motor Yağı','Brand A',1)")
            c.execute("INSERT OR IGNORE INTO products(id,name,brand,category_id) VALUES(2,'Örnek Bahçe Hortumu','Brand B',2)")
            for days, pop, price in [(30,45,60),(20,52,58),(10,68,55),(3,81,51)]:
                t=(now-timedelta(days=days)).isoformat()
                c.execute("""INSERT INTO observations
                    (product_id,country,platform,price,currency,popularity,source,observed_at)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (1,"DE","demo",price,"EUR",pop,"demo",t))
            for days, pop, price in [(30,70,35),(20,67,36),(10,64,37),(3,60,39)]:
                t=(now-timedelta(days=days)).isoformat()
                c.execute("""INSERT INTO observations
                    (product_id,country,platform,price,currency,popularity,source,observed_at)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (2,"DE","demo",price,"EUR",pop,"demo",t))

    def product_trend(self, pid):
        with self.connect() as c:
            rows=c.execute("""
                SELECT popularity,price,observed_at
                FROM observations WHERE product_id=?
                ORDER BY observed_at ASC
            """,(pid,)).fetchall()
        usable=[r for r in rows if r["popularity"] is not None]
        if len(usable)<2:
            return None
        first=usable[0]["popularity"]
        last=usable[-1]["popularity"]
        delta=last-first
        if delta >= 10:
            direction="RISING"
        elif delta <= -10:
            direction="FALLING"
        else:
            direction="STABLE"
        return direction, delta, len(usable), usable[0]["observed_at"], usable[-1]["observed_at"]

    def opportunity_score(self, delta, observations):
        if observations < 3:
            return 0.0
        # Basit ve açıklanabilir skor; satış tahmini değildir.
        score = max(0.0, min(100.0, 50 + delta * 1.5))
        return round(score, 1)

    def report(self):
        with self.connect() as c:
            products=c.execute("""
                SELECT p.id,p.name,p.brand,c.name category
                FROM products p JOIN categories c ON c.id=p.category_id
            """).fetchall()

        out=["=== BUZZARD INTELLIGENCE v7 — TREND & FIRSAT ==="]
        found=False
        for p in products:
            trend=self.product_trend(p["id"])
            if not trend:
                out.append(f"- {p['name']} | VERİ YETERSİZ")
                continue
            direction,delta,n,start,end=trend
            score=self.opportunity_score(delta,n)
            found=True
            out.append(
                f"- {p['name']} | {p['category']} | {direction} | "
                f"değişim={delta:+.1f} | gözlem={n} | fırsat_skoru={score}"
            )
        if not found:
            out.append("Yeterli zaman serisi verisi yok.")
        out += [
            "",
            "YORUM:",
            "RISING/FALLING yalnızca mevcut gözlemlerdeki değişimi ifade eder.",
            "Fırsat skoru satış garantisi veya yatırım tavsiyesi değildir."
        ]
        return "\\n".join(out)
