import argparse
from buzzard_intelligence.trends import TrendEngine

def main():
    p = argparse.ArgumentParser(description="Buzzard Intelligence v7")
    s = p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("analyze")
    args = p.parse_args()
    app = TrendEngine()
    if args.cmd == "init":
        app.init()
        print("v7 trend motoru hazır.")
    elif args.cmd == "demo":
        app.init()
        app.demo()
        print("Demo zaman serisi verisi oluşturuldu.")
    elif args.cmd == "analyze":
        app.init()
        print(app.report())
    else:
        p.print_help()

if __name__ == "__main__":
    main()
