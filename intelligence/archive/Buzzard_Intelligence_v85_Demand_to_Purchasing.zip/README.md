# Buzzard Intelligence v85 — Demand to Purchasing

Dies ist Modul v85 der Buzzard Intelligence Plattform.

Zweck:
Demand to Purchasing als eigenständige, auditierbare Intelligence-Schicht vorzubereiten.

Grundprinzipien:
- nur autorisierte, öffentliche oder ausdrücklich erlaubte Datenquellen
- Quelle und Zeitstempel bei externen Beobachtungen
- keine geheimen oder privaten Daten
- Unsicherheit und Datenlücken sichtbar halten
- historische Erkenntnisse nicht still überschreiben
- irreversible kommerzielle Aktionen bleiben menschlicher Freigabe vorbehalten

Status:
Dieses Paket enthält die technische Modulbasis. Eine produktive Live-Anbindung
benötigt die jeweiligen autorisierten APIs, Feeds, Konten und Connectoren.

Start:
```bash
python main.py init
python main.py demo
python main.py report
```
