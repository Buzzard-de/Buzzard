# Buzzard Intelligence v8 — Category Discovery Engine

v8'in görevi kategori ağacını genişletmektir.

- Ana kategori keşfi
- Alt kategori keşfi
- Alt-alt kategori keşfi
- Aynı kategorinin farklı yazımlarını normalize etme
- Yeni kategori / mevcut kategori ayrımı
- Kapsama boşluğu tespiti
- Kaynak ve tarih kaydı
- 100+ ana kategori omurgasını genişletebilme

Bu sürüm karar vermez. Öneri üretir ve kaynakla birlikte kaydeder.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py discover
```

Not:
Gerçek otomatik keşif için sonraki bağlayıcılar, izin verilen API/feed/web kaynaklarından kategori sinyallerini bu motora aktarabilir.
