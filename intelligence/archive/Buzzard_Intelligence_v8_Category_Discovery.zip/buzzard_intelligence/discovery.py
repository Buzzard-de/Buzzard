import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB=Path("buzzard_intelligence_v8.db")

def normalize(text):
    text=" ".join(text.strip().split())
    return text.casefold()

class CategoryDiscovery:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc).isoformat()

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS categories(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                normalized TEXT NOT NULL,
                parent_id INTEGER,
                level INTEGER NOT NULL,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                UNIQUE(normalized,parent_id)
            );
            CREATE TABLE IF NOT EXISTS category_candidates(
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                normalized TEXT NOT NULL,
                parent_name TEXT,
                level INTEGER NOT NULL,
                source TEXT NOT NULL,
                confidence REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'NEW',
                discovered_at TEXT NOT NULL,
                UNIQUE(normalized,parent_name,source)
            );
            CREATE TABLE IF NOT EXISTS category_events(
                id INTEGER PRIMARY KEY,
                category_name TEXT NOT NULL,
                event_type TEXT NOT NULL,
                source TEXT,
                detected_at TEXT NOT NULL
            );
            """)

    def add_candidate(self,name,parent,level,source,confidence):
        n=normalize(name)
        now=self.now()
        with self.connect() as c:
            existing=c.execute("""
                SELECT id FROM categories
                WHERE normalized=? AND parent_id IS
                (SELECT id FROM categories WHERE normalized=? AND parent_id IS NULL)
            """,(n,normalize(parent) if parent else "")).fetchone()

            c.execute("""
                INSERT OR IGNORE INTO category_candidates
                (name,normalized,parent_name,level,source,confidence,discovered_at)
                VALUES(?,?,?,?,?,?,?)
            """,(name,n,parent,level,source,max(0,min(1,confidence)),now))

            if existing:
                return f"MEVCUT KATEGORİ: {name}"

            c.execute("""
                INSERT INTO category_events
                (category_name,event_type,source,detected_at)
                VALUES(?,?,?,?)
            """,(name,"NEW_CATEGORY_SIGNAL",source,now))

        return f"YENİ KATEGORİ SİNYALİ: {name}"

    def demo(self):
        demo=[
            ("Fren Sistemi","Otomotiv",2),
            ("Fren Balataları","Fren Sistemi",3),
            ("Fren Diskleri","Fren Sistemi",3),
            ("Motor Yağları","Otomotiv",2),
            ("5W-30 Motor Yağı","Motor Yağları",3),
            ("Seracılık Ekipmanları","Bahçe",2),
            ("Otomatik Sulama Sistemleri","Seracılık Ekipmanları",3),
            ("Akıllı Sulama Kontrolü","Seracılık Ekipmanları",3)
        ]
        for name,parent,level in demo:
            self.add_candidate(name,parent,level,"demo-source",0.85)

    def report(self):
        with self.connect() as c:
            candidates=c.execute("""
                SELECT name,parent_name,level,source,confidence,status,discovered_at
                FROM category_candidates
                ORDER BY confidence DESC,level,name
            """).fetchall()

            events=c.execute("""
                SELECT category_name,event_type,source,detected_at
                FROM category_events
                ORDER BY detected_at DESC LIMIT 30
            """).fetchall()

        out=["=== BUZZARD v8 KATEGORİ KEŞİF RAPORU ===","",
             "YENİ / BEKLEYEN KATEGORİ SİNYALLERİ"]
        if not candidates:
            out.append("- Henüz kategori sinyali yok.")
        for r in candidates:
            out.append(
                f"- {r['name']} | üst={r['parent_name'] or '-'} | "
                f"seviye={r['level']} | güven={r['confidence']:.2f} | "
                f"durum={r['status']} | kaynak={r['source']}"
            )

        out += ["","SON KATEGORİ OLAYLARI"]
        for r in events:
            out.append(
                f"- {r['event_type']} | {r['category_name']} | "
                f"{r['source']} | {r['detected_at']}"
            )

        out += [
            "",
            "KURAL:",
            "Yeni kategori sinyali otomatik olarak ticari karar değildir.",
            "Kategori Buzzard'a eklenmeden önce kaynak ve uygunluk doğrulaması yapılmalıdır."
        ]
        return "\\n".join(out)
