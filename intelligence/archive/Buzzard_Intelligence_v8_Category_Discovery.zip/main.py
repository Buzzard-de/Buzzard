import argparse
from buzzard_intelligence.discovery import CategoryDiscovery

def main():
    p = argparse.ArgumentParser(description="Buzzard Intelligence v8")
    s = p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("discover")
    a = s.add_parser("add")
    a.add_argument("--name", required=True)
    a.add_argument("--parent", default="")
    a.add_argument("--level", type=int, default=1)
    a.add_argument("--source", required=True)
    a.add_argument("--confidence", type=float, default=0.8)
    args=p.parse_args()
    app=CategoryDiscovery()
    if args.cmd=="init":
        app.init(); print("v8 kategori keşif motoru hazır.")
    elif args.cmd=="demo":
        app.init(); app.demo(); print("Demo kategori sinyalleri eklendi.")
    elif args.cmd=="discover":
        app.init(); print(app.report())
    elif args.cmd=="add":
        app.init()
        print(app.add_candidate(args.name,args.parent,args.level,args.source,args.confidence))
    else:
        p.print_help()

if __name__=="__main__":
    main()
