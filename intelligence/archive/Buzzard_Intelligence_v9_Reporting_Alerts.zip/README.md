# Buzzard Intelligence v9 — Reporting & Alert Engine

v9, istihbarat verisini okunabilir raporlara ve uyarılara dönüştürür.

Üretir:
- günlük/haftalık özet
- yeni ürün uyarıları
- yeni kategori uyarıları
- yükselen/düşen trend uyarıları
- fiyat değişimi uyarıları
- veri yetersizliği uyarıları
- kategori kapsamı raporu
- kaynak kapsamı raporu
- önceliklendirilmiş istihbarat kuyruğu

Karar vermez. Yönetici/Kurmay Heyeti için kanıtlı bilgi ve sinyal sunar.

Kurulum:
```bash
python main.py init
python main.py demo
python main.py report
python main.py alerts
```
