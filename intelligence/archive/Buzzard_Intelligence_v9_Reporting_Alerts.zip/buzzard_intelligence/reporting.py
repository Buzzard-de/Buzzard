import sqlite3
from datetime import datetime, timezone, timedelta
from pathlib import Path

DB=Path("buzzard_intelligence_v9.db")

class Reporter:
    def connect(self):
        c=sqlite3.connect(DB)
        c.row_factory=sqlite3.Row
        return c

    def now(self):
        return datetime.now(timezone.utc)

    def init(self):
        with self.connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS categories(
                id INTEGER PRIMARY KEY,name TEXT UNIQUE NOT NULL,
                first_seen TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS products(
                id INTEGER PRIMARY KEY,name TEXT NOT NULL,brand TEXT,
                category_id INTEGER NOT NULL,first_seen TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS observations(
                id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL,
                country TEXT,platform TEXT,price REAL,currency TEXT,
                popularity REAL,source TEXT,observed_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS alerts(
                id INTEGER PRIMARY KEY,alert_type TEXT NOT NULL,
                severity TEXT NOT NULL,title TEXT NOT NULL,
                details TEXT,entity TEXT,created_at TEXT NOT NULL,
                acknowledged INTEGER DEFAULT 0
            );
            """)

    def demo(self):
        now=self.now().isoformat()
        with self.connect() as c:
            c.execute("INSERT OR IGNORE INTO categories(id,name,first_seen) VALUES(1,'Otomotiv',?)",(now,))
            c.execute("INSERT OR IGNORE INTO categories(id,name,first_seen) VALUES(2,'Bahçe',?)",(now,))
            c.execute("""INSERT OR IGNORE INTO products
                (id,name,brand,category_id,first_seen)
                VALUES(1,'Örnek Motor Yağı','Brand A',1,?)""",(now,))
            c.execute("""INSERT OR IGNORE INTO products
                (id,name,brand,category_id,first_seen)
                VALUES(2,'Örnek Bahçe Hortumu','Brand B',2,?)""",(now,))
            for pop in (40,55,70,84):
                c.execute("""INSERT INTO observations
                    (product_id,country,platform,price,currency,popularity,source,observed_at)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (1,"DE","demo",50,"EUR",pop,"demo",now))
            c.execute("""INSERT INTO alerts
                (alert_type,severity,title,details,entity,created_at)
                VALUES(?,?,?,?,?,?)""",
                ("TREND","HIGH","Yükselen ürün sinyali",
                 "Örnek Motor Yağı için popülerlik gözlemleri yükseliyor.",
                 "Örnek Motor Yağı",now))

    def create_alert(self, typ, severity, title, details, entity):
        with self.connect() as c:
            c.execute("""
            INSERT INTO alerts
            (alert_type,severity,title,details,entity,created_at)
            VALUES(?,?,?,?,?,?)
            """,(typ,severity,title,details,entity,self.now().isoformat()))

    def alerts(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT alert_type,severity,title,details,entity,created_at
                FROM alerts
                WHERE acknowledged=0
                ORDER BY
                  CASE severity
                    WHEN 'CRITICAL' THEN 1
                    WHEN 'HIGH' THEN 2
                    WHEN 'MEDIUM' THEN 3
                    ELSE 4 END,
                  created_at DESC
            """).fetchall()
        if not rows:
            return "Aktif uyarı yok."
        out=["=== BUZZARD İSTİHBARAT UYARILARI ==="]
        for r in rows:
            out.append(
                f"[{r['severity']}] {r['title']} | {r['entity'] or '-'} | "
                f"{r['details'] or ''} | {r['created_at']}"
            )
        return "\\n".join(out)

    def priority_queue(self):
        with self.connect() as c:
            rows=c.execute("""
                SELECT alert_type,severity,title,details,entity,created_at
                FROM alerts
                WHERE acknowledged=0
                ORDER BY
                  CASE severity
                    WHEN 'CRITICAL' THEN 1
                    WHEN 'HIGH' THEN 2
                    WHEN 'MEDIUM' THEN 3
                    ELSE 4 END,
                  created_at DESC
                LIMIT 100
            """).fetchall()
        if not rows:
            return "Kurmay Heyeti için bekleyen istihbarat yok."
        out=["=== KURMAY HEYETİ İSTİHBARAT KUYRUĞU ==="]
        for i,r in enumerate(rows,1):
            out.append(
                f"{i}. [{r['severity']}] {r['title']} — "
                f"{r['entity'] or '-'}"
            )
        return "\\n".join(out)

    def report(self):
        with self.connect() as c:
            cats=c.execute("SELECT COUNT(*) n FROM categories").fetchone()["n"]
            products=c.execute("SELECT COUNT(*) n FROM products").fetchone()["n"]
            obs=c.execute("SELECT COUNT(*) n FROM observations").fetchone()["n"]
            alerts=c.execute(
                "SELECT COUNT(*) n FROM alerts WHERE acknowledged=0"
            ).fetchone()["n"]

            latest=c.execute("""
                SELECT p.name,p.brand,c.name category,o.price,o.currency,
                       o.popularity,o.observed_at,o.source
                FROM observations o
                JOIN products p ON p.id=o.product_id
                JOIN categories c ON c.id=p.category_id
                ORDER BY o.observed_at DESC
                LIMIT 20
            """).fetchall()

        out=[
            "=== BUZZARD İSTİHBARAT YÖNETİCİ RAPORU ===",
            "",
            f"Kategori: {cats}",
            f"Ürün: {products}",
            f"Gözlem: {obs}",
            f"Aktif uyarı: {alerts}",
            "",
            "SON İSTİHBARAT GÖZLEMLERİ"
        ]
        for r in latest:
            out.append(
                f"- {r['name']} | {r['category']} | "
                f"{r['price'] or '-'} {r['currency'] or ''} | "
                f"popülerlik={r['popularity'] if r['popularity'] is not None else '-'} | "
                f"{r['observed_at']}"
            )
        out += [
            "",
            "KULLANIM PRENSİBİ:",
            "Uyarı = inceleme önceliği. Uyarı tek başına ticari karar değildir.",
            "Karar yetkisi yönetici/Kurmay Heyeti'ndedir."
        ]
        return "\\n".join(out)
