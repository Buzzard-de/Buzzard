import argparse
from buzzard_intelligence.reporting import Reporter

def main():
    p=argparse.ArgumentParser(description="Buzzard Intelligence v9")
    s=p.add_subparsers(dest="cmd")
    s.add_parser("init")
    s.add_parser("demo")
    s.add_parser("report")
    s.add_parser("alerts")
    s.add_parser("queue")
    args=p.parse_args()

    app=Reporter()
    if args.cmd=="init":
        app.init()
        print("v9 raporlama motoru hazır.")
    elif args.cmd=="demo":
        app.init()
        app.demo()
        print("Demo istihbarat verileri hazır.")
    elif args.cmd=="report":
        app.init()
        print(app.report())
    elif args.cmd=="alerts":
        app.init()
        print(app.alerts())
    elif args.cmd=="queue":
        app.init()
        print(app.priority_queue())
    else:
        p.print_help()

if __name__=="__main__":
    main()
