# BUZZARD SMART MEGA MENU

48 ana kategoriye bağlı akıllı mega-menü.

Yapı:
- 48 ana kategori
- 796 alt kategori
- 6.411 alt-alt kategori
- Popüler / aranan kategoriler
- Top markalar alanı
- Çok satanlar alanı
- Fırsatlar / yeniler alanı
- 3 seviyeli arama
- Desktop / tablet / smartphone responsive

`index.html` doğrudan test edilebilir.
`data/taxonomy.json` ana veri kaynağıdır.

Not: Top marka ve ürün kartları şu an demo sinyalleridir. Gerçek ürün, fiyat,
stok, satış ve marka verileri daha sonra yasal kaynaklardan gelen canlı
feed/API ile bağlanmalıdır.
